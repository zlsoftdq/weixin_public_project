package com.zfrj.yzb.user.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.zfrj.base.controller.BaseController;
import com.zfrj.util.COMMON;
import com.zfrj.yzb.base.service.IUserService;

@Controller
@RequestMapping(value = "/app/user")
public class UserController extends BaseController{
	@Autowired
	IUserService userService;
	
	/**
	 * 
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/personal_chat_send")
	public void personal_chat_send(HttpServletRequest request,
			HttpServletResponse response){
	}
	

}
