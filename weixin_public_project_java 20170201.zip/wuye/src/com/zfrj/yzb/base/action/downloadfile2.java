package com.zfrj.yzb.base.action;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;


import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.ImageIcon;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.sun.image.codec.jpeg.ImageFormatException;
import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGEncodeParam;
import com.sun.image.codec.jpeg.JPEGImageDecoder;
import com.sun.image.codec.jpeg.JPEGImageEncoder;


/**
 * 
 * @author yzb
 * 
 * @date 2011-7-26
 * 
 */
public class downloadfile2 extends HttpServlet {

 private static final long serialVersionUID = -7744625344830285257L;
 private ServletContext sc;
 private String savePath;

 public void doGet(HttpServletRequest request, HttpServletResponse response)
   throws ServletException, IOException {
  doPost(request, response);
 }
 

 public void init(ServletConfig config) {
  // 在web.xml中设置的一个初始化参数
  savePath = config.getInitParameter("savePath");
  sc = config.getServletContext();
 }
 
 public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     response.reset();
	 String ph=request.getSession().getServletContext().getRealPath("/")+"WEB-INF\\pages\\code.jpg";
	 double number=Math.random()*10000;  
	 while (number<1000){
		 number=Math.random()*10000;
		 if (number>1000) break;
	 }// 设置response的Header	 }
	 int num=(int)number;
	 request.getSession().setAttribute("yz", String.valueOf(num));
	 boolean a=createMark(ph,String.valueOf(num),response);
 }
 public boolean createMark(String filePath, String markContent,HttpServletResponse response) throws ImageFormatException, IOException {  
		try {
     InputStream is=null;
		is = new FileInputStream(filePath);
//		is = new FileInputStream("d:/upload/code.jpg");
     
     
     //通过JPEG图象流创建JPEG数据流解码器
     JPEGImageDecoder jpegDecoder = JPEGCodec.createJPEGDecoder(is);
     //解码当前JPEG数据流，返回BufferedImage对象
     BufferedImage buffImg = jpegDecoder.decodeAsBufferedImage();
     //得到画笔对象
     Graphics g = buffImg.getGraphics();
     
     //创建你要附加的图象。
     //2.jpg是你的小图片的路径
//     ImageIcon imgIcon = new ImageIcon("2.jpg"); 
     
     //得到Image对象。
//     Image img = imgIcon.getImage();
     
     //将小图片绘到大图片上。
     //5,300 .表示你的小图片在大图片上的位置。
//     g.drawImage(img,5,330,null);
     
     
     
     //设置颜色。
	 double number1=Math.random()*255;  
	 double number2=Math.random()*255;  
	 double number3=Math.random()*255;  
	 Color cc =new Color((int)number1,(int)number2,(int)number3);
     g.setColor(cc);
     
     
     //最后一个参数用来设置字体的大小
     Font f = new Font("宋体",Font.BOLD,30);
     
     g.setFont(f);
     
     //10,20 表示这段文字在图片上的位置(x,y) .第一个是你设置的内容。
     g.drawString(markContent,10,30);
     
     g.dispose();
     
     
     
//     OutputStream os = new FileOutputStream("d:/upload/union.jpg");
     
     //创键编码器，用于编码内存中的图象数据。
     
//     JPEGImageEncoder en = JPEGCodec.createJPEGEncoder(os);
     OutputStream os=response.getOutputStream();
     JPEGImageEncoder en = JPEGCodec.createJPEGEncoder(os);
     en.encode(buffImg);
     is.close();
     os.flush();
     os.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     return true;  
 }  

 public void download(String path, HttpServletResponse response) {
     try {
         // path是指欲下载的文件的路径。
         File file = new File(path);
         // 取得文件名。
         String filename = file.getName();
         // 取得文件的后缀名。
         String ext = filename.substring(filename.lastIndexOf(".") + 1).toUpperCase();

         // 以流的形式下载文件。
         InputStream fis = new BufferedInputStream(new FileInputStream(path));
         byte[] buffer = new byte[fis.available()];
         fis.read(buffer);
         fis.close();
         // 清空response
         response.reset();
         // 设置response的Header
         response.addHeader("Content-Disposition", "attachment;filename=" + new String(filename.getBytes()));
         response.addHeader("Content-Length", "" + file.length());
         OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
         response.setContentType("application/octet-stream");
         toClient.write(buffer);
         toClient.flush();
         toClient.close();
     } catch (IOException ex) {
         ex.printStackTrace();
     }
 }


}
