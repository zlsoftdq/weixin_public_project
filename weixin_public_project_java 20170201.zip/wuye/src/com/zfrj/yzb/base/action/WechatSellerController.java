package com.zfrj.yzb.base.action;


import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.zfrj.base.controller.BaseController;
import com.zfrj.util.Md5Encrypt;
import com.zfrj.wechat.pojo.AccessToken;
import com.zfrj.wechat.pojo.JsapiTicket;
import com.zfrj.wechat.pojo.Template;
import com.zfrj.wechat.pojo.TemplateParam;
import com.zfrj.wechat.sendsms.SendSms;
import com.zfrj.wechat.service.WechatSellerService;
import com.zfrj.wechat.service.WechatUserService;
import com.zfrj.wechat.util.AliSnsInfo;
import com.zfrj.wechat.util.CommonUtil;
import com.zfrj.wechat.util.Decript;
import com.zfrj.wechat.util.GetOpenid;
import com.zfrj.wechat.util.SendTemplateUtil;
import com.zfrj.wechat.util.Web_Config;
import com.zfrj.wechat.util.WechatDeveloperInfo;
import com.zfrj.yzb.base.service.ICommonService;
import com.zfrj.yzb.base.service.IUserService;

/**
 * <p>
 * Title: 商户中心业务逻辑
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Company: zfrj
 * </p>
 *
 * @author gaofan
 * @date 2016年7月1日
 */

@Controller
@RequestMapping(value = "/seller")
public class WechatSellerController extends BaseController {
	@Autowired
	IUserService userService;
	@Autowired
	ICommonService commonService;
	@Autowired
	WechatDeveloperInfo wechatDeveloperInfo;
	@Autowired
	AliSnsInfo aliSnsInfo;
	@Autowired
	Web_Config web_Config;
	@Autowired
	WechatSellerService wechatSellerService;
	@Autowired
	WechatUserService wechatUserService;
	/*商户削减积分时，给小区住户发送短信验证码确认*/
	@RequestMapping(value = "/sendminscoresms")
	public void sendminscoresms(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	    String url=aliSnsInfo.url;
		String appkey=aliSnsInfo.appKey;
		String secret=aliSnsInfo.secret;
		String freeSignName=aliSnsInfo.freeSignName;
	    PrintWriter out = response.getWriter();
		String telno=request.getParameter("telno");
		String smsTemplateCode=request.getParameter("smstemplatecode");
		String code=SendSms.createVerificationCode();
		boolean result = SendSms.sendVerificationCode(url,appkey,secret,freeSignName,telno,smsTemplateCode, "{\"number\":\""+code+"\"}");
		if(result)
		{
			System.out.println(code);
			session.setAttribute("minscorecode", code);
			session.setMaxInactiveInterval(15*60);//15分钟有效
			out.print(1);
		}
		else{
			out.print(0);
		}
	    out.flush();
	    out.close();
	}
	/*加载积分列表页面*/
	@RequestMapping("/ajaxscorelist")
	public void ajxscorelist(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	    PrintWriter out = response.getWriter();
		String idcuser=session.getAttribute("idcuser").toString();
	   	int idx=Integer.parseInt(idcuser);
	   	String username=request.getParameter("customername");
	   	String userid=request.getParameter("countid");
	   	String phone=request.getParameter("usertel");
	   	String date1=request.getParameter("date1");
		String date2=request.getParameter("date2");
		if(username!=null||userid!=null||phone!=null||date1!=null||date2!=null){
			if(username!=""&&date1!=""&&date2!=""){
				List<Map<String, Object>> scorelist = wechatSellerService.getshopscorelist(username,idx,date1,date2);
			   	out.print(JSON.toJSONString(scorelist));
			}
			if(userid!=""&&date1!=""&&date2!=""){
				int countid=Integer.parseInt(userid);
				List<Map<String, Object>> scorelist = wechatSellerService.getshopscorelist(countid,idx,date1,date2);
			   	out.print(JSON.toJSONString(scorelist));
			}
			if(phone!=""&&date1!=""&&date2!=""){
				List<Map<String, Object>> scorelist = wechatSellerService.getshopscorelist(date1,date2,phone,idx);
			   	out.print(JSON.toJSONString(scorelist));
			}
		}
	   	else{
		   	List<Map<String, Object>> scorelist = wechatSellerService.getshopscorelist(idx);
		   	out.print(JSON.toJSONString(scorelist));
	   }
	    out.flush();
	    out.close();
	}
	/*加载积分列表页面*/
	@RequestMapping("/scorelist")
	public String scorelist(HttpServletRequest request) throws Exception{

		return "wechat4shopscorelist";
	}
	/*加载商户中心页面*/
	@RequestMapping("/shopcenter")
	public String shopcenter(HttpServletRequest request) throws Exception{

		return "wechat4shopcenter";
	}
	/*退出登录*/
	@RequestMapping("/logout")
	public String logout(HttpServletRequest request) throws Exception{
		request.getSession().removeAttribute("idcuser");
		return "redirect:/seller/login.htm";
	}
	/*加载物业报修商户申请页面*/
	@RequestMapping("/wyfixsellerapplication")
	public String wyfixsellerapplication(HttpServletRequest request) throws Exception{
		
		//request.setAttribute("user_openid", openid);
		return "wechat4wyfixsellerapplication";
	}
	/*加载修改商户信息页面*/
	@RequestMapping("/changeshopinfo")
	public String changeshop(HttpServletRequest request,HttpSession session) throws Exception{
		return "wechat4changeshopinfo";
	}
	/*修改商户信息ajax*/
	@RequestMapping(value = "/Validatechangeshopinfo")
	public void Validatechangeshopinfo(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	   	PrintWriter out = response.getWriter();
	   	String idcuser=session.getAttribute("idcuser").toString();
	   	int idx=Integer.parseInt(idcuser);
		String address=request.getParameter("address");
		String phone=request.getParameter("phone");
		String contacts=request.getParameter("contacts");
		String contacttel=request.getParameter("contacttel");
		String bz=request.getParameter("bz");
		String code=request.getParameter("code");
		String session4code=session.getAttribute("logincode").toString();
		if(session4code.equals(code)){
					int num=wechatSellerService.updateshopinfo(address,phone,contacts,contacttel,bz,idx);
					if(num>0){
						out.print(1);
					}
					else{
						out.print(-2);
					}
				}
			else{
				out.print(0);
			}
	    out.flush();
	    out.close();
	}
	/*加载商户信息ajax*/
	@RequestMapping("/ajaxlist4shopinfo")
	public void ajaxnodetb(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{
	 response.setContentType("text/Xml");
	 response.setCharacterEncoding("utf-8");
	 PrintWriter out = response.getWriter();
	 String idcuser=request.getParameter("userid");//session.getAttribute("idcuser").toString();
	 int idx=Integer.parseInt(idcuser);
	 List<Map<String,Object>> shopinfoSql = wechatSellerService.listuser(idx);
	 System.out.println(shopinfoSql.get(0));
	 System.out.println(JSON.toJSONString(shopinfoSql.get(0)));
	 out.print(JSON.toJSONString(shopinfoSql.get(0)));
	 out.flush();
	 out.close();
	}
	/*加载积分削减页面*/
	@RequestMapping("/shopminscore")
	public String shopminscore(HttpServletRequest request) throws Exception{
		String url_prefix =web_Config.url_prefix;
		weixin_scan_code(request,url_prefix+"wuye/seller/shopminscore.htm");
		return "wechat4shopminscore";
	}
	/*积分消减提交给客户审核ajax*/
	@RequestMapping(value = "/Validatetocustomerminscore")
	public void Validatetocustomerminscore(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	   	PrintWriter out = response.getWriter();
	   	String idcuser=session.getAttribute("idcuser").toString();
	   	int idx=Integer.parseInt(idcuser);
		String countid=request.getParameter("countid");
		String usertel=request.getParameter("usertel");
		String minmoney=request.getParameter("minmoney");
		String minreason=request.getParameter("minreason");
		int userid=-1;
		int num =-1;
		String openid="";
		String customername="";
		if(countid!=""){
			userid=Integer.parseInt(countid);
		}
		if(userid!=-1){
			List<Map<String,Object>> userSql = wechatSellerService.checkcustomer(userid);
			if(userSql.size()==1){
				usertel=(String)userSql.get(0).get("phone");
				openid=(String)userSql.get(0).get("openid");
				customername=(String)userSql.get(0).get("name");
				session.setAttribute("openid4user", openid);
				session.setAttribute("customername", customername);
				session.setAttribute("userid", userid);
				session.setAttribute("usertelno", usertel);
				session.setAttribute("minmoney", minmoney);
				session.setAttribute("minreason", minreason);
				out.print(1);
			}
			else{
				out.print(-1);
			}
		}
		else{
			List<Map<String,Object>> userSql = wechatSellerService.checkcustomer(usertel);
			if(userSql.size()==1){
				userid=(int)userSql.get(0).get("idusers");
				openid=(String)userSql.get(0).get("openid");
				customername=(String)userSql.get(0).get("name");
				session.setAttribute("openid4user", openid);
				session.setAttribute("customername", customername);
				session.setAttribute("userid", userid);
				session.setAttribute("usertelno", usertel);
				session.setAttribute("minmoney", minmoney);
				session.setAttribute("minreason", minreason);
				out.print(1);
			}
			else{
				out.print(-1);
			}
		}
	    out.flush();
	    out.close();
	}
	/*消减积分客户ajax*/
	@RequestMapping(value = "/Validate2customerminscore")
	public void Validate2customerminscore(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		List list1 = new ArrayList();
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	   	PrintWriter out = response.getWriter();
	   	String usertel=request.getParameter("usertel");
		String minmoney=request.getParameter("minmoney");
		int num =-1;
		float minmoney1=Float.parseFloat(minmoney);
		String code=request.getParameter("code");
		String session4userid=session.getAttribute("userid").toString();
		int userid=Integer.parseInt(session4userid);
		System.out.println(userid);
		String session4code=session.getAttribute("minscorecode").toString();
		String session4minreason=session.getAttribute("minreason").toString();
		String idcuser=session.getAttribute("idcuser").toString();
		String openid4user=session.getAttribute("openid4user").toString();
		String customername=session.getAttribute("customername").toString();
	   	int cuserid=Integer.parseInt(idcuser);
		if(session4code.equals(code)){
				list1=wechatSellerService.minscore2customer(cuserid, userid, minmoney1, session4minreason);
				num=(int)list1.get(0);
				String minscore=(String)list1.get(1);
				String totalscore=(String)list1.get(2);
				String shoptel=(String)list1.get(3);
				if(num>0){
					num=minscorenotice(openid4user,customername,minscore,session4minreason,totalscore,shoptel);
					out.print(1);
				}
				else if(num==-1){
					out.print(-1);
				}
				else{
					out.print(-2);
				}

		}
		else{
			out.print(0);
		}
	    out.flush();
	    out.close();
	}
	/*积分消减提交给物业审核ajax*/
	@RequestMapping(value = "/Validatetopropertyminscore")
	public void Validatetopropertyminscore(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	   	PrintWriter out = response.getWriter();
	   	String idcuser=session.getAttribute("idcuser").toString();
	   	int cuserid=Integer.parseInt(idcuser);
		String countid=request.getParameter("countid");
		String usertel=request.getParameter("usertel");
		String minmoney=request.getParameter("minmoney");
		float minmoney1=Float.parseFloat(minmoney);
		String minreason=request.getParameter("minreason");
		int userid=-1;
		int num =-1;
		if(countid!=""){
			userid=Integer.parseInt(countid);
		}
		if(userid!=-1){
			List<Map<String,Object>> userSql = wechatSellerService.checkcustomer(userid);
			if(userSql.size()!=1){
				out.print(-1);
			}
		}
		else{
			List<Map<String,Object>> userSql = wechatSellerService.checkcustomer(usertel);
			if(userSql.size()==1){
				userid=(int)userSql.get(0).get("idusers");
			}
			else{
				out.print(-1);
			}
		}
		num=wechatSellerService.minscore2property(cuserid, userid, minmoney1, minreason);
		if(num>0){
			out.print(1);
		}
		else if(num==-2){
			out.print(-2);
		}
		else{
			out.print(-3);
		}
	    out.flush();
	    out.close();
	}
	/*积分查询ajax*/
	@RequestMapping(value = "/ajax4querycustomerscore")
	public void ajax4querycustomerscore(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	   	PrintWriter out = response.getWriter();
	   	String idcuser=session.getAttribute("idcuser").toString();
	   	int cuserid=Integer.parseInt(idcuser);
	   	String customername=request.getParameter("customername");
		String countid=request.getParameter("countid");
		String date1=request.getParameter("date1");
		String date2=request.getParameter("date2");
		int userid=-1;
		int num =-1;
		if(countid!=""){
			userid=Integer.parseInt(countid);
		}
		String usertel=request.getParameter("usertel");
		if(customername!=""){
			List<Map<String,Object>> userSql = wechatSellerService.checkcustomer4customername(customername);
			if(userSql.size()==1){
				userid=(int)userSql.get(0).get("idusers");
				 num=wechatSellerService.queryscore(userid,date1,date2,cuserid);
				if(num>0){
					out.print("1");
				}
				else{
					out.print("-2");
				}
			}
			else{
				out.print("-1");
			}
		}
		if(countid!=""){
			List<Map<String,Object>> userSql = wechatSellerService.checkcustomer(userid);
			if(userSql.size()==1){
				num=wechatSellerService.queryscore(userid,date1,date2,cuserid);
				if(num>0){
					out.print(1);
				}
				else{
					out.print(-2);
				}
			}
			else{
				out.print(-1);
			}
		}
		if(usertel!=""){
			List<Map<String,Object>> userSql = wechatSellerService.checkcustomer(usertel);
			if(userSql.size()==1){
				userid=(int)userSql.get(0).get("idusers");
				num=wechatSellerService.queryscore(userid,date1,date2,cuserid);
				if(num>0){
					out.print(1);
					 System.out.println("jin");
				}
				else{
					out.print(-2);
				}
			}
			else{
				out.print(-1);
			}
		}
	    out.flush();
	    out.close();
	}
	/*加载积分查询页面*/
	@RequestMapping("/shopqueryscorelist")
	public String shopqueryscorelist(HttpServletRequest request) throws Exception{
		String url_prefix =web_Config.url_prefix;
		weixin_scan_code(request,url_prefix+"wuye/seller/shopqueryscorelist.htm");
		return "wechat4shopqueryscorelist";
	}
	/*增加积分ajax*/
	@RequestMapping(value = "/ajax4addscore")
	public void ajax4addscore(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		List list1 = new ArrayList();
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	   	PrintWriter out = response.getWriter();
	   	String idcuser=session.getAttribute("idcuser").toString();
	   	int cuserid=Integer.parseInt(idcuser);
		String countid=request.getParameter("countid");
		int userid=-1;
		int num =-1;
		if(countid!=""){
			userid=Integer.parseInt(countid);
		}
		String usertel=request.getParameter("usertel");
		String money=request.getParameter("money");
		float money1=Float.parseFloat(money);
		if(userid!=-1){
			List<Map<String,Object>> userSql = wechatSellerService.checkcustomer(userid);
			if(userSql.size()==1){
				String openid4user=(String)userSql.get(0).get("openid");
				String customername=(String)userSql.get(0).get("name");
				list1=wechatSellerService.addscore(cuserid,userid,money1);
				num=(int)list1.get(0);
				String shopname=(String)list1.get(1);
				String addscore=(String)list1.get(2);
				String getscoretime=(String)list1.get(3);
				String totalscore=(String)list1.get(4);
				if(num==0){
					num=addscorenotice(openid4user,customername,getscoretime,addscore,shopname,totalscore);
					if(num>0){
						out.print(1);
					}
					else{
						out.print(-2);
					}
				}
				else{
					out.print(-2);
				}
			}
			else{
				out.print(-1);
			}
		}
		else{
			List<Map<String,Object>> userSql = wechatSellerService.checkcustomer(usertel);
			if(userSql.size()==1){
				userid=(int)userSql.get(0).get("idusers");
				String openid4user=(String)userSql.get(0).get("openid");
				String customername=(String)userSql.get(0).get("name");
				list1=wechatSellerService.addscore(cuserid,userid,money1);
				num=(int)list1.get(0);
				String shopname=(String)list1.get(1);
				String addscore=(String)list1.get(2);
				String getscoretime=(String)list1.get(3);
				String totalscore=(String)list1.get(4);
				if(num==0){
					num=addscorenotice(openid4user,customername,getscoretime,addscore,shopname,totalscore);
					if(num>0){
						out.print(1);
					}
					else{
						out.print(-2);
					}
				}
				else{
					out.print(-2);
				}
			}
			else{
				out.print(-1);
			}
		}
	    out.flush();
	    out.close();
	}
	/*加载增加积分页面*/
	@RequestMapping("/shopaddscore")
	public String shopaddscore(HttpServletRequest request) throws Exception{
		String url_prefix =web_Config.url_prefix;
		weixin_scan_code(request,url_prefix+"wuye/seller/shopaddscore.htm");
		return "wechat4shopaddscore";
	}

	/*修改密码ajax*/
	@RequestMapping(value = "/Validatechangepwd")
	public void Validatechangepwd(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	   	PrintWriter out = response.getWriter();
	   	String idcuser=session.getAttribute("idcuser").toString();
	   	int idx=Integer.parseInt(idcuser);
		String oldpwd=request.getParameter("password");
		oldpwd=Md5Encrypt.md5(oldpwd);
		String newpwd=request.getParameter("newpassword");
		newpwd=Md5Encrypt.md5(newpwd);
		String code=request.getParameter("code");
		String session4code=session.getAttribute("logincode").toString();
		if(session4code.equals(code)){
				List<Map<String,Object>> userSql = wechatSellerService.checkuser(idx, oldpwd);
				if(userSql.size()==1){
					int num=wechatSellerService.updatepwd(newpwd, idx);
					if(num>0){
						out.print(1);
					}
					else{
						out.print(-2);
					}
				}
				else{
					out.print(-1);
				}
			}
			else{
				out.print(0);
			}
	    out.flush();
	    out.close();
	}
	/*加载修改密码页面*/
	@RequestMapping("/changepwd")
	public String changepwd(HttpServletRequest request) throws Exception{
		return "wechat4changeshoppwd";
	}
	/*验证登录ajax*/
	@RequestMapping(value = "/Validatelogin")
	public void Validatelogin(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	   	PrintWriter out = response.getWriter();
	   	String username=request.getParameter("username");
		String pwd=request.getParameter("password");
		String code=request.getParameter("code");
		pwd=Md5Encrypt.md5(pwd);
		String session4code=session.getAttribute("logincode").toString();
		if(session4code.equals(code)){
		List<Map<String,Object>> userSql = wechatSellerService.checklogin(username, pwd);
		if(userSql.size()==1){
			request.getSession().setAttribute("idcuser", userSql.get(0).get("idcuser"));
			out.print(1);
		}
		else{
			out.print(-1);
		}
		}
		else{
			out.print(0);
		}
	    out.flush();
	    out.close();
	}
	/*物业报修申请ajax*/
	@RequestMapping(value = "/Validatesellerapplicationwyfix")
	public void Validatesellerapplicationwyfix(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	   	PrintWriter out = response.getWriter();
		String fixname=request.getParameter("fixname");
		String fixaddress=request.getParameter("fixaddress");
		String fixtime=request.getParameter("fixtime");
		String problemcontents=request.getParameter("problemcontents");
		String contact=request.getParameter("contact");
		String contacttel=request.getParameter("contacttel");
		String openid=request.getParameter("openid");
		int num=wechatSellerService.sellerapplicationwyfix(fixname,fixaddress,fixtime,problemcontents,contact,contacttel,openid);
		if(num>0){
			out.print(1);
		}
		else{
			out.print(-2);
		}
		out.flush();
	    out.close();
	}
	/*加载商户中心登录页面*/
	@RequestMapping("/login")
	public String login(HttpServletRequest request) throws Exception{
		return "wechat4shoplogin";
	}
	/*加载削减积分提交客户审核*/
	@RequestMapping("/shopminscore2customer")
	public String shopminscore2customer(HttpServletRequest request,HttpSession session) throws Exception{
		return "wechat4shopminscore2customer";
	}
	/*封装方法*/
	/*获取AccessToken的值*/
	public String getAccessToken() throws Exception{
		String appId =wechatDeveloperInfo.appId;
		String appSecret = wechatDeveloperInfo.appSecret;
		AccessToken token = null;
		String accessToken=null;
		List<Map<String,Object>> accesstokenlist=wechatUserService.getAccessTokenList();
		int num = Integer.parseInt(accesstokenlist.get(0).get("expiresin").toString());
		if(num>=7200){
			token=CommonUtil.getToken(appId, appSecret);
			if (null != token) {
				accessToken=token.getAccessToken();
				wechatUserService.updateAccessToken(accessToken);
			}
		}
		else{
			accessToken=accesstokenlist.get(0).get("accesstoken").toString();
		}
		return accessToken;
	}
	/*获取jsapi_ticket的值*/
	public String getjsapi_ticket() throws Exception{
		String accesstoken=getAccessToken();
		JsapiTicket jsapitiket = null;
		String jsapi_ticket=null;
		List<Map<String,Object>> jsapi_ticketlist=wechatUserService.getJsapiTicketList();
		int num = Integer.parseInt(jsapi_ticketlist.get(0).get("expiresin").toString());
		if(num>=7200){
			jsapitiket=CommonUtil.getJsapiTicket(accesstoken);
			if (null != jsapitiket) {
				jsapi_ticket=jsapitiket.getJsapiTicket();
				wechatUserService.updateJsapiTicket(jsapi_ticket);
			}
		}
		else{
			jsapi_ticket=jsapi_ticketlist.get(0).get("jsapiticket").toString();
		}
		return jsapi_ticket;
	}
	/*调用微信扫一扫接口功能*/
	public void weixin_scan_code(HttpServletRequest request,String urlstr) throws Exception {
		String appId =wechatDeveloperInfo.appId;
		String ticket=getjsapi_ticket();
		String timestamp=Long.toString(new Date().getTime());
		String nonceStr=getRandomString(20);
		String url=urlstr;
		String jsapi_ticket="jsapi_ticket="+ticket+"&noncestr="+nonceStr+"&timestamp="+timestamp+"&url="+url;
		System.out.println(jsapi_ticket);
		String signature=Decript.SHA1(jsapi_ticket);
		System.out.println(signature);
		request.setAttribute("appId",appId);
		request.setAttribute("timestamp",timestamp);
		request.setAttribute("nonceStr",nonceStr);
	    request.setAttribute("signature",signature);
	}
	@RequestMapping(value = "/getsignature")
	public void getsignature(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	   	PrintWriter out = response.getWriter();
	   	String url=request.getParameter("url");
		String nonceStr=request.getParameter("noncestr");
		String ticket=request.getParameter("ticket");
		String timestamp=request.getParameter("timestamp");
		String jsapi_ticket=ticket+"&noncestr="+nonceStr+"&timestamp="+timestamp+"&url="+url;
		String signature=Decript.SHA1(jsapi_ticket);
		out.print("signature");
	    out.flush();
	    out.close();
	}
	/*积分增加通知*/
	public int addscorenotice(String openid4user,String customername,String getscoretime,String addscore,String shopname,String totalscore) throws Exception{
		Template tem=new Template();
		tem.setTemplateId("LQlJkZEThIKnoOr1GICvHYUs_ymRrY1cq3pB_yWdx4s");
		tem.setTopColor("#00DD00");
		tem.setToUser(openid4user);
		tem.setUrl("");

		List<TemplateParam> paras=new ArrayList<TemplateParam>();
		paras.add(new TemplateParam("first","亲爱的"+customername+"，您的积分账户有新增积分，具体内容如下:","#FF3333"));
		paras.add(new TemplateParam("keyword1",getscoretime,"#0044BB"));
		paras.add(new TemplateParam("keyword2",addscore,"#0044BB"));
		paras.add(new TemplateParam("keyword3","在商家"+shopname+"完成交易","#0044BB"));
		paras.add(new TemplateParam("keyword4",totalscore,"#0044BB"));
		paras.add(new TemplateParam("Remark","感谢您的使用!!!!","#AAAAAA"));
		tem.setTemplateParamList(paras);
		System.out.println(tem);
		String token= getAccessToken();
		boolean result=SendTemplateUtil.sendTemplateMsg(token,tem);
		if(result){
			return 1;
		}
		else{
			return 0;
		}

	}
	/*积分消减通知*/
	public int minscorenotice(String openid4user,String customername,String minscore,String minreason,String totalscore,String shoptel) throws Exception{
		Template tem=new Template();
		tem.setTemplateId("sCpw7NVHSeqlC7PYxJg55wjZGMfTsr6uOP2NHyHkAFw");
		tem.setTopColor("#00DD00");
		tem.setToUser(openid4user);
		tem.setUrl("");

		List<TemplateParam> paras=new ArrayList<TemplateParam>();
		paras.add(new TemplateParam("first","亲爱的"+customername+"，您的积分账户有积分消减，具体内容如下:","#FF3333"));
		paras.add(new TemplateParam("FieldName","消减原因","#0044BB"));
		paras.add(new TemplateParam("Account",minreason,"#0044BB"));
		paras.add(new TemplateParam("change","减去","#0044BB"));
		paras.add(new TemplateParam("CreditChange",minscore,"#0044BB"));
		paras.add(new TemplateParam("CreditTotal",totalscore,"#0044BB"));
		paras.add(new TemplateParam("Remark","如有疑问，请联系商家，联系电话："+shoptel+"；或联系物业三公司登峰家园物业分公司客服，客服电话：0459-8888888。","#AAAAAA"));

		tem.setTemplateParamList(paras);
		String token= getAccessToken();
		boolean result=SendTemplateUtil.sendTemplateMsg(token,tem);
		if(result){
			return 1;
		}
		else{
			return 0;
		}

	}
	public static String getRandomString(int length) { //length表示生成字符串的长度
	    String base = "abcdefghijklmnopqrstuvwxyz0123456789";
	    Random random = new Random();
	    StringBuffer sb = new StringBuffer();
	    for (int i = 0; i < length; i++) {
	        int number = random.nextInt(base.length());
	        sb.append(base.charAt(number));
	    }
	    return sb.toString();
	 }
}
