package com.zfrj.yzb.base.action;


import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.aspectj.weaver.ast.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.zfrj.base.controller.BaseController;
import com.zfrj.wechat.pojo.AccessToken;
import com.zfrj.wechat.pojo.Template;
import com.zfrj.wechat.pojo.TemplateParam;
import com.zfrj.wechat.sendsms.SendSms;
import com.zfrj.wechat.service.WechatUserService;
import com.zfrj.wechat.util.AliSnsInfo;
import com.zfrj.wechat.util.CommonUtil;
import com.zfrj.wechat.util.GetOpenid;
import com.zfrj.wechat.util.SendTemplateUtil;
import com.zfrj.wechat.util.WechatDeveloperInfo;
import com.zfrj.yzb.base.service.ICommonService;
import com.zfrj.yzb.base.service.IUserService;

/**
 * <p>
 * Title: 用户中心业务逻辑
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Company: zfrj
 * </p>
 * 
 * @author gaofan
 * @date 2016年7月1日
 */

@Controller
@RequestMapping(value = "/user")
public class WechatUserController extends BaseController {
	private static Logger logger = Logger.getLogger(Test.class);
	@Autowired
	IUserService userService;
	@Autowired
	ICommonService commonService;
	@Autowired
	WechatDeveloperInfo wechatDeveloperInfo;
	@Autowired
	AliSnsInfo aliSnsInfo;
	@Autowired
	WechatUserService wechatUserService;
	/* 发送短信验证码验证身份 */
	@RequestMapping(value = "/sendinitusersms")
	public void sendinitusersms(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
		String url=aliSnsInfo.url;
		String appkey=aliSnsInfo.appKey;
		String secret=aliSnsInfo.secret;
		String freeSignName=aliSnsInfo.freeSignName;
		PrintWriter out = response.getWriter();
		String telno=request.getParameter("telno");
		String smsTemplateCode=request.getParameter("smstemplatecode");
		String code=SendSms.createVerificationCode();		
		boolean result = SendSms.sendVerificationCode(url,appkey,secret,freeSignName,telno,smsTemplateCode, "{\"number\":\""+code+"\"}");
		if(result)
		{ 
			session.setAttribute("regusercode", code);
			session.setMaxInactiveInterval(15*60);//15分钟有效
			out.print(1);
		}
		else{
			out.print(0);
		}
	    out.flush();
	    out.close();
	}
	/*加载用户中心页面*/
	@RequestMapping("/index")
	public String index(HttpServletRequest request) throws Exception{
		return "wechat4userindex";
	}
	/*加载用户信息ajax*/
	@RequestMapping("/inituserindexinfo")
	public void inituserindexinfo(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{
	 response.setContentType("text/Xml");
	 response.setCharacterEncoding("utf-8");
	 PrintWriter out = response.getWriter();
	 String useropenid=request.getParameter("useropenid");//session.getAttribute("idcuser").toString();
	 List<Map<String, Object>> userinfoSql = wechatUserService.inituser(useropenid);
	 out.print(JSON.toJSONString(userinfoSql.get(0)));
	 out.flush();
	 out.close();
	}
	/*加载物业通知列表ajax*/
	@RequestMapping("/initwynoticelist")
	public void initwynoticelist(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{
	 response.setContentType("text/Xml");
	 response.setCharacterEncoding("utf-8");
	 PrintWriter out = response.getWriter();
	 List<Map<String, Object>> wynoticeSql = wechatUserService.initwynoticelist();
	 out.print(JSON.toJSONString(wynoticeSql));
	 out.flush();
	 out.close();
	}
	/*加载物业通知详情列表ajax*/
	@RequestMapping("/ajaxdetailnotice")
	public void detailnotice(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{
	 response.setContentType("text/Xml");
	 response.setCharacterEncoding("utf-8");
	 PrintWriter out = response.getWriter();
	 String noteid=request.getParameter("idnote");
	 int noteidx=Integer.parseInt(noteid);
	 List<Map<String, Object>> detailnoticelistSql = wechatUserService.initwynoticelist(noteidx);
	 out.print(JSON.toJSONString(detailnoticelistSql));
	 System.out.println(JSON.toJSONString(detailnoticelistSql));
	 out.flush();
	 out.close();
	}
	/*加载物业通知页面*/
	@RequestMapping("/wynotice")
	public String wynotice(HttpServletRequest request) throws Exception{
		return "wechat4wynotice";
	}
	/*加载物业通知详情页面*/
	@RequestMapping("/detailnotice")
	public String detailnotice(HttpServletRequest request) throws Exception{
		return "wechat4detailwynotice";
	}
	/*加载物业报修信息详情页面*/
	@RequestMapping("/wyfixuserdetail")
	public String wyfixuserdetail(HttpServletRequest request) throws Exception{
		return "wechat4wyfixuserdetails";
	}
	/*加载物业报修用户申请页面*/
	@RequestMapping("/wyfixuserapplication")
	public String wyfixuserapplication(HttpServletRequest request) throws Exception{
		return "wechat4wyfixuserapplication";
	}
	/*用户积分查询ajax*/
	@RequestMapping(value = "/ajax4queryscore")
	public void ajax4queryscore(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	   	PrintWriter out = response.getWriter();
	   	String shopname=request.getParameter("shopname");
		String useropenid=request.getParameter("useropenid");
		String date1=request.getParameter("date1");
		String date2=request.getParameter("date2");
		int num=wechatUserService.queryscore(shopname,date1,date2,useropenid);
		if(num>0){
			out.print(1);
		}
		else{
			out.print(-2);
		}
		
	    out.flush();
	    out.close();
	}
	/*加载用户查询积分页面*/
	@RequestMapping("/userqueryscorelist")
	public String userqueryscorelist(HttpServletRequest request) throws Exception{
		return "wechat4userqueryscorelist";
	}
	/*加载消减积分列表页面*/
	@RequestMapping("/userminscorelist")
	public String userminscorelist(HttpServletRequest request) throws Exception{
		return "wechat4userminscorelist";
	}
	/*加载物业报修列表页面*/
	@RequestMapping("/userwyfixlist")
	public String userwyfixlist(HttpServletRequest request) throws Exception{
		return "wechat4userfixlist";
	}
	/*加载商户列表页面*/
	@RequestMapping("/shoplist")
	public String shoplist(HttpServletRequest request) throws Exception{
		return "wechat4usersellerlist";
	}
	/*加载积分列表页面*/
	@RequestMapping("/ajaxsellerlist")
	public void ajaxsellerlist(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	    PrintWriter out = response.getWriter();
		List<Map<String, Object>> scorelist = wechatUserService.getusersellerlist();
	   	out.print(JSON.toJSONString(scorelist));
	    out.flush();
	    out.close();
	}
	/*加载消减积分列表ajax*/
	@RequestMapping("/inituserminscorelist")
	public void inituserminscorelist(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{
	 response.setContentType("text/Xml");
	 response.setCharacterEncoding("utf-8");
	 PrintWriter out = response.getWriter();
	 String useropenid=request.getParameter("useropenid");//session.getAttribute("idcuser").toString();
	 List<Map<String, Object>> userminscorelistSql = wechatUserService.inituserminscorelist(useropenid);
	 out.print(JSON.toJSONString(userminscorelistSql));
	 out.flush();
	 out.close();
	}
	/*加载积分兑换列表页面*/
	@RequestMapping("/exchangescorelist")
	public String exchangescorelist(HttpServletRequest request) throws Exception{
		return "wechat4userexchangescorelist";
	}
	/*加载兑换积分列表ajax*/
	@RequestMapping("/inituserinfo")
	public void inituserinfo(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{
	 response.setContentType("text/Xml");
	 response.setCharacterEncoding("utf-8");
	 PrintWriter out = response.getWriter();
	 String useropenid=request.getParameter("useropenid");//session.getAttribute("idcuser").toString();
	 List<Map<String, Object>> inituserinfolistSql = wechatUserService.inituserinfolist(useropenid);
	 out.print(JSON.toJSONString(inituserinfolistSql));
	 out.flush();
	 out.close();
	}
	/*加载用户信息修改页面*/
	@RequestMapping("/changeuserinfo")
	public String changeuserinfo(HttpServletRequest request) throws Exception{
		return "wechat4changeuserinfo";
	}
	/*加载用户信息修改列表ajax*/
	@RequestMapping(value = "/Validatechangeuserinfo")
	public void Validatechangeuserinfo(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	   	PrintWriter out = response.getWriter();
		String username=request.getParameter("username");
		String phone=request.getParameter("phone");
		String useroilid=request.getParameter("useroilno");
		String address=request.getParameter("address");
		String isdistrict=request.getParameter("isdistrict");
		String recommentel=request.getParameter("recommentel");
		String openid=request.getParameter("openid");
		String code=request.getParameter("code");
		String session4code=session.getAttribute("regusercode").toString();
		if(session4code.equals(code)){
				int num=wechatUserService.changeuserinfo(username,phone,useroilid,address,isdistrict,recommentel,openid);
				if(num>0){
					out.print(1);
				}
				else{
					out.print(-2);
				}
			}
			else{
				out.print(0);
			}
	    out.flush();
	    out.close();
	}
	@RequestMapping("/initexchangescorelist")
	public void initexchangescorelist(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{
	 response.setContentType("text/Xml");
	 response.setCharacterEncoding("utf-8");
	 PrintWriter out = response.getWriter();
	 String useropenid=request.getParameter("useropenid");//session.getAttribute("idcuser").toString();
	 List<Map<String, Object>> userinitexchangescorelistSql = wechatUserService.initexchangescorelist(useropenid);
	 out.print(JSON.toJSONString(userinitexchangescorelistSql));
	 out.flush();
	 out.close();
	}
	/*加载积分列表页面*/
	@RequestMapping("/ajaxscorelist")
	public void ajxscorelist(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	    PrintWriter out = response.getWriter();
		String useropenid=request.getParameter("useropenid");//session.getAttribute("user_openid").toString();
	   	String shopname=request.getParameter("shopname");
	   	String date1=request.getParameter("date1");
		String date2=request.getParameter("date2");
		if(shopname!=null||date1!=null||date2!=null){
			if(shopname!=""&&date1!=""&&date2!=""){
				List<Map<String, Object>> scorelist = wechatUserService.getsuserscorelist(useropenid,shopname,date1,date2);
			   	out.print(JSON.toJSONString(scorelist));
			}
		}   	
	   	else{	
		   	List<Map<String, Object>> scorelist = wechatUserService.getuserscorelist(useropenid);
		   	out.print(JSON.toJSONString(scorelist));
	   }
	    out.flush();
	    out.close();
	}
	/*加载用户积分列表页面*/
	@RequestMapping("/userscorelist")
	public String userscorelist(HttpServletRequest request) throws Exception{
		return "wechat4userscorelist";
	}
	/*关注时加载补全您的基础信息*/
	@RequestMapping("/inituser")
	public String inituser(HttpServletRequest request) throws Exception{
		String openid=request.getParameter("openid");
		//request.setAttribute("user_openid", openid);
		return "wechat4inituserinfo";
	}	
	/*加载补全您的基础信息*/
	@RequestMapping("/adduser")
	public String inituserinfo(HttpServletRequest request) throws Exception{
		String appId =wechatDeveloperInfo.appId;
		String appSecret = wechatDeveloperInfo.appSecret;
		String code=request.getParameter("code");
		String openid=GetOpenid.getOpenId(code, appId, appSecret);
		request.setAttribute("user_openid", openid);
		return "wechat4inituserinfo";
	}	
	/*获取openid的ajax*/
	@RequestMapping(value = "/getopenidajax")
	public void getopenidajax(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	   	PrintWriter out = response.getWriter();
	   	String appId =wechatDeveloperInfo.appId;
		String appSecret = wechatDeveloperInfo.appSecret;
		String code=request.getParameter("code");
		String openid=GetOpenid.getOpenId(code, appId, appSecret);
		out.print(openid);
	    out.flush();
	    out.close();
	}
	/*补全您的基础信息ajax*/
	@RequestMapping(value = "/Validateadduserinfo")
	public void Validateadduserinfo(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	   	PrintWriter out = response.getWriter();
		String username=request.getParameter("username");
		String phone=request.getParameter("phone");
		String useroilid=request.getParameter("useroilno");
		String address=request.getParameter("address");
		String addressid="010505";
		String isdistrict=request.getParameter("isdistrict");
		String recommentel=request.getParameter("recommentel");
		String openid=request.getParameter("openid");
		String code=request.getParameter("code");
		String session4code=session.getAttribute("regusercode").toString();
		if(session4code.equals(code)){
					int num=wechatUserService.adduserinfo(username,phone,useroilid,address,addressid,isdistrict,recommentel,openid);
					if(num>0){
						out.print(1);
					}
					else{
						out.print(-2);
					}
				}
			else{
				out.print(0);
			}
	    out.flush();
	    out.close();
	}
	/*物业报修申请ajax*/
	@RequestMapping(value = "/Validateuserapplicationwyfix")
	public void Validateuserapplicationwyfix(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	   	PrintWriter out = response.getWriter();
		String fixname=request.getParameter("fixname");
		String fixaddress=request.getParameter("fixaddress");
		String fixtime=request.getParameter("fixtime");
		String problemcontents=request.getParameter("problemcontents");
		String contact=request.getParameter("contact");
		String contacttel=request.getParameter("contacttel");
		String openid=request.getParameter("openid");
		int num=wechatUserService.userapplicationwyfix(fixname,fixaddress,fixtime,problemcontents,contact,contacttel,openid);
		if(num==0){
			out.print(1);
		}
		else{
			out.print(-2);
		}
		out.flush();
	    out.close();
	}
	/*判断用户是否补全基础信息*/
	@RequestMapping("/checkuseropenid")
	public void checkuseropenid(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	    PrintWriter out = response.getWriter();
		String useropenid=request.getParameter("openid");
		List<Map<String,Object>> userSql = wechatUserService.checkuser(useropenid);
		if(userSql.size()==1){
			out.print(1);
		}
		else if(userSql.size()==0){
			out.print(0);
		}
		else{
			out.print(-1);
		}
		 out.flush();
		 out.close();
	
	}
	/*封装方法*/
	/*获取AccessToken的值*/
	public String getAccessToken() throws Exception{
		String appId =wechatDeveloperInfo.appId;
		String appSecret = wechatDeveloperInfo.appSecret;
		AccessToken token = null;
		String accessToken=null;
		List<Map<String,Object>> accesstokenlist=wechatUserService.getAccessTokenList();
		int num = Integer.parseInt(accesstokenlist.get(0).get("expiresin").toString());
		if(num>=7200){
			token=CommonUtil.getToken(appId, appSecret);
			if (null != token) {
				accessToken=token.getAccessToken();
				wechatUserService.updateAccessToken(accessToken);
			}
		}
		else{
			accessToken=accesstokenlist.get(0).get("accesstoken").toString();
		}
		return accessToken;		
	}
	/*用户评分通知*/
	public int userevaluation4shopnotice(String openid4shop,String shopcontactname,String evaluationtime,String userid) throws Exception{
		Template tem=new Template();  
		tem.setTemplateId("-O-eYbXRjGJwWyubcXP4WfzvetB0TpADv1XuCjg12Vk");  
		tem.setTopColor("#00DD00"); 
		tem.setToUser(openid4shop);  
		tem.setUrl("");  	          
		List<TemplateParam> paras=new ArrayList<TemplateParam>();  
		paras.add(new TemplateParam("first","亲爱的"+shopcontactname+"商户，有用户对您的服务进行评分。","#FF3333"));  
		paras.add(new TemplateParam("keyword1","用户ID:"+userid,"#0044BB"));  
		paras.add(new TemplateParam("keyword2",evaluationtime,"#0044BB"));  		          
		tem.setTemplateParamList(paras);  
		String token= getAccessToken();        
		boolean result=SendTemplateUtil.sendTemplateMsg(token,tem);  
		if(result){
			return 1;
		}
		else{
			return 0;
		}
		
	}
}
