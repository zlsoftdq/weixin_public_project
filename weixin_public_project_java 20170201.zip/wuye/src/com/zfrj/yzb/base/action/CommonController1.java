/**
 * <p>Title: CommonController.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: zfrj</p>
 * @author yzb
 * @date 2015年8月6日
 * @version 1.0
 */
package com.zfrj.yzb.base.action;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zfrj.base.controller.BaseController;
import com.zfrj.util.COMMON;
import com.zfrj.util.Md5Encrypt;
import com.zfrj.wechat.pojo.AccessToken;
import com.zfrj.wechat.pojo.Template;
import com.zfrj.wechat.pojo.TemplateParam;
import com.zfrj.wechat.service.WechatSellerService;
import com.zfrj.wechat.service.WechatUserService;
import com.zfrj.wechat.util.AliSnsInfo;
import com.zfrj.wechat.util.CommonUtil;
import com.zfrj.wechat.util.SendTemplateUtil;
import com.zfrj.wechat.util.WechatDeveloperInfo;
import com.zfrj.yzb.base.bean.to.User;
import com.zfrj.yzb.base.service.ICommonService;
import com.zfrj.yzb.base.service.IUserService;

/**
 * <p>
 * Title: 基础的控制器
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Company: zfrj
 * </p>
 *
 * @author yzb
 * @date 2015年8月6日
 */


@Controller
@RequestMapping(value = "/app")
public class CommonController1 extends BaseController {
	@Autowired
	IUserService userService;
	@Autowired
	ICommonService commonService;
	@Autowired
	WechatDeveloperInfo wechatDeveloperInfo;
	@Autowired
	AliSnsInfo aliSnsInfo;
	@Autowired
	WechatSellerService wechatSellerService;
	@Autowired
	WechatUserService wechatUserService;

	/**
	 *
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/index")
	public String index(HttpServletRequest request,
			HttpServletResponse response){
			return "index";
	}

		/**
	 *
	 * @param request
	 * @param response
	 */

	@RequestMapping(value = "/judgename")
	public void judgename(HttpServletRequest request,
			HttpServletResponse response){
		try{
			if( COMMON.isnull(request.getParameter("name"))
					)
			{
				this.responseFail(response, -32602, "参数无效", "指定参数不符合服务接口定义");
			}
			String name = request.getParameter("name").toString();

			Integer result = userService.judgeName(name);

			JSONObject obj = new JSONObject();
			obj.accumulate("result", result);
			String format_json = this.FormatJson(0, "", Object2Json(obj));
			this.responseSuccess(response, format_json, 0);
			return;
		}
		catch(Exception e){
			e.printStackTrace();
			this.responseFail(response, -32602, "服务器有点忙，请过会重试", "");
			return ;
		}
	}

	/**
	 *
	 * @param request
	 * @param response
	 */

	@RequestMapping(value = "/judgetelephone")
	public void judgetelephone(HttpServletRequest request,
			HttpServletResponse response){
		try{
			if( COMMON.isnull(request.getParameter("telephone"))
					)
			{
				this.responseFail(response, -32602, "参数无效", "指定参数不符合服务接口定义");
			}
			String telephone = request.getParameter("telephone").toString();

			Integer result = userService.judgeTelephone(telephone);

			JSONObject obj = new JSONObject();
			obj.accumulate("result", result);
			String format_json = this.FormatJson(0, "", Object2Json(obj));
			this.responseSuccess(response, format_json, 0);
			return;
		}
		catch(Exception e){
			e.printStackTrace();
			this.responseFail(response, -32602, "服务器有点忙，请过会重试", "");
			return ;
		}
	}

	/**
	 *
	 * @param request
	 * @param response
	 */

	@RequestMapping(value = "/judgeemail")
	public void judgeemail(HttpServletRequest request,
			HttpServletResponse response){
		try{
			if( COMMON.isnull(request.getParameter("email"))
					)
			{
				this.responseFail(response, -32602, "参数无效", "指定参数不符合服务接口定义");
			}
			String email = request.getParameter("email").toString();

			Integer result = userService.judgeEmail(email);

			JSONObject obj = new JSONObject();
			obj.accumulate("result", result);
			String format_json = this.FormatJson(0, "", Object2Json(obj));
			this.responseSuccess(response, format_json, 0);
			return;
		}
		catch(Exception e){
			e.printStackTrace();
			this.responseFail(response, -32602, "服务器有点忙，请过会重试", "");
			return ;
		}
	}


	/**
	 *
	 * @param request
	 * @param response
	 */

	@RequestMapping(value = "/login")
	public String login(HttpServletRequest request,
			HttpServletResponse response){
			return "login";

	}
	/*2016-8-23 由于需求变更，登录部分由高凡更改业务逻辑*/
	@RequestMapping(value = "/check")
	public String check(HttpServletRequest request,
			HttpServletResponse response){
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String sql="";
		try{
		sql= "select idusers,username from systemuser where username='"+username+"' and password='"+Md5Encrypt.md5(password)+"'";
		System.out.println(sql);
		List<Map<String,Object>> userSql = userService.findBySQLToMap(sql,null,-1,-1);
		int len=userSql.size();
		if(len==1){
			request.getSession().setAttribute("user", userSql);
			request.getSession().setAttribute("userid", userSql.get(0).get("idusers"));
			request.getSession().setAttribute("username", userSql.get(0).get("username"));
			return "main_win";
		}
		else
		{
			request.setAttribute("error", "用户名或密码错误！");
			return "login";
		}
		}catch(Exception e){
			request.setAttribute("error", "服务器异常！");
			return "login";

		}

	}

	/**
	 *
	 * @param request
	 * @param response
	 */

	@RequestMapping(value = "/logout")
	public String logout(HttpServletRequest request,
			HttpServletResponse response){
		try{
			request.getSession().removeAttribute("user");
			request.getSession().removeAttribute("userid");
			request.getSession().removeAttribute("username");
			return "login";
		}
		catch(Exception e){
			e.printStackTrace();
			this.responseFail(response, -32602, "服务器有点忙，请过会重试", "");
			return "error";
		}
	}

	@RequestMapping(value ="cuserclasslist")
	public String cuserclasslist(HttpServletRequest request,HttpServletResponse response) throws Exception{
		List<Map<String,Object>> userSql = (List<Map<String,Object>>)request.getSession().getAttribute("user");
		request.setAttribute("userid", userSql.get(0).get("idusers"));
       return "cuserclasslist";
	}

	@RequestMapping(value ="listclassjson")
	@ResponseBody
	public JSONObject listclassjson(HttpServletRequest request,HttpServletResponse response) throws Exception{
		JSONObject result = new JSONObject();
		String r=request.getParameter("rows");
		String p=request.getParameter("page");
		int rows =Integer.parseInt(r);
		int page = Integer.parseInt(p);
//		List<Map<String,Object>> userSql = userService.findBySQLToMap(sql,null,-1,-1);
		List<Map<String,Object>> role = userService.findBySQLToMap("select * from cclass",null,(page-1)*rows,rows);
		List<Map<String,Object>> role2 = userService.findBySQLToMap("select count(*) as cnt from cclass",null,-1,-1);
		String num = role2.get(0).get("cnt").toString();
		 int num1= Integer.parseInt(num);
	//	List<Map<String, Object>> role=zs.ajaxlistarea(rows,page);
		 Map<String, Object> jsonMap = new HashMap<String, Object>();
		 jsonMap.put("rows", role);
		 jsonMap.put("total", num1);
		 result = JSONObject.fromObject(jsonMap);
       return result;
	}

	@RequestMapping(value ="cuserlist")
	public String cuserlist(HttpServletRequest request,HttpServletResponse response) throws Exception{
		List<Map<String,Object>> userSql = userService.findBySQLToMap("select * from cclass",null,-1,-1);;
		request.setAttribute("cclass", userSql);
       return "cuserlist";
	}
	@RequestMapping(value ="cuserlists")
	@ResponseBody
	public JSONObject cuserlists(HttpServletRequest request,HttpServletResponse response) throws Exception{
		JSONObject result = new JSONObject();
		String r=request.getParameter("rows");
		String p=request.getParameter("page");
		int rows =Integer.parseInt(r);
		int page = Integer.parseInt(p);
		List<Map<String,Object>> role = userService.findBySQLToMap("select * from cuserview",null,(page-1)*rows,rows);
		List<Map<String,Object>> role2 = userService.findBySQLToMap("select count(*) as cnt from cuserview",null,-1,-1);
		String num = role2.get(0).get("cnt").toString();
		 int num1= Integer.parseInt(num);
		 Map<String, Object> jsonMap = new HashMap<String, Object>();
		 jsonMap.put("rows", role);
		 jsonMap.put("total", num1);
		 System.out.println(num1);
		 result = JSONObject.fromObject(jsonMap);
		 System.out.println(result);
       return result;
	}
	@RequestMapping(value = "/addcuserclass")
	public void addcuserclass(HttpServletRequest request,HttpServletResponse response){
		response.setContentType("text/Xml");
		 response.setCharacterEncoding("utf-8");
		 PrintWriter out=null;
		try {
			out = response.getWriter();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String classname = request.getParameter("classname");
		String percentage = request.getParameter("percentage");
	     String idx=userService.getTableId("cclass");
		try {
			int i=userService.execSql("insert into cclass(idcclass,percentage,classname) values("+idx+","+percentage+",'"+classname+"')");
			 out.print(i);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 out.flush();
		 out.close();
		}

	@RequestMapping(value = "/deletecuserclass")
	public void deletecuserclass(HttpServletRequest request,HttpServletResponse response){
		response.setContentType("text/Xml");
		 response.setCharacterEncoding("utf-8");
		 PrintWriter out=null;
		try {
			out = response.getWriter();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String id = request.getParameter("id");
		try {
			int i=userService.execSql("delete  from cclass where idcclass="+id);
			 out.print(i);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 out.flush();
		 out.close();
		}

	@RequestMapping(value = "/modicuserclass")
	public void modicuserclass(HttpServletRequest request,HttpServletResponse response){
		response.setContentType("text/Xml");
		 response.setCharacterEncoding("utf-8");
		 PrintWriter out=null;
		try {
			out = response.getWriter();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String id = request.getParameter("id");
		String lx = request.getParameter("lx");
		String per = request.getParameter("per");
		try {
			int i=userService.execSql("update cclass set classname='"+lx+"',percentage="+per+" where idcclass="+id);
			 out.print(i);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 out.flush();
		 out.close();
		}

	@RequestMapping(value ="cuserclass")
	@ResponseBody
	public String cuserclass(HttpServletRequest request,HttpServletResponse response) throws Exception{
		List<Map<String,Object>> list = userService.findBySQLToMap("select * from cclass",null,-1,-1);
		   JSONArray json2 = new JSONArray();
	      for(int k=0;k<list.size();k++){
		        JSONObject json1=new JSONObject();
		        HashMap adu=(HashMap)list.get(k);
		        String name=adu.get("classname").toString();
		        int Id=Integer.parseInt(adu.get("idcclass").toString());
		             json1.put("text", name);
		             json1.put("id", Id);
		         json2.add(json1);
		        }
		        String s=json2.toString();
				return s;
	}

//	 name lx addr con phone
		@RequestMapping(value = "/addcuser")
		public void addcuser(HttpServletRequest request,HttpServletResponse response){
			response.setContentType("text/Xml");
			 response.setCharacterEncoding("utf-8");
				String name=request.getParameter("name");
				String lx=request.getParameter("lx");
				String addr=request.getParameter("addr");
				String con=request.getParameter("con");
				String phone=request.getParameter("phone");
				String username=request.getParameter("uername");
				String password=request.getParameter("password");
			 PrintWriter out=null;
			try {
				out = response.getWriter();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     String idx=userService.getTableId("cuser");
				List<Map<String,Object>> ss = (List<Map<String,Object>>)request.getSession().getAttribute("user");
			try {
		//		  `idcuser` int(11) NOT NULL,
		//		  `name` varchar(45) DEFAULT NULL,
		//		  `classid` int(11) DEFAULT NULL,
		//		  `address` varchar(45) DEFAULT NULL,
		//		  `phone` varchar(45) DEFAULT NULL,
		//		  `depaid` int(11) DEFAULT NULL,
		//		  `status` varchar(45) DEFAULT '有效',
		//		  `contacts` varchar(45) DEFAULT NULL,

				int i=userService.execSql("insert into cuser(idcuser,name,classid,address,phone,depaid,contacts,uname,password) values("+idx+",'"+name+"',"+lx+",'"+addr+"','"+phone+"',"+ss.get(0).get("depaid")+",'"+con+"','"+username+"','"+password+"')");
				 out.print(i);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 out.flush();
			 out.close();
			}


		@RequestMapping(value = "/modicuser")
		public void modicuser(HttpServletRequest request,HttpServletResponse response){
			response.setContentType("text/Xml");
			 response.setCharacterEncoding("utf-8");
			 PrintWriter out=null;
			try {
				out = response.getWriter();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//"id":a,"uname":b,"ulx":c,"uaddr":e,"ucon":e,"uphone":f,"ustatus":g
			String id = request.getParameter("id");
			String uname = request.getParameter("uname");
			String ulx = request.getParameter("ulx");
			String uaddr = request.getParameter("uaddr");
			String ucon = request.getParameter("ucon");
			String uphone = request.getParameter("uphone");
			String ustatus = request.getParameter("ustatus");
			try {
				int i=userService.execSql("update cuser set name='"+uname+"',classid="+ulx+",address='"+uaddr+"',contacts='"+ucon+"',phone='"+uphone+"',status='"+ustatus+"' where idcuser="+id);
				 out.print(i);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 out.flush();
			 out.close();
			}

		@RequestMapping(value = "/deleterec")
		public void deletecuser(HttpServletRequest request,HttpServletResponse response){
			response.setContentType("text/Xml");
			 response.setCharacterEncoding("utf-8");
			 PrintWriter out=null;
			try {
				out = response.getWriter();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String id = request.getParameter("id");
			String tb = request.getParameter("tb");
			String fd = request.getParameter("fd");
			try {
				int i=userService.execSql("delete  from "+tb+" where "+fd+"="+id);
				 out.print(i);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 out.flush();
			 out.close();
			}


		@RequestMapping(value ="userscorelist")
		public String userscorelist(HttpServletRequest request,HttpServletResponse response) throws Exception{
			List<Map<String,Object>> userSql = userService.findBySQLToMap("select * from cclass",null,-1,-1);;
			request.setAttribute("cclass", userSql);
			 request.getSession().setAttribute("yhjfcx", "");
	       return "userscorelist";
		}
		@RequestMapping(value ="cuserscorelist")
		public String cuserscorelist(HttpServletRequest request,HttpServletResponse response) throws Exception{
			List<Map<String,Object>> userSql = userService.findBySQLToMap("select * from cclass",null,-1,-1);;
			request.setAttribute("cclass", userSql);
			 request.getSession().setAttribute("yhjfcx", "");
	       return "cuserscorelist";
		}
		@RequestMapping(value ="gainscorelist")
		public String gainscorelist(HttpServletRequest request,HttpServletResponse response) throws Exception{
			 
	       return "wygainscorelist";
		}
		@RequestMapping(value ="userscorelistcx")
		public String userscorelistcx(HttpServletRequest request,HttpServletResponse response) throws Exception{
			List<Map<String,Object>> userSql = userService.findBySQLToMap("select * from addresslist",null,-1,-1);;
			request.setAttribute("cclass", userSql);
			String name=request.getParameter("name");
			String lx=request.getParameter("lx");
			String dz=request.getParameter("dz");
			 String tj=" where username like '%"+name+"%' and address like '%"+dz+"%' and classname like '%"+lx+"%'";
			 request.getSession().setAttribute("yhjfcx", tj);
	       return "userscorelist";
		}
		@RequestMapping(value ="cuserinsdeclist")
		public String userinsdeclist(HttpServletRequest request,HttpServletResponse response) throws Exception{
			List<Map<String,Object>> userSql = userService.findBySQLToMap("select * from cclass",null,-1,-1);;
			request.setAttribute("cclass", userSql);
	       return "cuserinsdeclist";
		}
		@RequestMapping(value ="cuserinsdeclist2")
		public String userinsdeclist2(HttpServletRequest request,HttpServletResponse response) throws Exception{
			List<Map<String,Object>> userSql = userService.findBySQLToMap("select * from cclass",null,-1,-1);;
			request.setAttribute("cclass", userSql);
	       return "cuserinsdeclist2";
		}
		@RequestMapping(value ="cuserinsdeclistsh2")
		public String userinsdeclistsh2(HttpServletRequest request,HttpServletResponse response) throws Exception{
			List<Map<String,Object>> userSql = userService.findBySQLToMap("select * from cclass",null,-1,-1);;
			request.setAttribute("cclass", userSql);
	       return "cuserinsdeclistsh2";
		}

		@RequestMapping(value ="scorelist")
		@ResponseBody
		public JSONObject scorelist(HttpServletRequest request,HttpServletResponse response) throws Exception{
			JSONObject result = new JSONObject();
			String r=request.getParameter("rows");
			String p=request.getParameter("page");
			int rows =Integer.parseInt(r);
			int page = Integer.parseInt(p);
			String tj=request.getSession().getAttribute("yhjfcx").toString();
			List<Map<String,Object>> role = userService.findBySQLToMap("select *,CONCAT(YEAR(scoreview.dt),'年',MONTH(scoreview.dt),'月',DAY(scoreview.dt),'日', ' ',IF(LENGTH(HOUR(scoreview.dt))=1,CONCAT(0,HOUR(scoreview.dt)),HOUR(scoreview.dt)),':',IF(LENGTH(MINUTE(scoreview.dt))=1,CONCAT(0,MINUTE(scoreview.dt)),MINUTE(scoreview.dt)),':',IF(LENGTH(SECOND(scoreview.dt))=1,CONCAT(0,SECOND(scoreview.dt)),SECOND(scoreview.dt))) AS dt1  from scoreview"+tj,null,(page-1)*rows,rows);
			List<Map<String,Object>> role2 = userService.findBySQLToMap("select count(*) as cnt from scoreview"+tj,null,-1,-1);
			String num = role2.get(0).get("cnt").toString();
			 int num1= Integer.parseInt(num);
			 Map<String, Object> jsonMap = new HashMap<String, Object>();
			 jsonMap.put("rows", role);
			 jsonMap.put("total", num1);
			 result = JSONObject.fromObject(jsonMap);
	       return result;
		}
		@RequestMapping(value ="getgainscorelist")
		@ResponseBody
		public JSONObject getgainscorelist(HttpServletRequest request,HttpServletResponse response) throws Exception{
			JSONObject result = new JSONObject();
			String r=request.getParameter("rows");
			String p=request.getParameter("page");
			int rows =Integer.parseInt(r);
			int page = Integer.parseInt(p);
			List<Map<String,Object>> role = userService.findBySQLToMap("select *,CONCAT(YEAR(gainscoreview.dt),'年',MONTH(gainscoreview.dt),'月',DAY(gainscoreview.dt),'日', ' ',IF(LENGTH(HOUR(gainscoreview.dt))=1,CONCAT(0,HOUR(gainscoreview.dt)),HOUR(gainscoreview.dt)),':',IF(LENGTH(MINUTE(gainscoreview.dt))=1,CONCAT(0,MINUTE(gainscoreview.dt)),MINUTE(gainscoreview.dt)),':',IF(LENGTH(SECOND(gainscoreview.dt))=1,CONCAT(0,SECOND(gainscoreview.dt)),SECOND(gainscoreview.dt))) AS dt1  from gainscoreview",null,(page-1)*rows,rows);
			List<Map<String,Object>> role2 = userService.findBySQLToMap("select count(*) as cnt from gainscoreview",null,-1,-1);
			String num = role2.get(0).get("cnt").toString();
			 int num1= Integer.parseInt(num);
			 Map<String, Object> jsonMap = new HashMap<String, Object>();
			 jsonMap.put("rows", role);
			 jsonMap.put("total", num1);
			 result = JSONObject.fromObject(jsonMap);
	       return result;
		}
		@RequestMapping(value ="scoremlist")
		@ResponseBody
		public JSONObject scoremlist(HttpServletRequest request,HttpServletResponse response) throws Exception{
			JSONObject result = new JSONObject();
			String r=request.getParameter("rows");
			String p=request.getParameter("page");
			int rows =Integer.parseInt(r);
			int page = Integer.parseInt(p);
			String tj=request.getSession().getAttribute("yhjfcx").toString();
			List<Map<String,Object>> role = userService.findBySQLToMap("select scoremlist.idscoremlist,scoremlist.class as class1,users.name as username,scoremlist.goodsname as shopname,scoremlist.money,scoremlist.type,scoremlist.score,CONCAT(YEAR(scoremlist.date),'年',MONTH(scoremlist.date),'月',DAY(scoremlist.date),'日', ' ',IF(LENGTH(HOUR(scoremlist.date))=1,CONCAT(0,HOUR(scoremlist.date)),HOUR(scoremlist.date)),':',IF(LENGTH(MINUTE(scoremlist.date))=1,CONCAT(0,MINUTE(scoremlist.date)),MINUTE(scoremlist.date)),':',IF(LENGTH(SECOND(scoremlist.date))=1,CONCAT(0,SECOND(scoremlist.date)),SECOND(scoremlist.date))) AS date from scoremlist left join cuser on scoremlist.cuserid=cuser.idcuser left join users on scoremlist.userid=users.idusers"+tj,null,(page-1)*rows,rows);
			List<Map<String,Object>> role2 = userService.findBySQLToMap("select count(*) as cnt from scoremlist"+tj,null,-1,-1);
			String num = role2.get(0).get("cnt").toString();
			 int num1= Integer.parseInt(num);
			 Map<String, Object> jsonMap = new HashMap<String, Object>();
			 jsonMap.put("rows", role);
			 jsonMap.put("total", num1);
			 result = JSONObject.fromObject(jsonMap);
	       return result;
		}
		@RequestMapping(value ="scorelistxjsh")
		@ResponseBody
		public JSONObject scorelistxjsh(HttpServletRequest request,HttpServletResponse response) throws Exception{
			JSONObject result = new JSONObject();
			String r=request.getParameter("rows");
			String p=request.getParameter("page");
			int rows =Integer.parseInt(r);
			int page = Integer.parseInt(p);
			String tj=request.getSession().getAttribute("yhjfcx").toString();
			List<Map<String,Object>> role = userService.findBySQLToMap("select * from scorexjview"+tj,null,(page-1)*rows,rows);
			List<Map<String,Object>> role2 = userService.findBySQLToMap("select count(*) as cnt from scorexjview"+tj,null,-1,-1);
			String num = role2.get(0).get("cnt").toString();
			 int num1= Integer.parseInt(num);
			 Map<String, Object> jsonMap = new HashMap<String, Object>();
			 jsonMap.put("rows", role);
			 jsonMap.put("total", num1);
			 result = JSONObject.fromObject(jsonMap);
	       return result;
		}


		@RequestMapping(value = "/modiscore")
		public void modiscore(HttpServletRequest request,HttpServletResponse response){
			response.setContentType("text/Xml");
			 response.setCharacterEncoding("utf-8");
			 PrintWriter out=null;
			try {
				out = response.getWriter();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//"id":a,"uname":b,"ulx":c,"uaddr":e,"ucon":e,"uphone":f,"ustatus":g
			String id = request.getParameter("id");
			String umoney = request.getParameter("umoney");
			String uscore = request.getParameter("uscore");
			try {
				int i=userService.execSql("update score set money="+umoney+",score="+uscore+" where userid="+id);
				 out.print(i);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 out.flush();
			 out.close();
			}
		@RequestMapping(value = "/shscore")
		public void shscore(HttpServletRequest request,HttpServletResponse response){
			response.setContentType("text/Xml");
			 response.setCharacterEncoding("utf-8");
			 PrintWriter out=null;
			try {
				out = response.getWriter();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//"id":a,"uname":b,"ulx":c,"uaddr":e,"ucon":e,"uphone":f,"ustatus":g
			String id = request.getParameter("id");
			try {
				int i=userService.execSql("update scoremlist set shstatus='已审核' where userid="+id);
				 out.print(i);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 out.flush();
			 out.close();
			}
		@RequestMapping(value ="userlist")
		public String userlist(HttpServletRequest request,HttpServletResponse response) throws Exception{
			List<Map<String,Object>> userSql = userService.findBySQLToMap("select * from addresslist",null,-1,-1);;
			request.setAttribute("cclass", userSql);
			 request.getSession().setAttribute("yzxxcx", "");
	       return "userlist";
		}
		@RequestMapping(value ="userlistcx")
		public String userlistcx(HttpServletRequest request,HttpServletResponse response) throws Exception{
			List<Map<String,Object>> userSql = userService.findBySQLToMap("select * from addresslist",null,-1,-1);;
			request.setAttribute("cclass", userSql);
			String name=request.getParameter("name");
			String dz=request.getParameter("dz");
			String id=request.getParameter("id");
			String phone=request.getParameter("phone");
			if (id.equals("")){
			 String tj=" where address like '%"+dz+"%' and name like '%"+name+"%' and phone like '%"+phone+"%'";
			 request.getSession().setAttribute("yzxxcx", tj);
			}
			else
			{

				 String tj=" where id="+id;
				 request.getSession().setAttribute("yzxxcx", tj);
			}
	       return "userlist";
		}
		@RequestMapping(value ="userlists")
		@ResponseBody
		public JSONObject userlists(HttpServletRequest request,HttpServletResponse response) throws Exception{
			JSONObject result = new JSONObject();
			String r=request.getParameter("rows");
			String p=request.getParameter("page");
			int rows =Integer.parseInt(r);
			int page = Integer.parseInt(p);
			String tj=request.getSession().getAttribute("yzxxcx").toString();
			List<Map<String,Object>> role = userService.findBySQLToMap("select * from userview"+tj,null,(page-1)*rows,rows);
			List<Map<String,Object>> role2 = userService.findBySQLToMap("select count(*) as cnt from userview"+tj,null,-1,-1);
			String num = role2.get(0).get("cnt").toString();
			 int num1= Integer.parseInt(num);
			 Map<String, Object> jsonMap = new HashMap<String, Object>();
			 jsonMap.put("rows", role);
			 jsonMap.put("total", num1);
			 result = JSONObject.fromObject(jsonMap);
	       return result;
		}

//		 name lx addr con phone
			@RequestMapping(value = "/adduser")
			public void adduser(HttpServletRequest request,HttpServletResponse response){
				response.setContentType("text/Xml");
				 response.setCharacterEncoding("utf-8");
					String name=request.getParameter("name");
					String addr=request.getParameter("addr");
					String phone=request.getParameter("phone");
				 PrintWriter out=null;
				try {
					out = response.getWriter();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			     String idx=userService.getTableId("users");
					List<Map<String,Object>> ss = (List<Map<String,Object>>)request.getSession().getAttribute("user");
				try {
			//		  `idcuser` int(11) NOT NULL,
			//		  `name` varchar(45) DEFAULT NULL,
			//		  `classid` int(11) DEFAULT NULL,
			//		  `address` varchar(45) DEFAULT NULL,
			//		  `phone` varchar(45) DEFAULT NULL,
			//		  `depaid` int(11) DEFAULT NULL,
			//		  `status` varchar(45) DEFAULT '有效',
			//		  `contacts` varchar(45) DEFAULT NULL,

					int i=userService.execSql("insert into users(idusers,name,addressid,phone,depaid) values("+idx+",'"+name+"',"+addr+",'"+phone+"',"+ss.get(0).get("depaid")+")");
					 out.print(i);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 out.flush();
				 out.close();
				}
			@RequestMapping(value = "/modiuser")
			public void modiuser(HttpServletRequest request,HttpServletResponse response){
				response.setContentType("text/Xml");
				 response.setCharacterEncoding("utf-8");
				 PrintWriter out=null;
				try {
					out = response.getWriter();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//"id":a,"uname":b,"uaddr":d,"uphone":e,"ustatus"
				String id = request.getParameter("id");
				String uname = request.getParameter("uname");
				String uaddr = request.getParameter("uaddr");
				String uphone = request.getParameter("uphone");
				String ustatus = request.getParameter("ustatus");
				try {
					int i=userService.execSql("update users set name='"+uname+"',addressid="+uaddr+",phone='"+uphone+"',status='"+ustatus+"' where idusers="+id);
					 out.print(i);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 out.flush();
				 out.close();
				}
			@RequestMapping(value ="addresslistcx")
			public String addresslistcx(HttpServletRequest request,HttpServletResponse response) throws Exception{
				String xq=request.getParameter("xq");
				String dz=request.getParameter("dz");
				 String tj=" where buildingarea like '%"+xq+"%' and name like '%"+dz+"%'";
				 request.getSession().setAttribute("dzcx", tj);
		       return "addresslist";
			}
			@RequestMapping(value ="addresslist")
			public String addresslist(HttpServletRequest request,HttpServletResponse response) throws Exception{
				 request.getSession().setAttribute("dzcx", "");
		       return "addresslist";
			}
			@RequestMapping(value ="addresslists")
			@ResponseBody
			public JSONObject addresslists(HttpServletRequest request,HttpServletResponse response) throws Exception{
				JSONObject result = new JSONObject();
				String r=request.getParameter("rows");
				String p=request.getParameter("page");
				int rows =Integer.parseInt(r);
				int page = Integer.parseInt(p);
				String tj=request.getSession().getAttribute("dzcx").toString();
				List<Map<String,Object>> role = userService.findBySQLToMap("select * from addresslist"+tj,null,(page-1)*rows,rows);
				List<Map<String,Object>> role2 = userService.findBySQLToMap("select count(*) as cnt from addresslist"+tj,null,-1,-1);
				String num = role2.get(0).get("cnt").toString();
				 int num1= Integer.parseInt(num);
				 Map<String, Object> jsonMap = new HashMap<String, Object>();
				 jsonMap.put("rows", role);
				 jsonMap.put("total", num1);
				 result = JSONObject.fromObject(jsonMap);
		       return result;
			}
			@RequestMapping(value = "/addaddresslist")
			public void addaddresslist(HttpServletRequest request,HttpServletResponse response){
				response.setContentType("text/Xml");
				 response.setCharacterEncoding("utf-8");
					String name=request.getParameter("name");
					String buildingarea=request.getParameter("buildingarea");
				 PrintWriter out=null;
				try {
					out = response.getWriter();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			     String idx=userService.getTableId("addresslist");
					List<Map<String,Object>> ss = (List<Map<String,Object>>)request.getSession().getAttribute("user");
				try {
			//		  `idcuser` int(11) NOT NULL,
			//		  `name` varchar(45) DEFAULT NULL,
			//		  `classid` int(11) DEFAULT NULL,
			//		  `address` varchar(45) DEFAULT NULL,
			//		  `phone` varchar(45) DEFAULT NULL,
			//		  `depaid` int(11) DEFAULT NULL,
			//		  `status` varchar(45) DEFAULT '有效',
			//		  `contacts` varchar(45) DEFAULT NULL,

					int i=userService.execSql("insert into addresslist(idaddresslist,name,buildingarea,depaid) values("+idx+",'"+name+"','"+buildingarea+"',"+ss.get(0).get("depaid")+")");
					 out.print(i);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 out.flush();
				 out.close();
				}
			@RequestMapping(value = "/modiaddresslist")
			public void modiaddresslist(HttpServletRequest request,HttpServletResponse response){
				response.setContentType("text/Xml");
				 response.setCharacterEncoding("utf-8");
				 PrintWriter out=null;
				try {
					out = response.getWriter();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//"id":a,"uname":b,"uaddr":d,"uphone":e,"ustatus"
				String id = request.getParameter("id");
				String uname = request.getParameter("uname");
				String ubuildingarea = request.getParameter("ubuildingarea");
				String ustatus = request.getParameter("ustatus");
				try {
					int i=userService.execSql("update addresslist set name='"+uname+"',buildingarea='"+ubuildingarea+"',status='"+ustatus+"' where idaddresslist="+id);
					 out.print(i);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 out.flush();
				 out.close();
				}
			@RequestMapping(value ="dzcx")
			public String dzcx(HttpServletRequest request,HttpServletResponse response) throws Exception{
		       return "dzcx";
			}
			@RequestMapping(value ="shjfcx")
			public String shjfcx(HttpServletRequest request,HttpServletResponse response) throws Exception{
		       return "shjfcx";
			}
			@RequestMapping(value ="yhjfcx")
			public String yhjfcx(HttpServletRequest request,HttpServletResponse response) throws Exception{
		       return "yhjfcx";
			}
			@RequestMapping(value ="yzxxcx")
			public String yzxxcx(HttpServletRequest request,HttpServletResponse response) throws Exception{
		       return "yzxxcx";
			}
			@RequestMapping(value ="xgdlmm")
			public String xgdlmm(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{
				String pass1 = request.getParameter("pass1");
				String pass2 = request.getParameter("pass2");
				String pass3 = request.getParameter("pass3");
				String yzm = request.getParameter("yz");
				String userid=session.getAttribute("userid").toString();;
				String msg="null";
				String sql="";
				if (pass1!=null){
					sql= "select idusers from systemuser where idusers="+userid+" and password='"+Md5Encrypt.md5(pass1)+"'";
					List<Map<String,Object>> ss = userService.findBySQLToMap(sql,null,-1,-1);
					if (ss.size()==1){
						if(pass2.equals(pass3)){
							String yz=request.getSession().getAttribute("logincode").toString();
							if(yz.equals(yzm)){
								msg="密码修改失败！";
								int i=userService.execSql("update systemuser set password='"+Md5Encrypt.md5(pass2)+"' where idusers="+userid);
								msg="密码修改成功！";
							}
							else
							{
								msg="验证码不正确！";
							}
						}
						else
						{
							msg="确认密码不一致！";
						}

					}
					else{
						msg="原始密码不正确！";
					}
				}
				request.getSession().setAttribute("error", msg);
				return "xgdlmm";
			}
			@RequestMapping(value ="scoreexchangelist")
			public String scoreexchangelist(HttpServletRequest request,HttpServletResponse response) throws Exception{
				List<Map<String,Object>> userSql = userService.findBySQLToMap("select * from exchangename",null,-1,-1);;
				request.setAttribute("cclass", userSql);
				 request.getSession().setAttribute("scoreexchangelist", "");
		       return "scoreexchangelist";
			}
			@RequestMapping(value ="scoreexchangelists")
			@ResponseBody
			public JSONObject scoreexchangelists(HttpServletRequest request,HttpServletResponse response) throws Exception{
				JSONObject result = new JSONObject();
				String r=request.getParameter("rows");
				String p=request.getParameter("page");
				int rows =Integer.parseInt(r);
				int page = Integer.parseInt(p);
				String tj=request.getSession().getAttribute("scoreexchangelist").toString();
				List<Map<String,Object>> role = userService.findBySQLToMap("select scoreexchangeview.*,CONCAT(YEAR(scoreexchangeview.dt),'年',MONTH(scoreexchangeview.dt),'月',DAY(scoreexchangeview.dt),'日', ' ',IF(LENGTH(HOUR(scoreexchangeview.dt))=1,CONCAT(0,HOUR(scoreexchangeview.dt)),HOUR(scoreexchangeview.dt)),':',IF(LENGTH(MINUTE(scoreexchangeview.dt))=1,CONCAT(0,MINUTE(scoreexchangeview.dt)),MINUTE(scoreexchangeview.dt)),':',IF(LENGTH(SECOND(scoreexchangeview.dt))=1,CONCAT(0,SECOND(scoreexchangeview.dt)),SECOND(scoreexchangeview.dt))) AS dt1 from scoreexchangeview"+tj,null,(page-1)*rows,rows);
				List<Map<String,Object>> role2 = userService.findBySQLToMap("select count(*) as cnt from scoreexchangeview"+tj,null,-1,-1);
				String num = role2.get(0).get("cnt").toString();
				 int num1= Integer.parseInt(num);
				 Map<String, Object> jsonMap = new HashMap<String, Object>();
				 jsonMap.put("rows", role);
				 jsonMap.put("total", num1);
				 result = JSONObject.fromObject(jsonMap);
		       return result;
			}
			@RequestMapping(value = "/addscoreexchange")
			public void addscoreexchange(HttpServletRequest request,HttpServletResponse response){
				response.setContentType("text/Xml");
				 response.setCharacterEncoding("utf-8");
					String phone=request.getParameter("phone");
					String score=request.getParameter("score");
					String lx=request.getParameter("lx");
				 PrintWriter out=null;
				try {
					out = response.getWriter();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				List<Map<String,Object>> role = userService.findBySQLToMap("select * from users where phone='"+phone+"'",null,-1,-1);
			     String idx=userService.getTableId("scoreexchange");
					List<Map<String,Object>> ss = (List<Map<String,Object>>)request.getSession().getAttribute("user");
				try {

					int i=userService.execSql("insert into scoreexchange(idscoreexchange,changenameid,score,userid) values("+idx+",'"+lx+"','"+score+"',"+role.get(0).get("idusers")+")");
					 out.print(i);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 out.flush();
				 out.close();
				}



			@RequestMapping(value ="listnote")
			public String listnote(HttpServletRequest request,HttpServletResponse response) throws Exception{
				List<Map<String,Object>> userSql = userService.findBySQLToMap("select * from cuser",null,-1,-1);;
				request.setAttribute("cuser", userSql);
		       return "listnote";
			}
			@RequestMapping(value ="getnotelists")
			@ResponseBody
			public JSONObject getnotelists(HttpServletRequest request,HttpServletResponse response) throws Exception{
				JSONObject result = new JSONObject();
				String r=request.getParameter("rows");
				String p=request.getParameter("page");
				int rows =Integer.parseInt(r);
				int page = Integer.parseInt(p);
				List<Map<String,Object>> role = userService.findBySQLToMap("select * from listnoteview",null,(page-1)*rows,rows);
				List<Map<String,Object>> role2 = userService.findBySQLToMap("select count(*) as cnt from note",null,-1,-1);
				String num = role2.get(0).get("cnt").toString();
				 int num1= Integer.parseInt(num);
				 Map<String, Object> jsonMap = new HashMap<String, Object>();
				 jsonMap.put("rows", role);
				 jsonMap.put("total", num1);
				 result = JSONObject.fromObject(jsonMap);
		       return result;
			}
			@RequestMapping(value = "/addnote")
			public void addnote(HttpServletRequest request,HttpServletResponse response){
				response.setContentType("text/Xml");
				 response.setCharacterEncoding("utf-8");
					String bt=request.getParameter("bt");
					String content=request.getParameter("content");
					List<Map<String,Object>> userSql = (List<Map<String,Object>>)request.getSession().getAttribute("user");
					userSql.get(0).get("idusers");
				 PrintWriter out=null;
				try {
					out = response.getWriter();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			     String idx=userService.getTableId("note");
				try {

					int i=userService.execSql("insert into note(idnote,title,content,sender) values("+idx+",'"+bt+"','"+content+"',"+userSql.get(0).get("idusers")+")");
					 out.print(i);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 out.flush();
				 out.close();
				}

			@RequestMapping(value = "/modinote")
			public void modinote(HttpServletRequest request,HttpServletResponse response){
				response.setContentType("text/Xml");
				 response.setCharacterEncoding("utf-8");
				 PrintWriter out=null;
				try {
					out = response.getWriter();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//"id":a,"uname":b,"uaddr":d,"uphone":e,"ustatus"
				String uid = request.getParameter("id");
				String ubt = request.getParameter("bt");
				String ucontent = request.getParameter("content");
				try {
					int i=userService.execSql("update note set title='"+ubt+"',content='"+ucontent+"'  where idnote="+uid);
					 out.print(i);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 out.flush();
				 out.close();
				}

			/*封装方法*/
			/*获取AccessToken的值*/
			public String getAccessToken() throws Exception{
				String appId =wechatDeveloperInfo.appId;
				String appSecret = wechatDeveloperInfo.appSecret;
				AccessToken token = null;
				String accessToken=null;
				List<Map<String,Object>> accesstokenlist=wechatUserService.getAccessTokenList();
				int num = Integer.parseInt(accesstokenlist.get(0).get("expiresin").toString());
				if(num>=7200){
					token=CommonUtil.getToken(appId, appSecret);
					if (null != token) {
						accessToken=token.getAccessToken();
						wechatUserService.updateAccessToken(accessToken);
					}
				}
				else{
					accessToken=accesstokenlist.get(0).get("accesstoken").toString();
				}
				return accessToken;
			}
			/*物业通知*/
			public int userevaluation4wynotice(String openid4user,String evaluationtime,String noticeid,String noticetitile,String noticecontent) throws Exception{
				Template tem=new Template();
				tem.setTemplateId("gmfyYmNpl4SlR3LRBe-StnMHpX_rfe3ryAV099YHhFA");
				tem.setTopColor("#00DD00");
				tem.setToUser(openid4user);
				tem.setUrl("http://shequ.cbelite.cn/wuye/user/detailnotice.htm?noteid="+noticeid);
				List<TemplateParam> paras=new ArrayList<TemplateParam>();
				paras.add(new TemplateParam("first","亲爱的登峰家园住户，您好：","#FF3333"));
				paras.add(new TemplateParam("keyword1",noticetitile,"#0044BB"));
				paras.add(new TemplateParam("keyword2","登峰物业管理处","#0044BB"));
				paras.add(new TemplateParam("keyword3",evaluationtime,"#0044BB"));
				paras.add(new TemplateParam("remark",noticecontent+"点击此处浏览详情。","#0044BB"));
				tem.setTemplateParamList(paras);
				String token= getAccessToken();
				boolean result=SendTemplateUtil.sendTemplateMsg(token,tem);
				if(result){
					return 1;
				}
				else{
					return 0;
				}

			}
			/*用户积分消减申请审核通知*/
			public int userevaluation4userminscore(String openid4user,String evaluationtime,String noticeid,String noticetitile,String noticecontent) throws Exception{
				Template tem=new Template();
				tem.setTemplateId("gmfyYmNpl4SlR3LRBe-StnMHpX_rfe3ryAV099YHhFA");
				tem.setTopColor("#00DD00");
				tem.setToUser(openid4user);
				tem.setUrl("");
				List<TemplateParam> paras=new ArrayList<TemplateParam>();
				paras.add(new TemplateParam("first","xx商户，您好。赵先生于2016年7月15日16:05 在贵处有100元消费产生了相应的积分。现赵先生申请消减该积分。","#FF3333"));
				paras.add(new TemplateParam("keyword1","物业已审核通过。","#0044BB"));
				paras.add(new TemplateParam("keyword2",evaluationtime,"#0044BB"));
				paras.add(new TemplateParam("remark","感谢您的使用。","#0044BB"));
				tem.setTemplateParamList(paras);
				String token=getAccessToken();
				boolean result=SendTemplateUtil.sendTemplateMsg(token,tem);
				if(result){
					return 1;
				}
				else{
					return 0;
				}

			}

}
