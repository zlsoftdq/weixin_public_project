package com.zfrj.yzb.base.action;


import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.zfrj.base.controller.BaseController;
import com.zfrj.wechat.pojo.AccessToken;
import com.zfrj.wechat.pojo.Template;
import com.zfrj.wechat.pojo.TemplateParam;
import com.zfrj.wechat.sendsms.SendSms;
import com.zfrj.wechat.service.WechatUserService;
import com.zfrj.wechat.util.AliSnsInfo;
import com.zfrj.wechat.util.CommonUtil;
import com.zfrj.wechat.util.GetOpenid;
import com.zfrj.wechat.util.SendTemplateUtil;
import com.zfrj.wechat.util.WechatDeveloperInfo;
import com.zfrj.yzb.base.service.ICommonService;
import com.zfrj.yzb.base.service.IUserService;

/**
 * <p>
 * Title: 物业中心业务逻辑
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Company: zfrj
 * </p>
 * 
 * @author gaofan
 * @date 2016年7月1日
 */

@Controller
@RequestMapping(value = "/wy")
public class WechatWyController extends BaseController {
	@Autowired
	IUserService userService;
	@Autowired
	ICommonService commonService;
	@Autowired
	WechatDeveloperInfo wechatDeveloperInfo;
	@Autowired
	AliSnsInfo aliSnsInfo;
	@Autowired
	WechatUserService wechatUserService;
	/* 发送短信验证码验证身份 */
	@RequestMapping(value = "/sendinitusersms")
	public void sendinitusersms(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
		String url=aliSnsInfo.url;
		String appkey=aliSnsInfo.appKey;
		String secret=aliSnsInfo.secret;
		String freeSignName=aliSnsInfo.freeSignName;
		PrintWriter out = response.getWriter();
		String telno=request.getParameter("telno");
		String smsTemplateCode=request.getParameter("smstemplatecode");
		String code=SendSms.createVerificationCode();		
		boolean result = SendSms.sendVerificationCode(url,appkey,secret,freeSignName,telno,smsTemplateCode, "{\"number\":\""+code+"\"}");
		if(result)
		{ 
			session.setAttribute("regusercode", code);
			session.setMaxInactiveInterval(15*60);//15分钟有效
			out.print(1);
		}
		else{
			out.print(0);
		}
	    out.flush();
	    out.close();
	}
	/*加载物业中心页面*/
	@RequestMapping("/index")
	public String index(HttpServletRequest request) throws Exception{
		/*String appId =wechatDeveloperInfo.appId;
		String appSecret = wechatDeveloperInfo.appSecret;
		String code=request.getParameter("code");
		String openid=GetOpenid.getOpenId(code, appId, appSecret);
		request.setAttribute("user_openid", openid);*/		
		return "wechat4wycent1er";
	}
	@RequestMapping("/json")
	public void createjson() throws Exception{
		String s= jsonlistaddress("0");
		System.out.println(s);
	}
	  public String jsonlistaddress(String id) throws Exception{
		    List<Map<String,Object>> list = wechatUserService.getaddresslist(id);
		           JSONArray json = new JSONArray();
		             for(int k=0;k<list.size();k++){
		                JSONObject json1=new JSONObject();
		                HashMap adu=(HashMap)list.get(k);
		                String name=adu.get("name").toString();
		                int Id=Integer.parseInt(adu.get("idarea").toString());
		                String pid=adu.get("pid").toString();
		                     json1.put("name", name);	
		                     
		                   List<Map<String,Object>> list2 = wechatUserService.getaddresslist(String.valueOf(Id));
		               if (list2.size()>0){
		            	   json1.put("name", name);
		                 json1.put("sub", jsonlistaddress(String.valueOf(Id)));
		                 if(id!="0"){
		                 json1.put("type", 0);
		                 }
		               }
		             json.add(json1);
		            }
		            String s=json.toString();
		            
		        return s;
		  }
	  
	  
	  /*维修绑定ajax*/
	@RequestMapping(value = "/Validateadduserinfo")
	public void Validateadduserinfo(HttpServletRequest request,
			HttpServletResponse response,HttpSession session) throws Exception{
		/*response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	   	PrintWriter out = response.getWriter();
		String username=request.getParameter("username");
		String phone=request.getParameter("phone");
		String address=request.getParameter("address");
		String addressid="010505";
		String openid=request.getParameter("openid");
		String code=request.getParameter("code");
		String session4code=session.getAttribute("regusercode").toString();
		if(session4code.equals(code)){
					int num=wechatUserService.adduserinfo(username,phone,address,addressid,openid);
					if(num>0){
						out.print(1);
					}
					else{
						out.print(-2);
					}
				}
			else{
				out.print(0);
			}
	    out.flush();
	    out.close();*/
	}
	/*判断用户是否补全基础信息*/
	@RequestMapping("/checkuseropenid")
	public void checkuseropenid(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{
		response.setContentType("text/Xml");
	    response.setCharacterEncoding("utf-8");
	    PrintWriter out = response.getWriter();
		String useropenid=request.getParameter("openid");
		List<Map<String,Object>> userSql = wechatUserService.checkuser(useropenid);
		if(userSql.size()==1){
			out.print(1);
		}
		else if(userSql.size()==0){
			out.print(0);
		}
		else{
			out.print(-1);
		}
		 out.flush();
		 out.close();
	
	}
	/*封装方法*/
	/*获取AccessToken的值*/
	public String getAccessToken() throws Exception{
		String appId =wechatDeveloperInfo.appId;
		String appSecret = wechatDeveloperInfo.appSecret;
		AccessToken token = null;
		String accessToken=null;
		List<Map<String,Object>> accesstokenlist=wechatUserService.getAccessTokenList();
		int num = Integer.parseInt(accesstokenlist.get(0).get("expiresin").toString());
		if(num>=7200){
			token=CommonUtil.getToken(appId, appSecret);
			if (null != token) {
				accessToken=token.getAccessToken();
				wechatUserService.updateAccessToken(accessToken);
			}
		}
		else{
			accessToken=accesstokenlist.get(0).get("accesstoken").toString();
		}
		return accessToken;		
	}
	/*用户评分通知*/
	public int userevaluation4shopnotice(String openid4shop,String shopcontactname,String evaluationtime,String userid) throws Exception{
		Template tem=new Template();  
		tem.setTemplateId("-O-eYbXRjGJwWyubcXP4WfzvetB0TpADv1XuCjg12Vk");  
		tem.setTopColor("#00DD00"); 
		tem.setToUser(openid4shop);  
		tem.setUrl("");  	          
		List<TemplateParam> paras=new ArrayList<TemplateParam>();  
		paras.add(new TemplateParam("first","亲爱的"+shopcontactname+"商户，有用户对您的服务进行评分。","#FF3333"));  
		paras.add(new TemplateParam("keyword1","用户ID:"+userid,"#0044BB"));  
		paras.add(new TemplateParam("keyword2",evaluationtime,"#0044BB"));  		          
		tem.setTemplateParamList(paras);  
		String token= getAccessToken();        
		boolean result=SendTemplateUtil.sendTemplateMsg(token,tem);  
		if(result){
			return 1;
		}
		else{
			return 0;
		}
		
	}
}
