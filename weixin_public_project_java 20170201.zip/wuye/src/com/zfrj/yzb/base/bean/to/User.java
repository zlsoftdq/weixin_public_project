package com.zfrj.yzb.base.bean.to;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Objects;
import java.math.BigDecimal;



/**
 * The persistent class for the db_user database table.
 * 
 */
@Entity
@Table(name="db_user")
public class User{
	private int user_id;
	private String user_name;
	private String user_password;
	private String user_telephone;
	private String user_email;
	private Timestamp user_create_time;
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="user_id")
	public int getUser_id() {
		return this.user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	@Column(name="username")
	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	@Column(name="password")
	public String getUser_password() {
		return user_password;
	}

	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}

	@Column(name="user_telephone")
	public String getUser_telephone() {
		return user_telephone;
	}

	public void setUser_telephone(String user_telephone) {
		this.user_telephone = user_telephone;
	}

	@Column(name="user_email")
	public String getUser_email() {
		return user_email;
	}

	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}

	@Column(name="user_create_time")
	public Timestamp getUser_create_time() {
		return user_create_time;
	}

	public void setUser_create_time(Timestamp user_create_time) {
		this.user_create_time = user_create_time;
	}

	
	

}