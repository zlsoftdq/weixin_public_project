package com.zfrj.yzb.base.bean.to;

import java.io.Serializable;

import javax.persistence.*;

import com.zfrj.util.DateUtil;

import java.sql.Timestamp;


/**
 * The persistent class for the tmp_verify_code database table.
 * 
 */
@Entity
@Table(name="tmp_verify_code")
public class VerifyCode implements Serializable {
	private static final long serialVersionUID = 1L;
	private Timestamp addTime;
	private String codeType;
	private String codeValue;
	private String requestedIp;
	private String typeValue;
	private int id;
	

	public VerifyCode() {
	}
	/**
	 * @param codeValue
	 * @param codeType
	 * @param typeValue
	 * @param requestedIp
	 */
	public VerifyCode(String codeValue,String codeType,String typeValue,String requestedIp){
		this.codeValue=codeValue;
		this.typeValue=typeValue;
		this.codeType=codeType;
		this.requestedIp=requestedIp;
		this.addTime=new Timestamp(System.currentTimeMillis());
	}
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name="add_time")
	public Timestamp getAddTime() {
		return this.addTime;
	}

	public void setAddTime(Timestamp addTime) {
		this.addTime = addTime;
	}


	@Column(name="code_type")
	public String getCodeType() {
		return this.codeType;
	}

	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}


	@Column(name="code_value")
	public String getCodeValue() {
		return this.codeValue;
	}

	public void setCodeValue(String codeValue) {
		this.codeValue = codeValue;
	}


	@Column(name="requested_ip")
	public String getRequestedIp() {
		return this.requestedIp;
	}

	public void setRequestedIp(String requestedIp) {
		this.requestedIp = requestedIp;
	}


	@Column(name="type_value")
	public String getTypeValue() {
		return this.typeValue;
	}

	public void setTypeValue(String typeValue) {
		this.typeValue = typeValue;
	}

}