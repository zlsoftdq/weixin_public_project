/**
* <p>Title: UserServiceImpl.java</p>
* <p>Description: </p>
* <p>Copyright: Copyright (c) 2015</p>
* <p>Company: zfrj</p>
* @author yzb
* @date 2015年5月28日
* @version 1.0
*/
package com.zfrj.yzb.base.service.impl;

import java.util.List;
import java.util.Map;

import org.hibernate.SQLQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zfrj.base.dao.BaseDAO;
import com.zfrj.yzb.base.bean.to.User;
import com.zfrj.yzb.base.exception.DuplicateUserException;
import com.zfrj.yzb.base.exception.NoSuchUserException;
import com.zfrj.yzb.base.service.IUserService;
import com.zfrj.yzb.base.service.pagestruct;
import com.zfrj.util.*;

/**
 * <p>Title: UserServiceImpl</p>
 * <p>Description: </p>
 * <p>Company: zfrj</p>
 * @author    yzb
 * @date       2015年9月11日
 */
@Service
public class UserServiceImpl implements IUserService {
	
	@Autowired
	BaseDAO baseDao;

	/* （非 Javadoc）
	* <p>Title: getUserById</p>
	* <p>Description: </p>
	* @param user_id
	* @return
	* @see com.siysoft.zfrj.app.center.service.UserService#getUserById(int)
	*/
	@Override
	public User getUserById(int user_id) {
		return (User) baseDao.findById(User.class, user_id);
	}
	

	
	/* （非 Javadoc）
	* <p>Title: changehead</p>
	* <p>Description: </p>
	* @param Telephone
	* @return
	* @see com.siysoft.zfrj.app.center.service.UserService#changehead(java.lang.String)
	*/
	
	
	

	/* （非 Javadoc）
	* <p>Title: getUserByTelephone</p>
	* <p>Description: </p>  
	* @param Telephone
	* @return
	* @see com.siysoft.zfrj.app.center.service.UserService#getUserByTelephone(java.lang.String)
	*/
	@Override
	public User getUserByTelephone(String telephone) throws DuplicateUserException {
		String hql="from User where telephone='"+telephone+"'";
		List<User> users=baseDao.findByHQL(hql);
		if(users.size()>1){
			throw new DuplicateUserException(telephone);
		}
		else if(users.size()==0){
			return null;
		}
		else{
			return users.get(0);
		}
		
	}

	
	/* （非 Javadoc）
	* <p>Title: updateUser</p>
	* <p>Description: </p>
	* @param User
	* @return
	* @see com.siysoft.zfrj.app.center.service.UserService#updateUser(User user)
	*/
	@Override
	public void updateUser(User user) {
		baseDao.update(user);
		
	}


	/* （非 Javadoc）
	* <p>Title: getUserByEmailOrTelephone</p>
	* <p>Description: </p>
	* @param emailOrPhone
	* @return
	* @see com.siysoft.zfrj.app.center.service.IUserService#getUserByEmailOrTelephone(java.lang.String)
	*/
	@Override
	public User getUserByEmailOrTelephone(String emailOrPhone) throws DuplicateUserException, NoSuchUserException {
		String hql="from User where telephone='"+emailOrPhone+"' or email='"+emailOrPhone+"'";
		List<User> users=baseDao.findByHQL(hql);
		if(users.size()>1){
			throw new DuplicateUserException(emailOrPhone);
		}
		else if(users.size()==0){
			throw new NoSuchUserException(emailOrPhone);
		}
		else{
			return  users.get(0);
		}
	}
	
	@Override
	public int insertUser(User user) {
		return (Integer)baseDao.saveReturnId(user);
	}




	@Override
	public User createUser(String name, String telephone, String email,
			String password) {
		String hql = "from User where user_name='"+name+"' or user_email='"+email+"' or user_telephone='"+telephone+"'";
		List<User> users = baseDao.findByHQL(hql);
		if(users.size() == 0){
			User user = new User();
			user.setUser_name(name);
			user.setUser_telephone(telephone);
			user.setUser_email(email);
			user.setUser_password(password);
			int user_id = (int)baseDao.saveReturnId(user);
			User tmp_user = (User)baseDao.findById(User.class, user_id);
			return tmp_user;
		}
		else{
			return null;
		}
	}
	
	@Override
	public Integer judgeName(String name) {
		// TODO Auto-generated method stub
		String hql = "from User where user_name='"+name+"'";
		List<User> user = baseDao.findByHQL(hql);
		if(user.size() == 0){
			return 1;
		}
		else{
			return -1;
		}
	}


	@Override
	public Integer judgeTelephone(String telephone) {
		// TODO Auto-generated method stub
		String hql = "from User where user_telephone='"+telephone+"'";
		List<User> user = baseDao.findByHQL(hql);
		if(user.size() == 0){
			return 1;
		}
		else{
			return -1;
		}
	}


	@Override
	public Integer judgeEmail(String email) {
		// TODO Auto-generated method stub
		String hql = "from User where user_email='"+email+"'";
		List<User> user = baseDao.findByHQL(hql);
		if(user.size() == 0){
			return 1;
		}
		else{
			return -1;
		}
	}



	@Override
	public User login(String name_email_studentid) {
		// TODO Auto-generated method stub
		String hql = "from User where user_name='"+name_email_studentid+"' or user_email='"+name_email_studentid+"'";
		List<User> user = baseDao.findByHQL(hql);
		if(user.size() == 0){
			return null;
		}
		else{
			return user.get(0);
		}
	}
	@Override
	public User login2(String user_id) {
		// TODO Auto-generated method stub
		String hql = "from User where user_id="+user_id;
		List<User> user = baseDao.findByHQL(hql);
		if(user.size() == 0){
			return null;
		}
		else{
			return user.get(0);
		}
	}



	@Override
	public List<Map<String, Object>> getUsers(Pagination pg) {
		// TODO Auto-generated method stub
		String sql = "select user_id,username,user_telephone from db_user";
		String sql1 = "select user_id from db_user";
		
		try {
			List<Map<String, Object>> users = baseDao.findBySQLToMap(sql, null, pg.getOffset(), pg.getLimit());
			pg.setTotal(((List)baseDao.findBySQLToMap(sql1, null, -1, -1)).size());
			return users;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	@Override
	public List<Map<String, Object>> getTable(String sql){
		try {
			List<Map<String, Object>> u = baseDao.findBySQLToMap(sql, null, -1, -1);
			return u;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
	@Override
	public List<Map<String, Object>> findBySQLToMap(String sql, Map params, int start, int rowCount){
		try {
			List<Map<String, Object>> u = baseDao.findBySQLToMap(sql, params, start, rowCount);
			return u;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
	@Override
	public List getProcQuery(){
		try {
			SQLQuery query = baseDao.ProcQuery("{CALL jgglistuser(?)}");
			query.addEntity(User.class);
			query.setLong(0, 1001);  
			List<User> list =query.list(); 
//			List list =query.list(); 
			return list;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
	@Override
	public void noteQuery(){
		try {
			SQLQuery query = baseDao.noteQuery("{note()}");
//			SQLQuery query = baseDao.ProcQuery("{CALL listuser(?)}");
//			query.addEntity(User.class);
//			query.setLong(0, 1001);  
//			List<User> list =query.list(); 
			query.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void insertrights(String name,String classname){
		try {
			SQLQuery query = baseDao.callprocedure("{CALL addrights('"+name+"','"+classname+"')}");
//			SQLQuery query = baseDao.ProcQuery("{CALL listuser(?)}");
//			query.addEntity(User.class);
//			query.setLong(0, 1001);  
//			List<User> list =query.list(); 
			query.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public List<Map<String, Object>> test2(){
		try {
			List<Map<String, Object>> u = baseDao.test2();///
			return u;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
	@Override
	public List<Map<String, Object>> getrole(String name){
		try {
			String sql="select * from new_role where role_name='"+name+"'";
			List<Map<String, Object>> u = baseDao.findBySQLToMap(sql, null, -1, -1);;///
			return u;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}

	/**
	 * 方法摘要：获取自增表id 作者：yzb
	 * 
	 * @param tablename
	 *              表名
	 */
	@Override
	public String getTableId(String tableName){
		String id="1";
		String sql = "select id_value  from id_table where id_name='"+tableName+"'";
		try {
			List<Map<String, Object>> tbs = baseDao.findBySQLToMap(sql, null, -1, -1);
			if (tbs!=null&&tbs.size()>0){
			int 	idi = (int) tbs.get(0).get("id_value");
		//		id = (String) tbs.get(0).get("id_value");
				id=(idi+1)+" ";
				id=id.trim();
				sql = "update id_table set id_value="+id+" where id_name='"+tableName+"'";
				baseDao.executeSql(sql);
				return id;
			}
			else
			{
				sql = "insert into id_table(id_name,id_value) values('"+tableName+"',"+id+")";
				baseDao.executeSql(sql);
				return id;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "0";
		}
	}

	@Override
	public String getTableId2(String tableName){
		String id="1";
		String sql = "select id_value  from id_table where id_name='"+tableName+"'";
		BaseDAO  baseDao2=new BaseDAO();
		try {
			List<Map<String, Object>> tbs = baseDao2.findBySQLToMap(sql, null, -1, -1);
			if (tbs!=null&&tbs.size()>0){
			int 	idi = (int) tbs.get(0).get("id_value");
		//		id = (String) tbs.get(0).get("id_value");
				id=(idi+1)+" ";
				id=id.trim();
				sql = "update id_table set id_value="+id+" where id_name='"+tableName+"'";
				baseDao2.executeSql(sql);
				return id;
			}
			else
			{
				sql = "insert into id_table(id_name,id_value,id) values('"+tableName+"',"+id+","+id+")";
				baseDao2.executeSql(sql);
				return id;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "0";
		}
	}

	
	/**
	 * 方法摘要：判断是否有权限 作者：yzb
	 * 
	 * @param roleName
	 *              角色名
	 */
	public boolean hasRight(String roleName,String right_name){
		String id="1";
		String sql = "select role_name,rights_name  from role_view where role_name='"+roleName+"'";
		
		try {
			List<Map<String, Object>> tbs = baseDao.findBySQLToMap(sql, null, -1, -1);
			if (tbs!=null&&tbs.size()>0){
				for (int i=0;i<tbs.size();i++){
					String rts=(String)tbs.get(0).get("rights_name");
					int k=rts.indexOf(right_name);
					if (k>0) return true;
					
				}
			}
			else
			{
				return false;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return false;
	}
	/**
	 * 方法摘要：执行插入 作者：yzb
	 * 
	 * @param sql
	 *              sql语句
	 */

	@Override
	public int insertToDb(String sql) throws Exception{
		return baseDao.executeSql(sql);
	}
	@Override
	public int execSql(String sql) throws Exception{
		return baseDao.executeSql(sql);
	}
	@Override
	public pagestruct getpage(String listsql,String tablename,int pagesize,int pagenumber){
		pagestruct ps=new pagestruct();
		try {
			int st=pagesize*(pagenumber-1);
			ps.list = baseDao.findBySQLToMap(listsql, null, st, pagesize);
			List<Map<String,Object>> ls = baseDao.findBySQLToMap("select count(*) as cnt from "+tablename, null, -1,-1);
			String ss=ls.get(0).get("cnt").toString();
			int k1=Integer.parseInt(ss);
			int k2=Integer.parseInt(ss)/pagesize*pagesize;
			if (k1==k2){
				ps.pagecount=Integer.parseInt(ss)/pagesize;
				
			}
			else
			{
				ps.pagecount=Integer.parseInt(ss)/pagesize+1;
				
			}
			ps.pagesize=pagesize;
			ps.pagenumber=pagenumber;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ps;
	}
	public pagestruct getsearchpage(String listsql,String listsql1,int pagesize,int pagenumber){
		pagestruct ps=new pagestruct();
		try {
			int st=pagesize*(pagenumber-1);
			ps.list = baseDao.findBySQLToMap(listsql, null, st, pagesize);
			List<Map<String,Object>> ls = baseDao.findBySQLToMap(listsql1, null, -1,-1);
			String ss=ls.get(0).get("cnt").toString();
			int k1=Integer.parseInt(ss);
			int k2=Integer.parseInt(ss)/pagesize*pagesize;
			if (k1==k2){
				ps.pagecount=Integer.parseInt(ss)/pagesize;
				
			}
			else
			{
				ps.pagecount=Integer.parseInt(ss)/pagesize+1;
				
			}
			ps.pagesize=pagesize;
			ps.pagenumber=pagenumber;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ps;
	}
	
}
