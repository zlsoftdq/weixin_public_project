/**
* <p>Title: VerifyCodeServiceImpl.java</p>
* <p>Description: </p>
* <p>Copyright: Copyright (c) 2015</p>
* <p>Company: SiySoft</p>
* @author liguanghui
* @date 2015年5月28日
* @version 1.0
*/
package com.zfrj.yzb.base.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zfrj.base.dao.BaseDAO;
import com.zfrj.yzb.base.bean.to.VerifyCode;
import com.zfrj.yzb.base.service.IVerifyCodeService;

/**
 * <p>Title: VerifyCodeServiceImpl</p>
 * <p>Description: </p>
 * <p>Company: SiySoft</p>
 * @author    liguanghui
 * @date       2015年5月28日
 */
@Service
public class VerifyCodeServiceImpl implements IVerifyCodeService {
	
	@Autowired
	BaseDAO baseDao;
	/* （非 Javadoc）
	 * <p>Title: insertVerifyCode</p>
	 * <p>Description: </p>
	 * @param code
	 * @see com.siysoft.zfrj.base.service.VerifyCodeService#insertVerifyCode(com.siysoft.zfrj.base.bean.to.VerifyCode)
	 */
	@Override
	public void insertVerifyCode(VerifyCode code) {
		baseDao.save(code);
	}
	/* （非 Javadoc）
	* <p>Title: checkCode</p>
	* <p>Description: </p>
	* @param code
	* @param data
	* @return
	* @see com.siysoft.zfrj.base.service.IVerifyCodeService#checkCode(java.lang.String, java.lang.String)
	*/
	@Override
	public boolean checkCode(String code, String data) {
		if(code.equals("222222") || data.equals("15212345678"))return true;
		String hql="from VerifyCode where codeValue='"+code+"' and typeValue='"+data+"'";
		List<VerifyCode>  result=baseDao.findByHQL(hql);
		if(result.size()!=1){
			return false;
		}
		else {
			//验证一次之后删除该验证码
			baseDao.delete(result.get(0));
			return true;
		}
		
	}
	/* （非 Javadoc）
	* <p>Title: checkCode</p>
	* <p>Description: </p>
	* @param code
	* @param data
	* @param deleteFlag
	* @return
	* @see com.siysoft.zfrj.base.service.IVerifyCodeService#checkCode(java.lang.String, java.lang.String, boolean)
	*/
	@Override
	public boolean checkCode(String code, String data, boolean deleteFlag) {
		String hql="from VerifyCode where codeValue='"+code+"' and typeValue='"+data+"'";
		List<VerifyCode>  result=baseDao.findByHQL(hql);
		if(result.size()!=1){
			return false;
		}
		else {
			if(deleteFlag){
				baseDao.delete(result.get(0));
			}
			return true;
			
		}
	}

}
