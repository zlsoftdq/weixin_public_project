/**
 * <p>Title: CommonService.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: SiySoft</p>
 * @author liguanghui
 * @date 2015年5月28日
 * @version 1.0
 */
package com.zfrj.yzb.base.service;

import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import com.zfrj.util.IMap;
import com.zfrj.yzb.base.exception.MailPropertyNotFoundException;

/**
 * <p>
 * Title: CommonService
 * </p>
 * <p>
 * Description:公共方法Service
 * </p>
 * <p>
 * Company: zfrj
 * </p>
 * 
 * @author yzb
 */
public interface ICommonService {
	/**
	 * 方法摘要：发送邮箱消息 作者：yzb
	 * 
	 * @param toAddress
	 *              目标邮箱地址
	 * @param requestIp
	 *              请求IP
	 * @throws MailPropertyNotFoundException
	 *               邮箱账户配置失败异常
	 * @throws MessagingException
	 *               邮箱发送失败异常
	 */
	boolean sendEmailMsg(String toAddress, String requestIp,String title,String content)
			throws MailPropertyNotFoundException, MessagingException;

	/**
	 * 方法摘要：发送邮箱验证码 作者：yzb
	 * 
	 * @param toAddress
	 *              目标邮箱地址
	 * @param requestIp
	 *              请求IP
	 * @throws MailPropertyNotFoundException
	 *               邮箱账户配置失败异常
	 * @throws MessagingException
	 *               邮箱发送失败异常
	 */
	boolean sendEmailVerfiyCode(String toAddress, String requestIp)
			throws MailPropertyNotFoundException, MessagingException;
	
	
}
