/**
 * <p>Title: CommonServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: SiySoft</p>
 * @author liguanghui
 * @date 2015年5月28日
 * @version 1.0
 */
package com.zfrj.yzb.base.service.impl;

import javax.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zfrj.base.dao.BaseDAO;
import com.zfrj.util.RandomCode;
import com.zfrj.util.mail.MailSenderInfo;
import com.zfrj.util.mail.SimpleMailSender;
import com.zfrj.yzb.base.bean.to.VerifyCode;
import com.zfrj.yzb.base.exception.MailPropertyNotFoundException;
import com.zfrj.yzb.base.service.ICommonService;
import com.zfrj.yzb.base.service.IVerifyCodeService;

/**
 * <p>
 * Title: CommonServiceImpl
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Company: SiySoft
 * </p>
 * 
 * @author vitoryu
 * @date 2015年9月15日
 */
@Service
public class CommonServiceImpl implements ICommonService {
	
	@Autowired
	IVerifyCodeService verifyCodeService;
	@Autowired
	BaseDAO baseDao;
	@Autowired
	MailSenderInfo mailSenderInfo;

	/*
	 * （非 Javadoc） <p>Title: sendEmailVerfiyCode</p> <p>Description: </p>
	 * 
	 * @param toAddress
	 * 
	 * @see com.siysoft.zfrj.base.service.CommonService#sendEmailVerfiyCode
	 * (java.lang.String)
	 */
	@Override
	public boolean sendEmailVerfiyCode(String toAddress, String requestIp)
			throws MailPropertyNotFoundException, MessagingException {


		VerifyCode code = new VerifyCode(RandomCode.getSixDigitRandomCode(),
				"EMAIL", toAddress, requestIp);

		mailSenderInfo.setToAddress(toAddress);
		mailSenderInfo.setSubject("验证码测试");
		mailSenderInfo.setContent("您的验证码是" + code.getCodeValue());
		// 把验证码插入到数据库。
		SimpleMailSender sms = new SimpleMailSender();

		sms.sendTextMail(mailSenderInfo);
		// 如果发送成功，插入验证码到数据库
		verifyCodeService.insertVerifyCode(code);
		return true;

	}
	
	@Override
	public boolean sendEmailMsg(String toAddress, String requestIp,String title,String content)
			throws MailPropertyNotFoundException, MessagingException{
		System.out.println("****************************222222222222222222222");
		mailSenderInfo.setToAddress(toAddress);
		mailSenderInfo.setSubject(title);
		mailSenderInfo.setContent(content);
		// 把验证码插入到数据库。
		SimpleMailSender sms = new SimpleMailSender();
		System.out.println("****************************3333333333333333333333");
		System.out.println("****************************getUserName" +mailSenderInfo.getUserName());
		System.out.println("****************************getMailServerHost" +mailSenderInfo.getMailServerHost());
		System.out.println("****************************getMailServerPort" +mailSenderInfo.getMailServerPort());
		sms.sendTextMail(mailSenderInfo);
		System.out.println("****************************44444444444444444444");
		/*// 如果发送成功，插入邮件发送记录+
		verifyCodeService.insertEmail(content);*/
		return true;

	}


	
}
