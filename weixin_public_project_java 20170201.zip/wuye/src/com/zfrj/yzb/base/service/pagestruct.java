package com.zfrj.yzb.base.service;

import java.util.List;
import java.util.Map;

public class pagestruct{
	public List<Map<String, Object>> list;
	public int pagenumber;
	public int pagecount;
	public int pagesize;
}
