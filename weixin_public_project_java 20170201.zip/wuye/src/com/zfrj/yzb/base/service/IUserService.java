/**
* <p>Title: UserService.java</p>
* <p>Description: </p>
* <p>Copyright: Copyright (c) 2015</p>
* <p>Company: SiySoft</p>
* @author liguanghui
* @date 2015年5月28日
* @version 1.0
*/
package com.zfrj.yzb.base.service;

import java.util.List;
import java.util.Map;

import com.zfrj.util.Pagination;
import com.zfrj.yzb.base.bean.to.User;
import com.zfrj.yzb.base.exception.DuplicateUserException;
import com.zfrj.yzb.base.exception.NoSuchUserException;

/**
 * <p>Title: UserService</p>
 * <p>Description: </p>
 * <p>Company: zfrj</p>
 * @author    yzb
 * @date       2015年5月28日
 */
public interface IUserService {
	/**
	 * 方法摘要：  根据主键获取User
	 * 作者：yzb
	 * 日期：2015年5月28日 上午8:20:02
	 * @param user_id
	 * @return
	 */
	User getUserById(int user_id);
	/**
	 * 方法摘要： 根据手机号获取User
	 * 作者：yzb
	 * 日期：2015年5月28日 上午8:20:26
	 * @param telephone
	 * @return 
	 * @throws DuplicateUserException 
	 */
	User getUserByTelephone(String telephone) throws DuplicateUserException;
	
	
	/**
	 * 方法摘要： 修改user
	 * 作者：yzb
	 * 日期：2015年6月02日 上午8:08:26
	 * @param user
	 * @return 
	 */
	void updateUser(User user);
	
	/**
	 * 方法摘要： 通过邮箱或手机获取
	 * 作者：yzb
	 * 日期：2015年6月2日 下午5:45:14
	 * @param emailOrPhone
	 * @return
	 * @throws DuplicateUserException 
	 * @throws NoSuchUserException 
	 */
	User getUserByEmailOrTelephone(String emailOrPhone) throws DuplicateUserException, NoSuchUserException;
	/**
	 * 
	 * 方法摘要： 用户注册
	 * 作者：yzb
	 * 日期：2015年6月3日 下午6:14:40
	 * @param user
	 */
	int insertUser(User user);
	
	/**
	 * 
	 * @param name
	 * @param telephone
	 * @param email
	 * @param password
	 * @return
	 */
	User createUser(String name, String telephone, String email, String password);
	
	User login(String name_email_studentid);
	User login2(String user_id);
	
	/**
	 * 
	 * @param name
	 * @return
	 */
	Integer judgeName(String name);
	
	/**
	 * 
	 * @param telephone
	 * @return
	 */
	Integer judgeTelephone(String telephone);
	
	/**
	 * 
	 * @param email
	 * @return
	 */
	Integer judgeEmail(String email);
	/**
	 * 
	 * @param pg 
	 * @return
	 */
	List<Map<String, Object>> getUsers(Pagination pg);
	/**
	 * 方法摘要：获取自增表id 作者：yzb
	 * 
	 * @param tablename
	 *              表名
	 */
	String getTableId(String tableName);
	String getTableId2(String tableName);
	/**
	 * 方法摘要：判断是否有权限 作者：yzb
	 * 
	 * @param roleName
	 *              角色名
	 */
	public List<Map<String, Object>> findBySQLToMap(String sql, Map params, int start, int rowCount);
	boolean hasRight(String roleName,String right_name);
	public int insertToDb(String sql) throws Exception;
	public int execSql(String sql) throws Exception;
	public List<Map<String, Object>> getTable(String sql);
	public List<Map<String, Object>> test2();
	public List<Map<String, Object>> getrole(String name);
	public List<Map<String, Object>> getProcQuery();
	public void noteQuery();
	public void insertrights(String name,String classname);
	public pagestruct getpage(String listsql,String tablename,int pagesize,int pagenumber);
	public pagestruct getsearchpage(String listsql,String listsql1,int pagesize,int pagenumber);
	
}
