/**
* <p>Title: VerifyCodeService.java</p>
* <p>Description: </p>
* <p>Copyright: Copyright (c) 2015</p>
* <p>Company: SiySoft</p>
* @author liguanghui
* @date 2015年5月28日
* @version 1.0
*/
package com.zfrj.yzb.base.service;

import com.zfrj.yzb.base.bean.to.VerifyCode;

/**
 * <p>Title: VerifyCodeService</p>
 * <p>Description: </p>
 * <p>Company: SiySoft</p>
 * @author    liguanghui
 * @date       2015年5月28日
 */
public interface IVerifyCodeService {
	/**
	 * 方法摘要： 数据库添加发送的验证码
	 * 作者：liguanghui
	 * 日期：2015年6月2日 下午12:20:40
	 * @param code 验证码对象
	 */
	void insertVerifyCode(VerifyCode code);
	
	/**
	 * 方法摘要： 验证发送的验证码
	 * 作者：liguanghui
	 * 日期：2015年6月2日 下午12:21:16
	 * @param code	验证码
	 * @param data	手机号或邮箱
	 * @return		验证成功返回true
	 */
	boolean checkCode(String code,String data);
	
	/**
	 * 方法摘要： 验证码验证
	 * 作者：liguanghui
	 * 日期：2015年6月8日 下午1:31:46
	 * @param code 验证码
	 * @param data 邮箱或手机号
	 * @param deleteFlag 验证后是否删除验证码
	 * @return
	 */
	boolean checkCode(String code,String data,boolean deleteFlag);
	
}
