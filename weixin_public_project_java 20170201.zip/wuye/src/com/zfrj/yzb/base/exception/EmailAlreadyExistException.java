/**
* <p>Title: EmailAlreadyExistException.java</p>
* <p>Description: </p>
* <p>Copyright: Copyright (c) 2015</p>
* <p>Company: SiySoft</p>
* @author liguanghui
* @date 2015年6月4日
* @version 1.0
*/
package com.zfrj.yzb.base.exception;

/**
 * <p>Title: EmailAlreadyExistException</p>
 * <p>Description: </p>
 * <p>Company: SiySoft</p>
 * @author    liguanghui
 * @date       2015年6月4日
 */
public class EmailAlreadyExistException extends Exception {
	public EmailAlreadyExistException(){
		super("当前邮箱已经被其他人使用");
	}
}
