/**
* <p>Title: InvalidFindByIdException.java</p>
* <p>Description: </p>
* <p>Copyright: Copyright (c) 2015</p>
* <p>Company: SiySoft</p>
* @author liguanghui
* @date 2015年6月18日
* @version 1.0
*/
package com.zfrj.yzb.base.exception;

/**
 * <p>Title: InvalidFindByIdException</p>
 * <p>Description: </p>
 * <p>Company: SiySoft</p>
 * @author    liguanghui
 * @date       2015年6月18日
 */
public class InvalidFindByIdException extends Exception {
	public InvalidFindByIdException(){
		super("Cannot find data with the id in database,return 404 error");
	}

}
