/**
* <p>Title: DuplicateUserException.java</p>
* <p>Description: </p>
* <p>Copyright: Copyright (c) 2015</p>
* <p>Company: SiySoft</p>
* @author liguanghui
* @date 2015年6月3日
* @version 1.0
*/
package com.zfrj.yzb.base.exception;

/**
 * <p>Title: DuplicateUserException</p>
 * <p>Description: </p>
 * <p>Company: SiySoft</p>
 * @author    liguanghui
 * @date       2015年6月3日
 */
public class DuplicateUserException extends Exception {
	public DuplicateUserException(String data){
		super("重复的邮箱或电话号:"+data);
	}

}
