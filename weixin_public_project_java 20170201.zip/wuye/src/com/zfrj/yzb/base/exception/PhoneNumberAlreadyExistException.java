/**
* <p>Title: PhoneNumberAlreadyExistException.java</p>
* <p>Description: </p>
* <p>Copyright: Copyright (c) 2015</p>
* <p>Company: SiySoft</p>
* @author liguanghui
* @date 2015年6月4日
* @version 1.0
*/
package com.zfrj.yzb.base.exception;

/**
 * <p>Title: PhoneNumberAlreadyExistException</p>
 * <p>Description: </p>
 * <p>Company: SiySoft</p>
 * @author    liguanghui
 * @date       2015年6月4日
 */
public class PhoneNumberAlreadyExistException extends Exception {
	public PhoneNumberAlreadyExistException(){
		super("当前手机号已经被注册");
	}
}
