/**
* <p>Title: NoSuchUserException.java</p>
* <p>Description: </p>
* <p>Copyright: Copyright (c) 2015</p>
* <p>Company: SiySoft</p>
* @author liguanghui
* @date 2015年6月3日
* @version 1.0
*/
package com.zfrj.yzb.base.exception;

/**
 * <p>Title: NoSuchUserException</p>
 * <p>Description: </p>
 * <p>Company: SiySoft</p>
 * @author    liguanghui
 * @date       2015年6月3日
 */
public class NoSuchUserException extends Exception {
	public NoSuchUserException(String username){
		super("没有相关的用户:"+username);
	}

}
