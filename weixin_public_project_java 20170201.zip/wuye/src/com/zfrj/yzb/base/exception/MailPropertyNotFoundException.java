/**
* <p>Title: MailPropertyNotFoundException.java</p>
* <p>Description: </p>
* <p>Copyright: Copyright (c) 2015</p>
* <p>Company: SiySoft</p>
* @author liguanghui
* @date 2015年5月28日
* @version 1.0
*/
package com.zfrj.yzb.base.exception;

/**
 * <p>Title: MailPropertyNotFoundException</p>
 * <p>Description: </p>
 * <p>Company: SiySoft</p>
 * @author    liguanghui
 * @date       2015年5月28日
 */
public class MailPropertyNotFoundException extends Exception {
	public MailPropertyNotFoundException(){
		super("未找到邮件配置文件！");
	}
}

