/**
 * NoSuchRoleNameException.java
 * 描述：
 * 作者： liguanghui
 * 创建日期 ：2015年6月13日 下午11:26:22
 */
package com.zfrj.yzb.base.exception;

/**
 * @author ubuntu
 *
 */
public class NoSuchRoleNameException extends Exception {
	public NoSuchRoleNameException(String msg){
		super(msg);
	}
}
