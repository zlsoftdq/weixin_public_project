package com.zfrj.pojo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.Region;

import com.zfrj.yzb.base.action.ExportExcel;

public class exporttoexcel {
	public HttpServletResponse response;
	public List fialList;
	public List fieldList;
	public String title;
	List<Map<String,Object>> records;
	public exporttoexcel(HttpServletResponse res,String mytitle,List fieldtitleList,List fieldlist,List<Map<String,Object>> rec){
		response=res;
		fialList=fieldtitleList;
		title=mytitle;
		records=rec;
		fieldList=fieldlist;
	}
	final HSSFWorkbook wb = new HSSFWorkbook();

	final HSSFSheet sheet = wb.createSheet();
	public void excute(){
		
		
		ExportExcel exportExcel = new ExportExcel(wb, sheet);

		// 计算该报表的列数
		int number = fialList.size();

		// 给工作表列定义列宽(实际应用自己更改列数)
		for (int i = 0; i < number; i++) {
			sheet.setColumnWidth(i, 3000);

		}

		// 创建单元格样式
		HSSFCellStyle cellStyle = wb.createCellStyle();

		// 指定单元格居中对齐
		cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);

		// 指定单元格垂直居中对齐
		cellStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);

		// 指定当单元格内容显示不下时自动换行
		cellStyle.setWrapText(true);

		// 设置单元格字体
		HSSFFont font = wb.createFont();
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		font.setFontName("宋体");
		font.setFontHeight((short) 200);
		cellStyle.setFont(font);

		// 创建报表头部
		exportExcel.createNormalHead(title, number);

		// 设置第二行
		String[] params = new String[] { "    年  月  日", "  年  月  日" };
		exportExcel.createNormalTwoRow(params, number);

		// 设置列头

		HSSFRow row3 = sheet.createRow(2);

		// 设置行高
		row3.setHeight((short) 800);

		HSSFCell row3Cell = null;
		int n = 0;

		// 创建不同的LIST的列标题
		for (int i = 0; i < number; i++) {

				row3Cell = row3.createCell(i);
				row3Cell.setCellStyle(cellStyle);
				row3Cell.setCellValue(new HSSFRichTextString(fialList.get(i).toString()));
		}

		// 循环创建中间的单元格的各项的值
		int jmp=3;
		for (int i = 0; i < records.size(); i++) {
			HSSFRow row = sheet.createRow((short) i+jmp);
			for (int j = 0; j < number; j++) {
				String vl=fieldList.get(j).toString();
				exportExcel
						.cteateCell(wb, row, (short) j,
								HSSFCellStyle.ALIGN_CENTER_SELECTION, records.get(i).get(vl).toString());
				vl="";
			}

		}

		
		String path="d:\\uploads\\excel.xls";
		exportExcel.outputExcel(path);


	    try {
	         // path是指欲下载的文件的路径。
	         File file = new File(path);
	         // 取得文件名。
	         String filename = file.getName();
	         // 取得文件的后缀名。

	         // 以流的形式下载文件。
	         InputStream fis = new BufferedInputStream(new FileInputStream(path));
	         byte[] buffer = new byte[fis.available()];
	         fis.read(buffer);
	         fis.close();
	         // 清空response
	         response.reset();
	         // 设置response的Header
//	         response.addHeader("Content-Disposition", "attachment;filename=" + new String(filename.getBytes()));
	         response.addHeader("Content-Disposition", "attachment;filename=" + filename);
	         response.addHeader("Content-Length", "" + file.length());
	         OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
	         response.setContentType("application/octet-stream");
	         toClient.write(buffer);
	         toClient.flush();
	         toClient.close();
	     } catch (IOException ex) {
	         ex.printStackTrace();
	     }

		
		
		
		
		
		
	}


}
