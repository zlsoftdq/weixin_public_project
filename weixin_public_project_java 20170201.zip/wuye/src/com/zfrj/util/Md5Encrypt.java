package com.zfrj.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.security.authentication.encoding.Md5PasswordEncoder;

/**
 * 功能：md5加密处理类
 * 版本：1.0
 * 日期：2010-12-21
 * 作者：feng
 **/
public class Md5Encrypt {
	
	/**
	 * 功能：计算字符串的md5值
	 * 
	 * @param src
	 * @return
	 */
	public static String md5(String src) {			
		return digest(src, "MD5");			
	}
	
	/**
	 * 功能：根据指定的散列算法名，得到字符串的散列结果。
	 * 
	 * @param src
	 * @param name
	 * @return
	 */
	private static String digest(String src, String name){
		try {
			MessageDigest alg = MessageDigest.getInstance(name);
			byte[] result = alg.digest(src.getBytes());
			return BinaryConvert.byte2hex(result);
		} catch (NoSuchAlgorithmException ex) {
			return null;
		}	
	}
	/**
	 * 方法摘要： 带盐值的MD5加密方法
	 * 作者：liguanghui
	 * 日期：2015年7月8日 下午4:49:55
	 * @param src 密码明文
	 * @param salt 盐值，如果不用盐，第二个参数给空字符
	 * @return
	 */
	public static String saltMD5(String src,String salt){
		Md5PasswordEncoder md5 = new Md5PasswordEncoder();       
	        // false 表示：生成32位的Hex版, 这也是encodeHashAsBase64的, Acegi 默认配置; true  表示：生成24位的Base64版       
	        md5.setEncodeHashAsBase64(false); 
	        //第一个参数为密码。第二个参数为盐值,如果不用盐，第二个参数给空字符
	        return  md5.encodePassword(src,salt);
	}
}
