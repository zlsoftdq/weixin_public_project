package com.zfrj.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class HttpRequest {

    private static HttpRequest          instance           = null;
    
    public static HttpRequest getInstance ()
    {
        if (instance == null)
        {
            instance = new HttpRequest();
        }
        return instance;
    }
    
	Logger log = LoggerFactory.getLogger(HttpRequest.class);

	public String requestUrl (String requestUrl, String param,
			boolean moreline, String requestMethod) {
		StringBuffer sf = new StringBuffer("");
		try {
			URL url = new URL(requestUrl);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod(requestMethod);
			conn.setRequestProperty("Charset", "utf-8");
			conn.setDefaultUseCaches(false);

			if (requestMethod.equals("POST")) {
				OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
				writer.write(param);
				writer.flush();
			}
			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
			String line;
			while ((line = reader.readLine()) != null) {
				sf.append(line);
			}
			reader.close();
			conn.disconnect();
		} catch (MalformedURLException e) {
			log.info("公共MalformedURL读取异常", e);
		} catch (IOException e) {
			log.info("IO传输异常", e);
		}
		return sf.toString().replaceAll("\r\n", "");
	}
	
	
}
