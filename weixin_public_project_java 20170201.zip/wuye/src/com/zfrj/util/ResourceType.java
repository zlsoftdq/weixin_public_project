/**
* <p>Title: ResourceType.java</p>
* <p>Description: </p>
* <p>Copyright: Copyright (c) 2015</p>
* <p>Company: SiySoft</p>
* @author liguanghui
* @date 2015年5月29日
* @version 1.0
*/
package com.zfrj.util;

/**
 * <p>Title: ResourceType</p>
 * <p>Description: </p>
 * <p>Company: SiySoft</p>
 * @author    luote
 * @date       2015年5月29日
 */
public class ResourceType {
	/**
	 * 头像类图片 1001
	 */
	public static final String USER_AVATAR="1001";
	/**
	 * 课程图片 4001
	 */
	public static final String CLASS_PICTURE="1002";
	/**
	 * 课程视频 4002
	 */
	public static final String CLASS_VIDEO="1003";
	

}
