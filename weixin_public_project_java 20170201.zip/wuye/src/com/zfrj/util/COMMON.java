package com.zfrj.util;


import java.io.File;
import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import sun.reflect.Reflection;


/**
 * @author SunChaoqun
 * 
 */

public class COMMON {

    public static final double aaa=0.0;

    /**
     * 判断某个对象是否为空 集合类、数组做特殊处理
     * 
     * @param obj
     * @return 如为空，返回true,否则false
     * @author yehailong
     */
    public static boolean isEmpty(Object obj) {
        if (obj == null)
            return true;

        // 如果不为null，需要处理几种特殊对象类型
        if (obj instanceof String) {
            return ((String) obj).trim().equals("");
        } else if (obj instanceof Collection) {
            // 对象为集合
            Collection coll = (Collection) obj;
            return coll.size() == 0;
        } else if (obj instanceof Map) {
            // 对象为Map
            Map map = (Map) obj;
            return map.size() == 0;
        } else if (obj.getClass().isArray()) {
            // 对象为数组
            return Array.getLength(obj) == 0;
        } else {
            // 其他类型，只要不为null，即不为empty
            return false;
        }
    }

    /**
     * 字符串是否为数字
     * 
     * @param str
     * @return
     */
    public static boolean isDigitalString(String str) {
        if (isEmpty(str)) {
            return false;
        } else {
            try {
                Double.parseDouble(str);
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }



 

    /**
     * 转换字符串至HTML格式
     * 
     * @param src
     * @return
     */
    public static String toHtmlStr(String src) {
        if (src == null || src.length() == 0)
            return "";
        int i;
        StringBuffer aimStrBuf = new StringBuffer();
        StringBuffer resStrBuf = new StringBuffer(src);
        int strLength = resStrBuf.length();
        char tmpChar = 0;
        for (i = 0; i < strLength; i++) {
            tmpChar = resStrBuf.charAt(i);
            if (tmpChar == '<') {
                aimStrBuf.append(new char[] { '&', 'l', 't', ';' });
            } else if (tmpChar == '<') {
                aimStrBuf.append(new char[] { '&', 'g', 't', ';' });
            } else if (tmpChar == '\n') {
                aimStrBuf.append(new char[] { '<', 'b', 'r', '>' });
            } else if (tmpChar == '\r') {} else if (tmpChar == '\t') {
                aimStrBuf.append(new char[] { '&', 'n', 'b', 's', 'p', ';', '&', 'n', 'b', 's', 'p', ';', '&', 'n',
                        'b', 's', 'p', ';', '&', 'n', 'b', 's', 'p', ';' });
            } else if (tmpChar == ' ') {
                aimStrBuf.append(new char[] { '&', 'n', 'b', 's', 'p', ';' });
            } else if (tmpChar == '"') {
                aimStrBuf.append(new char[] { '\\', '“' });
            } else if (tmpChar == '\'') {
                aimStrBuf.append(new char[] { '\\', '\'' });
            } else if (tmpChar == '\\') {
                aimStrBuf.append(new char[] { '\\', '\\' });
            } else {
                aimStrBuf.append(tmpChar);
            }
        }
        return aimStrBuf.toString();
    }

  
    public static void debug(String message) {
        Log log = LogFactory.getLog(Reflection.getCallerClass(2));
        log.debug(message);
    }

    /**
     * @param message
     */
    public static void info(String message) {
        Log log = LogFactory.getLog(Reflection.getCallerClass(2));
        log.info(message);
    }
    
    /**
     * @param message
     */
    public static void info(String flag,String message) {
        Log log = LogFactory.getLog(Reflection.getCallerClass(2));
        log.info("[" + flag + "] " +message);
    }
    
    /**
     * @param message
     */
    public static void info(String flag1,String flag2,String message) {
        Log log = LogFactory.getLog(Reflection.getCallerClass(2));
        log.info("[" + flag1 + "] " + "[" + flag2 + "] " +message);
    }

    /**
     * @param message
     */
    public static void warn(String message) {
        Log log = LogFactory.getLog(Reflection.getCallerClass(2));
        log.warn(message);
    }

    /**
     * @param message
     */
    public static void error(String message) {
        Log log = LogFactory.getLog(Reflection.getCallerClass(2));
        log.error(message);
    }

    /**
     * @param message
     */
    public static void fatal(String message) {
        Log log = LogFactory.getLog(Reflection.getCallerClass(2));
        log.fatal(message);
    }

    /**
     * @param message
     */
    public static void trace(String message) {
        Log log = LogFactory.getLog(Reflection.getCallerClass(2));
        log.trace(message);
    }
    /**
     * @param message
     */
    public static void trace(String flag , String message) {
        Log log = LogFactory.getLog(Reflection.getCallerClass(2));
        log.info("[" + flag + "] " +message);
    }
    /**
     * @param message
     */
    public static void trace(String flag1,String flag2,String message) {
        Log log = LogFactory.getLog(Reflection.getCallerClass(2));
        log.info("[" + flag1 + "] " + "[" + flag2 + "] " +message);
    }

   
	
	public static String getIpAddress(HttpServletRequest request) {
		String ip = request.getHeader("x-forwarded-for");
		if ((ip == null) || (ip.length() == 0)
				|| ("unknown".equalsIgnoreCase(ip))) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if ((ip == null) || (ip.length() == 0)
				|| ("unknown".equalsIgnoreCase(ip))) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if ((ip == null) || (ip.length() == 0)
				|| ("unknown".equalsIgnoreCase(ip))) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}
		if ((ip == null) || (ip.length() == 0)
				|| ("unknown".equalsIgnoreCase(ip))) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if ((ip == null) || (ip.length() == 0)
				|| ("unknown".equalsIgnoreCase(ip))) {
			ip = request.getRemoteAddr();
		}
		return ip;
	}



	public static int NulltoZero(Integer integer) {
		// TODO Auto-generated method stub
		if(integer == null)
		return 0;
		else return integer;
	}

	public static Object Nulltonull(Object obj) {
		// TODO Auto-generated method stub
		if(obj == null)
		return "null";
		else return obj;
	}

	public static Double ZerotoLongi(Double double1) {

		if(double1 == null)
		return 116.467618;
		else return double1;
	}


	public static Double ZerotoLati(Double double1) {
		if(double1 == null)
		return 39.994581;
		else return double1;
	}


	public static String NulltoBlank(String str) {
		// TODO Auto-generated method stub
		if(str == null)
			return "";
		return str;
	}

	public static Object NulltoBlank(Object ob) {
		// TODO Auto-generated method stub
		if(ob == null)
			return "";
		return ob;
	}
	
	public static boolean isnull(Object obj) {
		// TODO Auto-generated method stub
		if(obj == null) return true;
		return false;
	}

}
