/**
* <p>Title: RandomCode.java</p>
* <p>Description: </p>
* <p>Copyright: Copyright (c) 2015</p>
* <p>Company: SiySoft</p>
* @author liguanghui
* @date 2015年5月28日
* @version 1.0
*/
package com.zfrj.util;

import java.util.Random;

/**
 * <p>Title: RandomCode</p>
 * <p>Description: </p>
 * <p>Company: SiySoft</p>
 * @author    liguanghui
 * @date       2015年5月28日
 */
public class RandomCode {
	public static String getSixDigitRandomCode(){
		int code=(int)((Math.random()*9+1)*100000);
		return String.valueOf(code);
	}
	public static String getRandomString(int length){
		     String str="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		     Random random=new Random();
		     StringBuffer sb=new StringBuffer();
		     for(int i=0;i<length;i++){
		       int number=random.nextInt(62);
		       sb.append(str.charAt(number));
		     }
		     return sb.toString();
		 }
}
