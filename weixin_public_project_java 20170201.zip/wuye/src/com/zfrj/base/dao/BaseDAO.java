package com.zfrj.base.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.zfrj.pojo.db_user;
import com.zfrj.util.COMMON;
import com.zfrj.yzb.base.bean.to.User;


/**
 * A data access object (DAO) providing persistence and search support for User
 * entities. Transaction control of the save(), update() and delete() operations
 * can directly support Spring container-managed transactions or they can be
 * augmented to handle user-managed Spring transactions. Each of these methods
 * provides additional information for how to configure it for the desired type
 * of transaction control.
 * 
 * @see .User
 * @author MyEclipse Persistence Tools & yzb  
 * yzb add function public Integer executeSql(String sql); 20150815
 */

public class BaseDAO extends HibernateDaoSupport {
	private static final Logger log = LoggerFactory.getLogger(BaseDAO.class);

	public List findByHQL(String hql) {
		log.debug(hql);

		List list = this.getHibernateTemplate().find(hql);
		return list;
	}

	public List<?> findByHQL(String hql, String param) {
		Query q = this.getHibernateTemplate().getSessionFactory()
				.getCurrentSession().createQuery(hql);
		q.setParameter(0, param);
		return q.list();
	}

	public List<?> findByHQL(String hql, Object[] param) {
		Query q = this.getHibernateTemplate().getSessionFactory()
				.getCurrentSession().createQuery(hql);
		if (param != null && param.length > 0) {
			for (int i = 0; i < param.length; i++) {
				q.setParameter(i, param[i]);
			}
		}
		return q.list();
	}

	public List<?> findByHQL(String hql, List<Object> param) {
		Query q = this.getHibernateTemplate().getSessionFactory()
				.getCurrentSession().createQuery(hql);
		if (param != null && param.size() > 0) {
			for (int i = 0; i < param.size(); i++) {
				q.setParameter(i, param.get(i));
			}
		}
		return q.list();
	}

	public Object findById(Class clazz, Serializable id) {
		return this.getHibernateTemplate().getSessionFactory()
				.getCurrentSession().get(clazz, id);
	}

	public void delete(Object... objs) {
		try {
			for (Object obj : objs) {
				this.getHibernateTemplate().delete(obj);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Object deleteByHQL(String hql) {
		Query query = this.getHibernateTemplate().getSessionFactory()
				.getCurrentSession().createQuery(hql);
		return query.executeUpdate();

	}

	public Object updateByHQL(String hql) {
		Query query = this.getHibernateTemplate().getSessionFactory()
				.getCurrentSession().createQuery(hql);
		return query.executeUpdate();

	}
	
	public List list(String hql) {
		return this.getHibernateTemplate().getSessionFactory()
				.getCurrentSession().createQuery(hql).list();
	}

	public void save(Object obj) {
		this.getHibernateTemplate().getSessionFactory().getCurrentSession()
				.persist(obj);
	}

	

	public void update(Object obj) {
		this.getHibernateTemplate().getSessionFactory().getCurrentSession()
				.merge(obj);
	}

	public void saveOrupdate(Object obj) {
		this.getHibernateTemplate().getSessionFactory().getCurrentSession()
				.saveOrUpdate(obj);
	}

	public Object saveReturn(Object obj) {
		try {
			Object o = this.getHibernateTemplate().getSessionFactory()
					.getCurrentSession().merge(obj);
			return o;
		} catch (RuntimeException re) {
			throw re;
		}
	}

	public Object saveReturnId(Object obj) {
		try {
			Object o = this.getHibernateTemplate().getSessionFactory()
					.getCurrentSession().save(obj);
			return o;
		} catch (RuntimeException re) {
			throw re;
		}
	}

	public List findPageByHql(String hql, int firstResult, int itemNum) {
		try {
			List list = this.getHibernateTemplate().getSessionFactory()
					.getCurrentSession().createQuery(hql)
					.setFirstResult(firstResult).setMaxResults(itemNum).list();
			return list;
		} catch (RuntimeException re) {
			throw re;
		}
	}

	public int findTotalRowsByHql(String hql, Map params) {
		try {
			hql = "select count(*) " + hql;
			if (!COMMON.isEmpty(params)) {
				return Integer.parseInt(this.getHibernateTemplate()
						.getSessionFactory().getCurrentSession()
						.createQuery(hql).setProperties(params).uniqueResult()
						.toString());
			} else {
				return Integer.parseInt(this.getHibernateTemplate()
						.getSessionFactory().getCurrentSession()
						.createQuery(hql).uniqueResult().toString());
			}
		} catch (RuntimeException re) {
			throw re;
		}
	}

	public Object findBySQL(String sql, Map params, int start, int rowCount)
			throws Exception {
		try {
			SQLQuery query = this.getHibernateTemplate().getSessionFactory()
					.getCurrentSession().createSQLQuery(sql);
			if (!COMMON.isEmpty(params)) {
				query.setProperties(params);
			}
			if (start != -1 && rowCount != -1) {
				query.setFirstResult(start);
				query.setMaxResults(rowCount);
			}

			return query.list();
		} catch (Exception e) {
			throw e;
		}
	}

	public List query(String sql,Object[] obj){
    	SQLQuery sq=super.getHibernateTemplate().getSessionFactory()
				.getCurrentSession().createSQLQuery(sql);
        for(int i=0;i<obj.length;i++){
        	sq.setParameter(i, obj[i]);
        }
        sq.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
        return sq.list();
    } 
	
	public List findBySQLToMap(String sql, Map params, int start, int rowCount)
			throws Exception {
		try {
			SQLQuery query = this.getHibernateTemplate().getSessionFactory()
					.getCurrentSession().createSQLQuery(sql);
			if (!COMMON.isEmpty(params)) {
				query.setProperties(params);
			}
			if (start != -1 && rowCount != -1) {
				query.setFirstResult(start);
				query.setMaxResults(rowCount);
			}
			query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);

			return query.list();

		} catch (Exception e) {
			throw e;
		}
	}
	

	public List findBySQLToMap2(String sql, List params, int start, int rowCount)
			throws Exception {
		try {
			SQLQuery query = this.getHibernateTemplate().getSessionFactory()
					.getCurrentSession().createSQLQuery(sql);
			if (!COMMON.isEmpty(params)) {
				for(int i=0;i<params.size();i++){
					query.setParameter(i,params.get(i).toString());					
				}
			}
			if (start != -1 && rowCount != -1) {
				query.setFirstResult(start);
				query.setMaxResults(rowCount);
			}
			query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);

			return query.list();

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	
	
	public Object findByHQL(String hql, Map params, int start, int rowCount)
			throws Exception {
		try {

			Query query = this.getHibernateTemplate().getSessionFactory()
					.getCurrentSession().createQuery(hql);
			if (!COMMON.isEmpty(params)) {
				query.setProperties(params);
			}
			if (start != -1 && rowCount != -1) {
				query.setFirstResult(start);
				query.setMaxResults(rowCount);
			}

			return query.list();
		} catch (Exception e) {
			throw e;
		}
	}
	

	public Integer executeHql(String hql) {
		return this.getHibernateTemplate().getSessionFactory()
				.getCurrentSession().createQuery(hql).executeUpdate();
	}
	
	public Integer executeSql(String sql) {
		return this.getHibernateTemplate().getSessionFactory()
				.getCurrentSession().createSQLQuery(sql).executeUpdate();
	}
	
	public void execSQLWithParam(String hql, Map<String,Object> map) {  
	  //  String hql = "UPDATE Ffconfigure SET configurevalue=:configurevalue WHERE configureid=:configureid";  
	        SQLQuery sqlquery = this.getHibernateTemplate().getSessionFactory()
					.getCurrentSession().createSQLQuery(hql);  
	  //      Map<String,Object> map = new HashMap<String,Object>();  
	   //     map.put("configurevalue",configurevalue);  
	  //      map.put("configureid",configureid);  
	        sqlquery.setProperties(map);  
	        sqlquery.executeUpdate();  
	}  
	public List test2(){
		SQLQuery query =   this.getHibernateTemplate().getSessionFactory()
				.getCurrentSession().createSQLQuery("{CALL listuser(?)}").addEntity(User.class);;
		query.setLong(0, 1001);  
		List<User> list =query.list(); 
//		List list =query.list(); 
		return list;
/*		 for(int i =0;i<list.size();i++){
			 System.out.println(list.get(i));
		 }
		 */
	}
	public SQLQuery callprocedure(String sql){
		return  this.getHibernateTemplate().getSessionFactory()
				.getCurrentSession().createSQLQuery(sql);
	}
	public SQLQuery ProcQuery(String sql){
		return  this.getHibernateTemplate().getSessionFactory()
				.getCurrentSession().createSQLQuery("{CALL listuser(?)}");
	}
	public SQLQuery noteQuery(String sqlcall){
		return  this.getHibernateTemplate().getSessionFactory()
				.getCurrentSession().createSQLQuery("{CALL note()}");
	}
}