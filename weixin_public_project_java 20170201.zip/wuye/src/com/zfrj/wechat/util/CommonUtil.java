package com.zfrj.wechat.util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;

import net.sf.json.JSONException;
import net.sf.json.JSONObject;

import com.zfrj.wechat.pojo.AccessToken;
import com.zfrj.wechat.pojo.JsapiTicket;

public class CommonUtil {
	// 凭证获取（GET）
		public final static String token_url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET";
		public final static String jsapi_ticket_url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=ACCESS_TOKEN&type=jsapi";
		
		/*发送http请求*/
		public static String httpRequest(String requestUrl, String requestMethod,String key,String value,String outputStr) {
			StringBuffer buffer=null;
			String buffer2str=null;
			try{
				URL url=new URL(requestUrl);
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod(requestMethod);
				conn.setDoOutput(true);
				conn.setDoInput(true);
				conn.setRequestProperty(key, value);
				conn.connect();
				if (null != outputStr) {
					OutputStream outputStream = conn.getOutputStream();
					// 注意编码格式
					outputStream.write(outputStr.getBytes("UTF-8"));
					outputStream.close();
				}
				InputStream inputStream = conn.getInputStream();
				InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "utf-8");
				BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
				String str = null;
				buffer = new StringBuffer();
				while ((str = bufferedReader.readLine()) != null) {
					buffer.append(str);
				}

				// 释放资源
				bufferedReader.close();
				inputStreamReader.close();
				inputStream.close();
				inputStream = null;
				conn.disconnect();
				buffer2str=buffer.toString();
			}
			catch (ConnectException ce) {
				//log.error("连接超时：{}", ce);
			} catch (Exception e) {
				//log.error("https请求异常：{}", e);
			}
			
			return buffer2str;
		}
		/*发送https请求*/
		public static JSONObject httpsRequest(String requestUrl, String requestMethod, String outputStr) {
			JSONObject jsonObject = null;
			try {
				// 创建SSLContext对象，并使用我们指定的信任管理器初始化
				TrustManager[] tm = { new MyX509TrustManager() };
				SSLContext sslContext = SSLContext.getInstance("SSL", "SunJSSE");
				sslContext.init(null, tm, new java.security.SecureRandom());
				// 从上述SSLContext对象中得到SSLSocketFactory对象
				SSLSocketFactory ssf = sslContext.getSocketFactory();

				URL url = new URL(requestUrl);
				HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
				conn.setSSLSocketFactory(ssf);
				
				conn.setDoOutput(true);
				conn.setDoInput(true);
				conn.setUseCaches(false);
				// 设置请求方式（GET/POST）
				conn.setRequestMethod(requestMethod);

				// 当outputStr不为null时向输出流写数据
				if (null != outputStr) {
					OutputStream outputStream = conn.getOutputStream();
					// 注意编码格式
					outputStream.write(outputStr.getBytes("UTF-8"));
					outputStream.close();
				}

				// 从输入流读取返回内容
				InputStream inputStream = conn.getInputStream();
				InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "utf-8");
				BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
				String str = null;
				StringBuffer buffer = new StringBuffer();
				while ((str = bufferedReader.readLine()) != null) {
					buffer.append(str);
				}

				// 释放资源
				bufferedReader.close();
				inputStreamReader.close();
				inputStream.close();
				inputStream = null;
				conn.disconnect();
				jsonObject = JSONObject.fromObject(buffer.toString());
			} catch (ConnectException ce) {
				//log.error("连接超时：{}", ce);
			} catch (Exception e) {
				//log.error("https请求异常：{}", e);
			}
			return jsonObject;
		}

		/*获取接口访问凭证*/
		public static AccessToken getToken(String appid, String appsecret) {
			AccessToken token = null;
			String requestUrl = token_url.replace("APPID", appid).replace("APPSECRET", appsecret);
			// 发起GET请求获取凭证
			JSONObject jsonObject = httpsRequest(requestUrl, "GET", null);

			if (null != jsonObject) {
				try {
					token = new AccessToken();
					token.setAccessToken(jsonObject.getString("access_token"));
					token.setExpiresIn(jsonObject.getInt("expires_in"));
				} catch (JSONException e) {
					token = null;
					// 获取token失败
					//log.error("获取token失败 errcode:{} errmsg:{}", jsonObject.getInt("errcode"), jsonObject.getString("errmsg"));
				}
			}
			return token;
		}
		/*URL编码（utf-8）*/
		public static String urlEncodeUTF8(String source) {
			String result = source;
			try {
				result = java.net.URLEncoder.encode(source, "utf-8");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			return result;
		}
		/* 根据内容类型判断文件扩展名 */
		public static String getFileExt(String contentType) {
			String fileExt = "";
			if ("image/jpeg".equals(contentType))
				fileExt = ".jpg";
			else if ("audio/mpeg".equals(contentType))
				fileExt = ".mp3";
			else if ("audio/amr".equals(contentType))
				fileExt = ".amr";
			else if ("video/mp4".equals(contentType))
				fileExt = ".mp4";
			else if ("video/mpeg4".equals(contentType))
				fileExt = ".mp4";
			return fileExt;
		}

		public static JsapiTicket getJsapiTicket(String accesstoken) {
			JsapiTicket jsapi_ticket=null;
			String requestUrl = jsapi_ticket_url.replace("ACCESS_TOKEN", accesstoken);
			// 发起GET请求获取凭证
			JSONObject jsonObject = httpsRequest(requestUrl, "GET", null);
			if (null != jsonObject) {
				try {
					jsapi_ticket = new JsapiTicket();
					jsapi_ticket.setJsapiTicket(jsonObject.getString("ticket"));
					jsapi_ticket.setExpiresIn(jsonObject.getInt("expires_in"));
				} catch (JSONException e) {
					jsapi_ticket = null;
					// 获取token失败
					//log.error("获取token失败 errcode:{} errmsg:{}", jsonObject.getInt("errcode"), jsonObject.getString("errmsg"));
				}
		}
			return jsapi_ticket;
		
	}
}

