package com.zfrj.wechat.util;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import net.sf.json.JSONObject;

import org.apache.log4j.Logger;
import org.aspectj.weaver.ast.Test;

public class GetOpenid {
	private static Logger logger = Logger.getLogger(Test.class);  
	public static String getOpenId(String code,String appid,String secret){
		String url="https://api.weixin.qq.com/sns/oauth2/access_token?appid=APPID&secret=SECRET&code=CODE&grant_type=authorization_code";
		url=url.replace("APPID", appid).replace("SECRET", secret).replace("CODE", code);
		String openId="";
		try {
			URL getUrl=new URL(url);
			HttpURLConnection http=(HttpURLConnection)getUrl.openConnection();
			http.setRequestMethod("GET"); 
			http.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
			http.setDoOutput(true);
			http.setDoInput(true);
			http.connect();
			InputStream is = http.getInputStream(); 
			int size = is.available(); 
			byte[] b = new byte[size];
			is.read(b);
			String message = new String(b, "UTF-8");
			logger.error(message);
			JSONObject json = JSONObject.fromObject(message);
			logger.error(json);
			if(message.contains("openid")){
			openId = json.getString("openid");
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
			return openId;
		}
}
