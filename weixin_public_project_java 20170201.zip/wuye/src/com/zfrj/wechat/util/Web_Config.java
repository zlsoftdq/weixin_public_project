package com.zfrj.wechat.util;

public class Web_Config {
	public String url_prefix;
	public Web_Config() {
		super();
	}
	public String getUrl_prefix() {
		return url_prefix;
	}

	public void setUrl_prefix(String url_prefix) {
		this.url_prefix = url_prefix;
	}
}
