package com.zfrj.wechat.util;



public class AliSnsInfo  {
	public String url;
	public String appKey;
	public String freeSignName;
	public String secret;
	public AliSnsInfo() {
		super();
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getAppKey() {
		return appKey;
	}
	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}
	public String getFreeSignName() {
		return freeSignName;
	}
	public void setFreeSignName(String freeSignName) {
		this.freeSignName = freeSignName;
	}
	public String getSecret() {
		return secret;
	}
	public void setSecret(String secret) {
		this.secret = secret;
	}


	
}
