package com.zfrj.wechat.util;


public class WechatDeveloperInfo  {
	public String appId;
	public String appSecret;
	public String token;
	public WechatDeveloperInfo() {
		super();
	}

	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getAppSecret() {
		return appSecret;
	}
	public void setAppSecret(String appSecret) {
		this.appSecret = appSecret;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
}
