package com.zfrj.wechat.menu;
/**
 * 按钮的基类
 * 
 * @author gaofan
 * @date 2016-06-30
 */
public class Button {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
