package com.zfrj.wechat.menu;
/**
 * 菜单
 * 
 * @author gaofan	
 * @date 2016-06-30
 */
public class Menu {
	private Button[] button;

	public Button[] getButton() {
		return button;
	}

	public void setButton(Button[] button) {
		this.button = button;
	}
}
