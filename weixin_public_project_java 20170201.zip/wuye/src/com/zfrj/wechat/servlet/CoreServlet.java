package com.zfrj.wechat.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zfrj.wechat.service.CoreService;
import com.zfrj.wechat.util.SignUtil;
/**
 * 微信核心servlet
 * @author gaofan
 * 2016-06-28 09:16:29
 */
public class CoreServlet extends HttpServlet {

	/**
	 * 在服务器配置时，用于token校验
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String signature=request.getParameter("signature");
		String timestamp=request.getParameter("timestamp");
		String nonce=request.getParameter("nonce");
		String echostr=request.getParameter("echostr");
		PrintWriter out=response.getWriter();
		//如果校验成功
		if(SignUtil.checkSignature(signature, timestamp, nonce)){
			out.write(echostr);
		}
		out.close();
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//编码设置
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String signature=request.getParameter("signature");
		String timestamp=request.getParameter("timestamp");
		String nonce=request.getParameter("nonce");
		
		PrintWriter out=response.getWriter();
		//如果校验成功
		if(SignUtil.checkSignature(signature, timestamp, nonce)){
			//消息进行处理
			String respXML=CoreService.processRequest(request);
			out.write(respXML);
		}
		out.close();
		
		
	}

}
