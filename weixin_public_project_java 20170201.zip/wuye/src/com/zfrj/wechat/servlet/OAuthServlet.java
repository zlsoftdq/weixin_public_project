package com.zfrj.wechat.servlet;


import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zfrj.wechat.pojo.SNSUserInfo;
import com.zfrj.wechat.pojo.WeixinOauth2Token;
import com.zfrj.wechat.util.AdvancedUtil;

/**
 * 授权后的回调请求处理
 *
 */
public class OAuthServlet extends HttpServlet {
	

	public void doGet(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");

		// 用户同意授权后，能获取到code
		String code = request.getParameter("code");

		// 用户同意授权
		if (!"authdeny".equals(code)) {
			// 获取网页授权access_token
			WeixinOauth2Token weixinOauth2Token = AdvancedUtil.getOauth2AccessToken("wx1447cb4b5d5a3196", "efe1de7d00883b1be71af14050348d79", code);
			
			// 用户标识
			String openId = weixinOauth2Token.getOpenId();
			
			session.setAttribute("user_openid", openId);
			// 设置要传递的参数
			//request.setAttribute("snsUserInfo", snsUserInfo);
		}
		// 跳转到index.jsp
		request.getRequestDispatcher("index.jsp").forward(request, response);
	}
}