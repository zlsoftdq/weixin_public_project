package com.zfrj.wechat.message;
//图片消息对象
public class ImageMessage extends BaseMessage {
   private Image Image;

public Image getImage() {
	return Image;
}

public void setImage(Image image) {
	Image = image;
}
}
