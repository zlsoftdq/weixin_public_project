package com.zfrj.wechat.message;

import java.util.List;
//图文消息对象
public class NewsMessage extends BaseMessage {
	private int ArticleCount;
	private List<Article> Article;
	public int getArticleCount() {
		return ArticleCount;
	}
	public void setArticleCount(int articleCount) {
		ArticleCount = articleCount;
	}
	public List<Article> getArticles() {
		return Article;
	}
	public void setArticles(List<Article> article) {
		Article = article;
	}
}
