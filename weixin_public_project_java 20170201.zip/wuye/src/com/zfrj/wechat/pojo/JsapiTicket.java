package com.zfrj.wechat.pojo;
/**
 * pojo4AccessToken
 * @author Administrator
 *
 */
public class JsapiTicket {
	// 接口访问凭证
		private String jsapiTicket;
		// 凭证有效期，单位：秒
		private int expiresIn;
		public String getJsapiTicket() {
			return jsapiTicket;
		}
		public void setJsapiTicket(String jsapiTicket) {
			this.jsapiTicket = jsapiTicket;
		}
		public int getExpiresIn() {
			return expiresIn;
		}
		public void setExpiresIn(int expiresIn) {
			this.expiresIn = expiresIn;
		}
		
	}