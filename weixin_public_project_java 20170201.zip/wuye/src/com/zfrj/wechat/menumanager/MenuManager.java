package com.zfrj.wechat.menumanager;

import com.zfrj.wechat.menu.Button;
import com.zfrj.wechat.menu.ComplexButton;
import com.zfrj.wechat.menu.Menu;
import com.zfrj.wechat.menu.ViewButton;
import com.zfrj.wechat.pojo.AccessToken;
import com.zfrj.wechat.util.CommonUtil;
import com.zfrj.wechat.util.MenuUtil;

public class MenuManager {
	/**
	 * 定义菜单结构
	 *
	 * @return
	 */
	private static Menu getMenu() {

		ViewButton btn11 = new ViewButton();
		btn11.setName("积分列表");
		btn11.setType("view");
		btn11.setUrl("http://shequ.cbelite.cn/wuye/user/userscorelist.htm");

		ViewButton btn12 = new ViewButton();
		btn12.setName("积分查询");
		btn12.setType("view");
		btn12.setUrl("http://shequ.cbelite.cn/wuye/user/userqueryscorelist.htm");

		ViewButton btn13 = new ViewButton();
		btn13.setName("积分消减");
		btn13.setType("view");
		btn13.setUrl("http://shequ.cbelite.cn/wuye/user/userminscorelist.htm");

		ViewButton btn14 = new ViewButton();
		btn14.setName("积分兑换");
		btn14.setType("view");
		btn14.setUrl("http://shequ.cbelite.cn/wuye/user/exchangescorelist.htm");

		/*ViewButton btn15 = new ViewButton();
		btn15.setName("用户报修申请");
		btn15.setType("view");
		btn15.setUrl(getUrl("http://shequ.cbelite.cn/wuye/user/wyfixuserapplication.htm"));*/

		ViewButton btn16 = new ViewButton();
		btn16.setName("用户管理中心");
		btn16.setType("view");
		btn16.setUrl("http://shequ.cbelite.cn/wuye/user/index.htm");

		ViewButton btn21 = new ViewButton();
		btn21.setName("增加积分");
		btn21.setType("view");
		btn21.setUrl("http://shequ.cbelite.cn/wuye/seller/shopaddscore.htm");

		ViewButton btn22 = new ViewButton();
		btn22.setName("消减积分申请");
		btn22.setType("view");
		btn22.setUrl("http://shequ.cbelite.cn/wuye/seller/shopminscore.htm");

		ViewButton btn23 = new ViewButton();
		btn23.setName("查看用户积分");
		btn23.setType("view");
		btn23.setUrl("http://shequ.cbelite.cn/wuye/seller/scorelist.htm");

		/*ViewButton btn24 = new ViewButton();
		btn24.setName("物业报修申请");
		btn24.setType("view");
		btn24.setUrl(getUrl("http://shequ.cbelite.cn/wuye/seller/wyfixsellerapplication.htm"));*/
		
		ViewButton btn25 = new ViewButton();
		btn25.setName("商户管理中心");
		btn25.setType("view");
		btn25.setUrl("http://shequ.cbelite.cn/wuye/seller/shopcenter.htm");

		/*ViewButton btn31 = new ViewButton();
		btn31.setName("物业通知");
		btn31.setType("view");
		btn31.setUrl("http://shequ.cbelite.cn/wuye/user/wynotice.htm");*/

		ViewButton btn35 = new ViewButton();
		btn35.setName("小区公告");
		btn35.setType("view");
		btn35.setUrl("http://mp.weixin.qq.com/s?__biz=MzIzNjQ0MjU2MQ==&mid=2247483670&idx=1&sn=0f1fe1328313f27f64a15c65be46b4a9&chksm=e8d687b8dfa10eae56597d92b6628b0a802344b6d4233b67698e1ddfbeb1588a08027a82942f#rd");
		
		/*ViewButton btn32 = new ViewButton();
		btn32.setName("物业服务");
		btn32.setType("view");
		btn32.setUrl("http://mp.weixin.qq.com/s?__biz=MzIzNjQ0MjU2MQ==&mid=2247483653&idx=1&sn=d4e823ba65f1662ccd04bc33dee18944&scene=0");

		ViewButton btn33 = new ViewButton();
		btn33.setName("业主公约");
		btn33.setType("view");
		btn33.setUrl("http://mp.weixin.qq.com/s?__biz=MzIzNjQ0MjU2MQ==&mid=2247483653&idx=2&sn=20515347c84eda0d704213bf10938a03&scene=0");
		*/
		ViewButton btn34 = new ViewButton();
		btn34.setName("物业问题报修");
		btn34.setType("view");
		btn34.setUrl("http://shequ.cbelite.cn/wuye/user/wyfixuserapplication.htm");
		
		ComplexButton mainBtn1 = new ComplexButton();
		mainBtn1.setName("用户中心");
		mainBtn1.setSub_button(new Button[] {btn11,btn12,btn13,btn14,btn16});

		ComplexButton mainBtn2 = new ComplexButton();
		mainBtn2.setName("商户中心");
		mainBtn2.setSub_button(new Button[] { btn21, btn22, btn23,btn25});

		ComplexButton mainBtn3 = new ComplexButton();
		mainBtn3.setName("物业服务");
		mainBtn3.setSub_button(new Button[] { btn35,btn34});

		Menu menu = new Menu();
		menu.setButton(new Button[] { mainBtn1, mainBtn2, mainBtn3 });

		return menu;
	}

	public static void main(String[] args) {
		// 第三方用户唯一凭证
		String appId = "wx1447cb4b5d5a3196";
		// 第三方用户唯一凭证密钥
		String appSecret = "efe1de7d00883b1be71af14050348d79";

		// 调用接口获取凭证
		AccessToken token = CommonUtil.getToken(appId, appSecret);

		if (null != token) {
			// 创建菜单
			boolean result = MenuUtil.createMenu(getMenu(), token.getAccessToken());

			// 判断菜单创建结果
			if (result)
				System.out.println("菜单创建成功！");
			else
				System.out.println("菜单创建失败！");
		}
	}
}
