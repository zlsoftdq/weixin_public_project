package com.zfrj.wechat.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zfrj.base.dao.BaseDAO;
import com.zfrj.yzb.base.service.IUserService;
@Service
public class WechatUserService{
	@Autowired
	 BaseDAO basedao;
	@Autowired
	IUserService userService;
	/* 获取AccessToken列表*/
	 public  List<Map<String, Object>> getAccessTokenList() throws Exception{
		   String sql="select * from v_accesstoken";
		   List<Map<String, Object>> listaccesstoken=basedao.findBySQLToMap(sql,null,-1,-1);	
			return listaccesstoken;		   
	   }
	 /* 更新AccessToken */
	 public void updateAccessToken(String accessToken) {
			String sql="update accesstoken set accesstoken='"+accessToken+"',gettime=now() where id=1";
			basedao.executeSql(sql);			
		}
	 /*获取JsapiTicket*/
	 public List<Map<String, Object>> getJsapiTicketList() throws Exception {
		 String sql="select * from v_jsapiticket";
		   List<Map<String, Object>> listjsapiticket=basedao.findBySQLToMap(sql,null,-1,-1);
			return listjsapiticket;
		}
	 /*更新JsapiTicket*/
		public void updateJsapiTicket(String jsapi_Ticket) {
			String sql="update jsapiticket set jsapiticket='"+jsapi_Ticket+"',gettime=now() where id=1";
			basedao.executeSql(sql);			
		}
	 /*初始化用户中心的用户信息*/
	public List inituser(String useropenid) throws Exception {
		int idusers=0;
		List<Map<String, Object>> listinituser = new ArrayList();		
		String sql="select idusers from users where openid='"+useropenid+"'";
		List<Map<String, Object>> listusers=basedao.findBySQLToMap(sql,null,-1,-1);	
		idusers=(int)listusers.get(0).get("idusers");
		String sql1="call sumscore4user("+idusers+");"; 
		List<Map<String, Object>> query=basedao.findBySQLToMap(sql1,null,-1,-1);	
		Object totalscore4user=query.get(0).get("sumscore4uid");
		float totalscore=Float.parseFloat(totalscore4user.toString());
		String iduser=Integer.toString(idusers);
		String totalscore1=Float.toString(totalscore);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("idusers",iduser);
		map.put("totalscore", totalscore1);
		listinituser.add(map);
		return listinituser;
	}
	/*初始化用户消减列表*/
	public List<Map<String, Object>> inituserminscorelist(String useropenid) throws Exception {
		int idusers=0;
		String sql="select idusers from users where openid='"+useropenid+"'";
		List<Map<String, Object>> listusers=basedao.findBySQLToMap(sql,null,-1,-1);	
		idusers=(int)listusers.get(0).get("idusers");
		System.out.println(idusers);
		String sql1="select cuser.headurl,cuser.name,scoremlist.money,scoremlist.score,CONCAT(YEAR(scoremlist.date),'年',MONTH(scoremlist.date),'月',DAY(scoremlist.date),'日', ' ',IF(LENGTH(HOUR(scoremlist.date))=1,CONCAT(0,HOUR(scoremlist.date)),HOUR(scoremlist.date)),':',IF(LENGTH(MINUTE(scoremlist.date))=1,CONCAT(0,MINUTE(scoremlist.date)),MINUTE(scoremlist.date)),':',IF(LENGTH(SECOND(scoremlist.date))=1,CONCAT(0,SECOND(scoremlist.date)),SECOND(scoremlist.date))) AS date from scoremlist left join cuser on scoremlist.cuserid=cuser.idcuser  where isreviewed=1 and userid="+idusers;
		List<Map<String, Object>> query=basedao.findBySQLToMap(sql1,null,-1,-1);
		return query;
	}
	/*积分查询*/
	public int queryscore(String shopname, String date1, String date2,String useropenid) throws Exception {
		int idusers=0;
		List<Map<String, Object>> listinituser = new ArrayList();		
		String sql="select idusers from users where openid='"+useropenid+"'";
		List<Map<String, Object>> listusers=basedao.findBySQLToMap(sql,null,-1,-1);	
		idusers=(int)listusers.get(0).get("idusers");
		String sql1="select idscore from score where (dt BETWEEN '"+date1+"' and date_add('"+date2+"', INTERVAL 1 day)) and goodsname LIKE '%"+shopname+"%' and userid="+idusers;
		List<Map<String, Object>> query=basedao.findBySQLToMap(sql1,null,-1,-1);
		int countdata=query.size();
		return countdata;	
	}
	/*获取用户积分列表*/
	public List<Map<String, Object>> getsuserscorelist(String useropenid,String shopname, String date1, String date2) throws Exception {
		int idusers=0;
		List<Map<String, Object>> listinituser = new ArrayList();		
		String sql="select idusers from users where openid='"+useropenid+"'";
		List<Map<String, Object>> listusers=basedao.findBySQLToMap(sql,null,-1,-1);	
		idusers=(int)listusers.get(0).get("idusers");
		String sql1="select goodsname as shopname,score,money,CONCAT(YEAR(score.dt),'年',MONTH(score.dt),'月',DAY(score.dt),'日', ' ',IF(LENGTH(HOUR(score.dt))=1,CONCAT(0,HOUR(score.dt)),HOUR(score.dt)),':',IF(LENGTH(MINUTE(score.dt))=1,CONCAT(0,MINUTE(score.dt)),MINUTE(score.dt)),':',IF(LENGTH(SECOND(score.dt))=1,CONCAT(0,SECOND(score.dt)),SECOND(score.dt))) AS dt from score where (dt BETWEEN '"+date1+"' and date_add('"+date2+"', INTERVAL 1 day)) and goodsname LIKE '%"+shopname+"%' and userid="+idusers;
		List<Map<String, Object>> query=basedao.findBySQLToMap(sql1,null,-1,-1);
		return query;
	}
	public List<Map<String, Object>> getuserscorelist(String useropenid) throws Exception {
		int idusers=0;
		List<Map<String, Object>> listinituser = new ArrayList();		
		String sql="select idusers from users where openid='"+useropenid+"'";
		List<Map<String, Object>> listusers=basedao.findBySQLToMap(sql,null,-1,-1);	
		idusers=(int)listusers.get(0).get("idusers");
		String sql1="select goodsname as shopname,score,money,CONCAT(YEAR(score.dt),'年',MONTH(score.dt),'月',DAY(score.dt),'日', ' ',IF(LENGTH(HOUR(score.dt))=1,CONCAT(0,HOUR(score.dt)),HOUR(score.dt)),':',IF(LENGTH(MINUTE(score.dt))=1,CONCAT(0,MINUTE(score.dt)),MINUTE(score.dt)),':',IF(LENGTH(SECOND(score.dt))=1,CONCAT(0,SECOND(score.dt)),SECOND(score.dt))) AS dt from score where userid="+idusers;
		List<Map<String, Object>> query=basedao.findBySQLToMap(sql1,null,-1,-1);
		return query;
	}
	/*初始化物业通知列表*/
	public List<Map<String, Object>> initwynoticelist() throws Exception {
		String sql="select idnote,title,content,CONCAT(YEAR(note.dt),'年',MONTH(note.dt),'月',DAY(note.dt),'日', ' ',IF(LENGTH(HOUR(note.dt))=1,CONCAT(0,HOUR(note.dt)),HOUR(note.dt)),':',IF(LENGTH(MINUTE(note.dt))=1,CONCAT(0,MINUTE(note.dt)),MINUTE(note.dt))) AS dt from note where sendto='all' order by note.dt desc";
		List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);
		return query;
	}
	/*初始化物业通知详情列表*/
	public List<Map<String, Object>> initwynoticelist(int noteidx) throws Exception {
		String sql="call viewdetailnote("+noteidx+");";
		List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);
		return query;
	}
	/*校验用户*/
	public List<Map<String, Object>> checkuser(String useropenid) throws Exception {
		String sql="select idusers from users where openid='"+useropenid+"'";
		List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);
		return query;
	}
	/*补全用户基本信息*/
	public int adduserinfo(String username, String phone,String useroilid,String address,
			String addressid,String isdistrict,String recommentel,String openid) {
		int num=0;	
		String idusers=userService.getTableId("users");
		String sql1="insert into users(idusers,name,phone,depaid,status,address,password,useroilid,isdistrict,recommentel,openid,addressid) values(";
		sql1=sql1+idusers+",'"+username+"','";
		sql1=sql1+phone+"',1,'有效','";
		sql1=sql1+address+"','','"+useroilid+"',"+isdistrict+",'"+recommentel+"','";
		sql1=sql1+openid+"',";
		sql1=sql1+addressid+")";
		System.out.print(sql1);
		num=basedao.executeSql(sql1);
		return num;
	}
	/*初始化积分兑换列表*/
	public List<Map<String, Object>> initexchangescorelist(String useropenid) throws Exception {
		int idusers=0;
		String sql="select idusers from users where openid='"+useropenid+"'";
		List<Map<String, Object>> listusers=basedao.findBySQLToMap(sql,null,-1,-1);	
		idusers=(int)listusers.get(0).get("idusers");
		System.out.println(idusers);
		String sql1="select exchangename.logo,exchangename.name,scoreexchange.score,CONCAT(YEAR(scoreexchange.dt),'年',MONTH(scoreexchange.dt),'月',DAY(scoreexchange.dt),'日', ' ',IF(LENGTH(HOUR(scoreexchange.dt))=1,CONCAT(0,HOUR(scoreexchange.dt)),HOUR(scoreexchange.dt)),':',IF(LENGTH(MINUTE(scoreexchange.dt))=1,CONCAT(0,MINUTE(scoreexchange.dt)),MINUTE(scoreexchange.dt)),':',IF(LENGTH(SECOND(scoreexchange.dt))=1,CONCAT(0,SECOND(scoreexchange.dt)),SECOND(scoreexchange.dt))) AS date from scoreexchange left join exchangename on scoreexchange.changenameid=exchangename.idexchangename where userid="+idusers;
		List<Map<String, Object>> query=basedao.findBySQLToMap(sql1,null,-1,-1);
		return query;
	}
	/*用户物业报修申请*/
	public int userapplicationwyfix(String fixname, String fixaddress,String fixtime, String problemcontents, String contact,String contacttel, String openid) {
		// TODO Auto-generated method stub
		int num=0;
		String idfix=userService.getTableId("wyfixinfo");
		String sql1="insert into wyfixinfo(idfix,fixname,fixaddress,fixtime,problemcontents,contact,contacttel,applicationopenid,status) values(";
		sql1=sql1+idfix+",'"+fixname+"','";
		sql1=sql1+fixaddress+"','";
		sql1=sql1+fixtime+"','";
		sql1=sql1+problemcontents+"','";
		sql1=sql1+contact+"','";
		sql1=sql1+contacttel+"','";
		sql1=sql1+openid+"',1);";
		String sql2="insert into wyfixjd(jdinfo,idfix) values('";
		sql2=sql2+contact+"提交了报修申请。',"+idfix+");";
		System.out.println(sql1);
		basedao.executeSql("begin");
		basedao.executeSql(sql1);
		basedao.executeSql(sql2);
		num=basedao.executeSql("commit");
		return num;
	}
	/*商户列表*/
	public List<Map<String, Object>> getusersellerlist() throws Exception {
		String sql="select name,address,phone from cuser";
		List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);
		return query;
	}
	/*地址列表*/
	public List<Map<String, Object>> getaddresslist(String id) throws Exception {
		String sql="select * from address where pid="+id;
		List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);
		return query;
	}
	/*初始化用户信息列表*/
	public List<Map<String, Object>> inituserinfolist(String useropenid) throws Exception {
		String sql="select * from users where openid='"+useropenid+"'";
		List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);	
		return query;
	}
	/*修改用户信息*/
	public int changeuserinfo(String username, String phone, String useroilid,
			String address, String isdistrict, String recommentel, String openid) {
		int num=0;	
		String sql1="update users set name='"+username+"',phone='"+phone+"',address='"+address+"',useroilid='"+useroilid+"',isdistrict="+isdistrict+",recommentel='"+recommentel+"' where openid='"+openid+"'";
		System.out.print(sql1);
		num=basedao.executeSql(sql1);
		return num;
	}
	
	
}
