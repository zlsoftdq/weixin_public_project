package com.zfrj.wechat.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import com.zfrj.base.dao.BaseDAO;
import com.zfrj.yzb.base.service.IUserService;

@Service
public class WechatSellerService {
	@Autowired
	BaseDAO basedao;
	@Autowired
	IUserService userService;
	/*验证原密码是否正确*/
	 public  List<Map<String, Object>> checkuser(int idcuser,String oldpwd) throws Exception{
		   String sql="select idcuser from cuser where idcuser="+idcuser+" and password='"+oldpwd+"'";
		   List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);	
			return query;		   
	   }
	 /*获取商户信息*/
	 public  List<Map<String, Object>> listuser(int idcuser) throws Exception{
		   String sql="select cuser.name,cuser.address,cuser.phone,cuser.contacts,cuser.bz,cuser.headurl,cclass.classname from cuser left join cclass on cuser.classid=cclass.idcclass where idcuser="+idcuser;
		   List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);	
			return query;		   
	   }
	 /*验证登录*/
	 public  List<Map<String, Object>> checklogin(String username,String pwd) throws Exception{
		   String sql="select idcuser from cuser where uname='"+username+"' and password='"+pwd+"'";
		   List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);	
			return query;		   
	   }
	 /*修改密码 */
	 public int updatepwd(String newpwd,int idcuser) {
			String sql="update cuser set password='"+newpwd+"' where idcuser="+idcuser;
			int num=basedao.executeSql(sql);	
			return num;
		}
	 /*消减积分客户处理*/
		public List minscore2customer(int cuserid, int userid, float minmoney,String minreason) throws Exception {
		    int num=0;	
			String sql="select cuser.name,cuser.phone,cuser.contacts,cclass.percentage,cclass.classname from cuser left join cclass on cuser.classid=cclass.idcclass where idcuser="+cuserid;
		    List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);	
		    List list1 = new ArrayList();
			if(query.size()==1){
				String shopname=(String)query.get(0).get("name");
				String class1=(String)query.get(0).get("classname");
				Object percentage1=(Object)query.get(0).get("percentage");
				float percentage=Float.parseFloat(percentage1.toString());
				String shoptel=(String)query.get(0).get("phone");
				float minscore=minmoney*percentage;
				float totalscore=getcustomersumscore(userid);
				String minscore1=Float.toString(minscore);
				String totalscore1=Float.toString(totalscore);
				if(minscore<totalscore){
					String sql1="insert into scoremlist(idscoremlist,class,goodsname,money,score,type,userid,cuserid,minreason,isreviewed) values(";
					sql1=sql1+userService.getTableId("scoremlist")+",'"+class1+"','"+shopname+"','";
					sql1=sql1+minmoney+"','";
					sql1=sql1+minscore+"','客户',";
					sql1=sql1+userid+",";
					sql1=sql1+cuserid+",'";
					sql1=sql1+minreason+"',1)";	
					num=basedao.executeSql(sql1);
				}
				else{
					num=-1;
				}
				list1.add(0,num);
				list1.add(1,minscore1);
				list1.add(2,totalscore1);
				list1.add(3,shoptel);
		   }
			return list1;
		}
		 /*消减积分物业处理*/
			public int minscore2property(int cuserid, int userid, float minmoney,String minreason) throws Exception {
			    int num=0;	
				String sql="select cuser.name,cuser.phone,cuser.contacts,cclass.percentage,cclass.classname from cuser left join cclass on cuser.classid=cclass.idcclass where idcuser="+cuserid;
			    List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);	
				if(query.size()==1){
					String shopname=(String)query.get(0).get("name");
					String class1=(String)query.get(0).get("classname");
					Object percentage1=(Object)query.get(0).get("percentage");
					float percentage=Float.parseFloat(percentage1.toString());
					float minscore=minmoney*percentage;
					if(minscore<getcustomersumscore(userid)){
						String sql1="insert into scoremlist(idscoremlist,class,goodsname,money,score,type,userid,cuserid,minreason,isreviewed) values(";
						sql1=sql1+userService.getTableId("scoremlist")+",'"+class1+"','"+shopname+"','";
						sql1=sql1+minmoney+"','";
						sql1=sql1+minscore+"','物业',";
						sql1=sql1+userid+",";
						sql1=sql1+cuserid+",'";
						sql1=sql1+minreason+"',0)";	
						num=basedao.executeSql(sql1);
					}
					else{
						num=-2;
					}
			   }
				return num;
			}
	 /*增加积分*/
	public List addscore(int cuserid, int userid, float money) throws Exception {
	    int num=0;	
	    int num1=0;
		String sql="select cuser.name,cuser.phone,cuser.contacts,cclass.percentage,cclass.gainpercentage from cuser left join cclass on cuser.classid=cclass.idcclass where idcuser="+cuserid;
	    List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);	
	    List list1 = new ArrayList();
		if(query.size()==1){
			String shopname=(String)query.get(0).get("name");
			System.out.println(1);
			Object percentage1=(Object)query.get(0).get("percentage");
			float percentage=Float.parseFloat(percentage1.toString());
			float score=money*percentage;
			System.out.println(1);
			String score1=Float.toString(score);
			String idscore=userService.getTableId("score");
			String sql1="insert into score(idscore,goodsname,money,score,userid,cuserid,modifyby,shstatus) values(";
			sql1=sql1+idscore+",'"+shopname+"','";
			sql1=sql1+money+"','";
			sql1=sql1+score+"','";
			sql1=sql1+userid+"','";
			sql1=sql1+cuserid+"',' ','有效')";		
			Object gainpercentage1=(Object)query.get(0).get("gainpercentage");
			float gainpercentage=Float.parseFloat(gainpercentage1.toString());
			float gainscore=money*gainpercentage;
			String gainscore2=Float.toString(gainscore);
			String idgainscore=userService.getTableId("gainscore");
			String sql2="insert into gainscore(idgainscore,gainscore,userid,cuserid) values(";
			sql2=sql2+idgainscore+",'"+gainscore2+"','"+userid+"','"+cuserid+"')";
			basedao.executeSql("begin");
			basedao.executeSql(sql1);
			basedao.executeSql(sql2);
			num=basedao.executeSql("commit");
			float totalscore=getcustomersumscore(userid);
			String totalscore1=Float.toString(totalscore);			
			Date now = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy年MM月dd日 HH:mm");
			String getscoretime = dateFormat.format(now); 
			list1.add(0,num);
			list1.add(1,shopname);
			list1.add(2,score1);
			list1.add(3,getscoretime);
			list1.add(4,totalscore1);
	   }
		return list1;
	}
	/*验证是否存在客户*/
	 public  List<Map<String, Object>> checkcustomer(int idusers) throws Exception{
		   String sql="select idusers,name,phone,openid from users where idusers="+idusers;
		   List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);	
			return query;		   
	   }
	 public  List<Map<String, Object>> checkcustomer(String usertel) throws Exception{
		   String sql="select idusers,name,phone,openid from users where phone='"+usertel+"'";
		   List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);	
			return query;		   
	   }
	 public  List<Map<String, Object>> checkcustomer4customername(String customername) throws Exception{
		   String sql="select idusers from users where name='"+customername+"'";
		   List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);	
			return query;		   
	   }
	 /*验证是否查询到此查询条件的积分信息*/
	 public  int queryscore(int userid,String date1,String date2,int cuserid) throws Exception{
		   String sql="select idscore from score where (dt BETWEEN '"+date1+"' and date_add('"+date2+"', INTERVAL 1 day)) and userid="+userid+" and cuserid="+cuserid;
		   List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);
		   int countdata=query.size();
		   return countdata;		   
	   }
	 /*修改商户信息*/
	public int updateshopinfo(String address, String phone, String contacts,String contacttel,String bz, int idcuser) {
		String sql="update cuser set address='"+address+"',phone='"+phone+"',contacts='"+contacts+"',contacttel='"+contacttel+"',bz='"+bz+"' where idcuser="+idcuser;
		int num=basedao.executeSql(sql);	
		return num;
	}
	 /*积分列表*/
	 public List<Map<String, Object>> getshopscorelist(int cuserid) throws Exception {
		String sql="select users.idusers,INSERT(users.phone,4,5,'****') as phone,IF(LENGTH(users.name)=6,INSERT(name,2,3,'*'),INSERT(name,2,4,'**')) as name,score.money,CONCAT(YEAR(score.dt),'年',MONTH(score.dt),'月',DAY(score.dt),'日', ' ',IF(LENGTH(HOUR(score.dt))=1,CONCAT(0,HOUR(score.dt)),HOUR(score.dt)),':',IF(LENGTH(MINUTE(score.dt))=1,CONCAT(0,MINUTE(score.dt)),MINUTE(score.dt)),':',IF(LENGTH(SECOND(score.dt))=1,CONCAT(0,SECOND(score.dt)),SECOND(score.dt))) AS dt from score left join users on score.userid=users.idusers where score.cuserid="+cuserid+" order by score.dt desc";
		List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);	
		return query;		   
	}
	 public List<Map<String, Object>> getshopscorelist(int userid,int cuserid,String date1,String date2) throws Exception {
			String sql="select users.idusers,INSERT(users.phone,4,5,'****') as phone,IF(LENGTH(users.name)=6,INSERT(name,2,3,'*'),INSERT(name,2,4,'**')) as name,score.money,CONCAT(YEAR(score.dt),'年',MONTH(score.dt),'月',DAY(score.dt),'日', ' ',IF(LENGTH(HOUR(score.dt))=1,CONCAT(0,HOUR(score.dt)),HOUR(score.dt)),':',IF(LENGTH(MINUTE(score.dt))=1,CONCAT(0,MINUTE(score.dt)),MINUTE(score.dt)),':',IF(LENGTH(SECOND(score.dt))=1,CONCAT(0,SECOND(score.dt)),SECOND(score.dt))) AS dt from score left join users on score.userid=users.idusers where (score.dt BETWEEN '"+date1+"' and date_add('"+date2+"', INTERVAL 1 day)) and score.cuserid="+cuserid+" and score.userid="+userid+" order by score.dt desc";
			List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);	
			return query;		   
	}
	 public List<Map<String, Object>> getshopscorelist(String date1,String date2,String usertel,int cuserid) throws Exception {
			String sql="select users.idusers,INSERT(users.phone,4,5,'****') as phone,IF(LENGTH(users.name)=6,INSERT(name,2,3,'*'),INSERT(name,2,4,'**')) as name,score.money,CONCAT(YEAR(score.dt),'年',MONTH(score.dt),'月',DAY(score.dt),'日', ' ',IF(LENGTH(HOUR(score.dt))=1,CONCAT(0,HOUR(score.dt)),HOUR(score.dt)),':',IF(LENGTH(MINUTE(score.dt))=1,CONCAT(0,MINUTE(score.dt)),MINUTE(score.dt)),':',IF(LENGTH(SECOND(score.dt))=1,CONCAT(0,SECOND(score.dt)),SECOND(score.dt))) AS dt from score left join users on score.userid=users.idusers where (score.dt BETWEEN '"+date1+"' and date_add('"+date2+"', INTERVAL 1 day)) and score.cuserid="+cuserid+" and users.phone='"+usertel+"' order by score.dt desc";
			List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);	
			return query;		   
	}
	 public List<Map<String, Object>> getshopscorelist(String customername,int cuserid,String date1,String date2) throws Exception {
			String sql="select users.idusers,INSERT(users.phone,4,5,'****') as phone,IF(LENGTH(users.name)=6,INSERT(name,2,3,'*'),INSERT(name,2,4,'**')) as name,score.money,CONCAT(YEAR(score.dt),'年',MONTH(score.dt),'月',DAY(score.dt),'日', ' ',IF(LENGTH(HOUR(score.dt))=1,CONCAT(0,HOUR(score.dt)),HOUR(score.dt)),':',IF(LENGTH(MINUTE(score.dt))=1,CONCAT(0,MINUTE(score.dt)),MINUTE(score.dt)),':',IF(LENGTH(SECOND(score.dt))=1,CONCAT(0,SECOND(score.dt)),SECOND(score.dt))) AS dt from score left join users on score.userid=users.idusers where (score.dt BETWEEN '"+date1+"' and date_add('"+date2+"', INTERVAL 1 day)) and score.cuserid="+cuserid+" and users.name='"+customername+"' order by score.dt desc";
			List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);	
			return query;		   
	}
	 /*计算客户当前总积分*/
	 public float getcustomersumscore(int userid) throws Exception {
		 String sql="call sumscore4user("+userid+");"; 
		 List<Map<String, Object>> query=basedao.findBySQLToMap(sql,null,-1,-1);	
		 Object sumscore4customer=query.get(0).get("sumscore4uid");
		 float sumscore4customer1=Float.parseFloat(sumscore4customer.toString());
		 return sumscore4customer1;
	}
	public int sellerapplicationwyfix(String fixname, String fixaddress,
			String fixtime, String problemcontents, String contact,
			String contacttel, String openid) {
		int num=0;
		String idfix=userService.getTableId("wyfixinfo");
		String sql1="insert into wyfixinfo(idfix,fixname,fixaddress,fixtime,problemcontents,contact,contacttel,applicationopenid,status) values(";
		sql1=sql1+idfix+",'"+fixname+"','";
		sql1=sql1+fixaddress+"','";
		sql1=sql1+fixtime+"','";
		sql1=sql1+problemcontents+"','";
		sql1=sql1+contact+"','";
		sql1=sql1+contacttel+"','";
		sql1=sql1+openid+"',1);";
		String sql2="insert into wyfixjd(jdinfo,idfix) values('";
		sql2=sql2+contact+"提交了报修申请。',"+idfix+");";
		System.out.println(sql1);
		basedao.executeSql("begin");
		basedao.executeSql(sql1);
		basedao.executeSql(sql2);
		num=basedao.executeSql("commit");
		return num;
	}
	 
}
