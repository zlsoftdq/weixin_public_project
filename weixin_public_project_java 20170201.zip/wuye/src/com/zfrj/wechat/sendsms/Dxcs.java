package com.zfrj.wechat.sendsms;

public class Dxcs {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String code=SendSms.createVerificationCode();
		//SendSms.sendVerificationCode(url,appkey,secret,freeSignName,telno,smsTemplateCode, "{\"number\":\""+code+"\"}");
		boolean result=SendSms.sendVerificationCode("http://gw.api.taobao.com/router/rest","23395966","c838770f761db081343d82ce585115b0","登峰家园","15845889674","SMS_11360183", "{\"number\":\""+code+"\"}");
		if(result)
		{
			System.out.println("发送成功！");
	    }
		else{
			System.out.println("发送失败！");
			}
	}

}
