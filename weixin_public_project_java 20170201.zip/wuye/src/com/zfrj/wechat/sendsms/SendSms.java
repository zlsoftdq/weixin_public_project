package com.zfrj.wechat.sendsms;

import net.sf.json.JSONException;
import net.sf.json.JSONObject;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.request.AlibabaAliqinFcSmsNumSendRequest;
import com.taobao.api.response.AlibabaAliqinFcSmsNumSendResponse;
import com.zfrj.wechat.util.AliSnsInfo;

public class SendSms {

	/**
	 * 发送验证码
	 * @param 接收方手机号
	 * @param 短信模板编号
	 * @param 短信模板传递参数（JSON数据格式）
	 * @throws Exception
	 */
	public static boolean sendVerificationCode(String url,String appkey,String secret,String freeSignName,String telno,String smsTemplateCode,String smsParamString) throws Exception{

		boolean result=false;
		TaobaoClient client = new DefaultTaobaoClient(url,appkey,secret);
		AlibabaAliqinFcSmsNumSendRequest req = new AlibabaAliqinFcSmsNumSendRequest();
		req.setExtend("");
		req.setSmsType("normal");
		req.setSmsFreeSignName(freeSignName);
		req.setSmsParamString(smsParamString);
		req.setRecNum(telno);
		req.setSmsTemplateCode(smsTemplateCode);
		AlibabaAliqinFcSmsNumSendResponse rsp = client.execute(req);
		String out4checkjson=rsp.getBody();
		//System.out.println(out4checkjson);
		JSONObject jsonObject=JSONObject.fromObject(out4checkjson);
		if (null != jsonObject) {
			try{
			String result4string=jsonObject.getString("alibaba_aliqin_fc_sms_num_send_response");
			result=true;
			//System.out.println(result4string);
			  }
			  catch (JSONException e)
			  {
				  result=false;
				  System.out.println("JSONObject key not found"); 
			  }
		}
	
		return result;
	}
	/**
	 * 生成验证码方法
	 * @return 生成的验证码
	 */
	public static String createVerificationCode(){
		int code=(int)((Math.random()*9+1)*100000);
		String verificationCode=String.valueOf(code);
		return verificationCode;
	}

	
}
