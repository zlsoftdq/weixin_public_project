function myalert(message) {	
	$("#alert_error").html(message);
    $("#myalert").modal();  
}