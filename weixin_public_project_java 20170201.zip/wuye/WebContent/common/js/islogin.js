/*商户中心*/
/*是否登录*/
var islogin=function (){
		var user = $("#user").html();
		if(user == "null"){
		 alert("登录超时！请重新登录！");
		 window.location.href ="seller/login.htm";
         }
   }