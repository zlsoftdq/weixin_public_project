  $("#address").cityPicker({
    toolbarTemplate: '<header class="bar bar-nav">\
    <button class="button button-link pull-right close-picker">确定</button>\
    <h1 class="title">选择您的住宅地址</h1>\
    </header>'
  });
  
  $("#fixaddress").cityPicker({
	    toolbarTemplate: '<header class="bar bar-nav">\
	    <button class="button button-link pull-right close-picker">确定</button>\
	    <h1 class="title">选择维修地点</h1>\
	    </header>'
	  });