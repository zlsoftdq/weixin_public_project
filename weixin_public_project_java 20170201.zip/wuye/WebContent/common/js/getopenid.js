(function ()  {  
	//addcookie('wxopenid','owTHowLEVOPsA-V4pBLJwu3dF5qM',360);            
    var wxopenid=getcookie('wxopenid');  
    var access_code=GetQueryString('code');
    var fromurl=location.href;  
 // alert(wxopenid);
        if (wxopenid==null){  
            if (access_code=="")  
            {                    
                var url='https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx1447cb4b5d5a3196&redirect_uri='+encodeURIComponent(fromurl)+'&response_type=code&scope=snsapi_base&state=1#wechat_redirect';  
               // alert(url);
                location.href=url;  
                
            }  
            else  
            {     
            	//alert(access_code);
                $.ajax({  
                    type:'get',  
                    url:'user/getopenidajax.htm',   
                    async:false,  
                    cache:false,  
                    data:{code:access_code},  
                    dataType:'text',  
                    success:function(result){                   
                            if (result!=null && result!=""){  
                            	//alert(result);
                               addcookie('wxopenid',result,360);                             
                               isinituser(result);  
                            }   
                            else  
                            {  
                              //alert('微信身份识别失败 \n '+result); 
                            	//alert(fromurl);
                            	window.location.href=fromurl;  
                            }  
                        }  
                    });      
            }  
        }else{  
        	  isinituser(wxopenid);    
        }  

        function isinituser(wxopenid){      
        	//alert(wxopenid);
        $.post("user/checkuseropenid.htm",{openid:wxopenid},function(data) {
   	             if(data=="0")
   	             {
   		            $.toast("为了更好的为您服务，请补全基础信息!");
   		             setTimeout(function(){window.location.href ="user/inituser.htm?openid="+wxopenid;},1000);
   		         }
              },"text"); 
        } 
     
})();  