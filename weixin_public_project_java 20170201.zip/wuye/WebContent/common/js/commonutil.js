/*set cookie*/  
function addcookie(name, value, Days){  
    if(Days == null || Days == ''){  
        Days = 360;  
    }  
    var exp  = new Date();  
    exp.setTime(exp.getTime() + Days*24*60*60*1000);  
    document.cookie = name + "="+ escape (value) + "; path=/;expires=" + exp.toGMTString();  
    //document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();  
}  
  
/*get cookie*/  
function getcookie(name) {  
    var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");  
    if(arr=document.cookie.match(reg))  
        return unescape(arr[2]);   
    else   
        return null;   
}  
var GetUrlParms=function(){
    var args=new Object();
    var query=location.search.substring(1);//获取查询串
    var pairs=query.split("&");//在逗号处断开
    for(var i=0;i<pairs.length;i++)
    {
        var pos=pairs[i].indexOf('=');//查找name=value
            if(pos==-1)   continue;//如果没有找到就跳过
            var argname=pairs[i].substring(0,pos);//提取name
            var value=pairs[i].substring(pos+1);//提取value
            args[argname]=decodeURI(value);//存为属性
    }
    return args;
}

function GetQueryString(name) {  
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");  
    var r = window.location.search.substr(1).match(reg);  //获取url中"?"符后的字符串并正则匹配
    var context = "";  
    if (r != null)  
         context = r[2];  
    reg = null;  
    r = null;  
    return context == null || context == "" || context == "undefined" ? "" : context;  
}

var test=function(){
	$.toast("测试中！");
}
