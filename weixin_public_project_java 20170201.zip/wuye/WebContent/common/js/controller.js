

$("#isdistrict").change(function(){
	if($("#isdistrict").prop("checked")){
		$("#isdistrict").val(1);
		$("#li4address").attr("style","display:none;");
		$("address").val("");
		$("#li4recommentel").attr("style","display:block;");
	}
	else{
		$("#isdistrict").val(0);
		$("#li4recommentel").attr("style","display:none;");
		$("#recommentel").val("");
		$("#li4address").attr("style","display:block;");
	}
});
/*商户中心*/
/*初始化商户信息*/
var initshopinfo= function (){
	 var user = $("#user").html();
		if(user == "null"){
		 $.toast("登录超时！请重新登录！");
     setTimeout(function(){window.location.href ="seller/login.htm";},1000);
		}
		else{
			 $.post("seller/ajaxlist4shopinfo.htm",{"userid":user},function(data){
				$("#shopname").text(data.name);
			 	$("#address").val(data.address);
			 	$("#phone").val(data.phone);
			 	$("#classname").text(data.classname);
			 	$("#contacts").val(data.contacts);
			 	$("#bz").val(data.bz);
			 },"json");
		}
 }
 /*初始化提交给客户审核*/
var initminsorelist2customer=function(){
	 var user = $("#user").html();
		if(user == "null"){
		 $.toast("登录超时！请重新登录！");
     setTimeout(function(){window.location.href ="seller/login.htm";},1000);
		}
		else{
			var usertel= $("#s4usertelno").html();
			var minmoney = $("#s4minmoney").html();
			$("#usertel").val(usertel);
			$("#minmoney").val(minmoney);
		}
}

 /*初始化商户积分列表*/
var initsorelistinfo=function(){
	 var user = $("#user").html();
	 var customername="";
	 var countid="";
	 var usertel="";
	 var date1="";
	 var date2="";

	 if(user == "null"){
		 $.toast("登录超时！请重新登录！");
		 setTimeout(function(){window.location.href ="seller/login.htm";},1000);
		}
		else{
			var args = new Object();
			 args = GetUrlParms();
			 if(args["customername"]!=undefined||args["customername"]!="")
				{
				  	customername = args["customername"] ;
				}
			 if(args["countid"]!=undefined||args["countid"]!="")
				{
				 	countid = args["countid"] ;
				}
			 if(args["usertel"]!=undefined||args["usertel"]!="")
				{
				 	usertel = args["usertel"] ;
				}
			 if(args["date1"]!=undefined||args["date1"]!="")
				{
				 	date1 = args["date1"] ;
				}
			 if(args["date2"]!=undefined||args["date2"]!="")
				{
				 	date2 = args["date2"] ;
				}

			if(customername!= null||countid!= null||usertel!= null||date1!= null||date2!=null){
				$.post("seller/ajaxscorelist.htm",{"customername":customername,"countid":countid,"usertel":usertel,"date1":date1,"date2":date2},function(data){
	                if($.isEmptyObject(data)){
	                	 $.toast("没有找到积分记录！");
	                     setTimeout(function(){window.location.href ="seller/shopcenter.htm";},1000);
	                 }
	                else{
	                	$("#scorelist").children("li").remove();
	                	for(var i=0;i<data.length;i++){
	                		$("#scorelist").append("<li class=\"item-content\"><div class=\"item-inner\"><div class=\"item-title-row\"><div class=\"item-title\">计分ID："+data[i].idusers+" </div><div class=\"item-after\">客户姓名："+data[i].name+" ("+data[i].phone+")</div></div> <div class=\"item-subtitle\">消费金额："+data[i].money+"元 </div><div class=\"item-text\">积分日期： "+data[i].dt+"</div></div></li>");
	                	}
	                	} },"json");
				}
				else{
				$.post("seller/ajaxscorelist.htm",{"userid":user},function(data){
	                if($.isEmptyObject(data)){
	                	 $.toast("没有找到积分记录！");
	                     setTimeout(function(){window.location.href ="seller/shopcenter.htm";},1000);
	                 }
	                else{
	                	$("#scorelist").children("li").remove();
	                	for(var i=0;i<data.length;i++){
	                		$("#scorelist").append("<li class=\"item-content\"><div class=\"item-inner\"><div class=\"item-title-row\"><div class=\"item-title\">计分ID："+data[i].idusers+" </div><div class=\"item-after\">客户姓名："+data[i].name+" ("+data[i].phone+")</div></div> <div class=\"item-subtitle\">消费金额："+data[i].money+"元 </div><div class=\"item-text\">积分日期： "+data[i].dt+"</div></div></li>");
	                	}
	                	} },"json");
				}


		}
}
/*商户物业报修申请处理逻辑*/
$("#btnsellerapplicationwyfix").click(function () {
    if (!wyfixsellerapplicationvalidateInput()) return;
      $(this).attr("disabled", "disabled").val("正在处理...");
      var datafixname=$("#fixname").val();
      var datafixaddress = $("#fixaddress").val();
      var datafixtime=$("#fixtime").val();
      var dataproblemcontents=$("#problemcontents").val();
      var datacontact=$("#contact").val();
      var datacontacttel=$("#contacttel").val();
      var dataopenid = $("#userss").html();

$.post("seller/Validatesellerapplicationwyfix.htm",{fixname:datafixname,fixaddress:datafixaddress,fixtime:datafixtime,problemcontents:dataproblemcontents,contact:datacontact,contacttel:datacontacttel,openid:dataopenid},function(data) {
        $("#btnsellerapplicationwyfix").removeAttr("disabled").val("提交");
        if(data=="1")
        {
       $.toast("操作成功!正在为你跳转到商户中心..");
        setTimeout(function(){window.location.href ="seller/shopcenter.htm";},1000);
       }
       else{
        $.toast("服务器异常，请重新提交以上信息！");
       }
}, "text");
});
 /*商户登录处理逻辑*/
$("#btnlogin").click(function () {
                            if (!shoploginvalidateInput()) return;
                              $(this).attr("disabled", "disabled").val("正在登录...");
                              var datauser=$("#uname").val();
                              var datapwd = $("#pwd").val();
                              var datacode=$("#yzcode").val();

                  $.post("seller/Validatelogin.htm",{username:datauser,password:datapwd,code:datacode},function(data) {
                                $("#btnlogin").removeAttr("disabled").val("登录");
                                if(data=="0")
                                {
                                $.toast("验证码输入错误，请重新输入!");
                                $("#yzcode").val("");
                                $("#imgcode").attr("src", "safecode?" + Math.random());
                                }else if(data=="1")
                                {
                               $.toast("登录成功，正在跳转!");
                                setTimeout(function(){window.location.href ="seller/shopcenter.htm";},1000);
                            }else if(data=="-1"){
                                 $.toast("用户名或密码错误，请重新输入！");
                                 $("#yzcode").val("");
                                 $("#imgcode").attr("src", "safecode?" + Math.random());
                            }
                               else{
                                $.toast("服务器异常，请重新提交以上信息！");
                           }
                     }, "text");
         });
/*商户修改密码处理逻辑*/
     $("#btnchangepwd").click(function () {
         if (!changeshoppwdvalidateInput()) return;
           $(this).attr("disabled", "disabled").val("正在处理...");
           var datapwd=$("#oldpwd").val();
           var datanewpwd = $("#newpwd").val();
           var datacode=$("#yzcode").val();

$.post("seller/Validatechangepwd.htm",{password:datapwd,newpassword:datanewpwd,code:datacode},function(data) {
             $("#btnchangepwd").removeAttr("disabled").val("确定");
             if(data=="0")
             {
             $.toast("验证码输入错误，请重新输入!");
             $("#yzcode").val("");
             $("#imgcode").attr("src", "safecode?" + Math.random());
             }else if(data=="1")
             {
            $.toast("修改密码成功，请牢记您的密码!");
             setTimeout(function(){window.location.href ="seller/shopcenter.htm";},1000);
         }else if(data=="-1"){
              $.toast("原密码输入错误，请重新输入！");
              $("#yzcode").val("");
              $("#imgcode").attr("src", "safecode?" + Math.random());
         }
            else{
             $.toast("服务器异常，请重新提交以上信息！");
        }
  }, "text");
});
     /*发送手机验证码业务逻辑*/
     $("#sendmincode").click(function () {

    	 var datausertel = $("#usertel").val();
    	 var datasmsTemplateCode="SMS_11051106";
    	 var validCode=true;
    	 var time=60;
			var code=$(this);
			if (validCode) {
				validCode=false;
				code.attr("class","button disabled");
			var t=setInterval(function  () {
				time--;
				code.val(time+"秒后可重新获取");
				if (time==0) {
					clearInterval(t);
				code.val("重新获取");

					validCode=true;
					code.attr("class","button  button-fill active");
				}
			},1000);

			}
    	 $.post("seller/sendminscoresms.htm",{telno:datausertel,smstemplatecode:datasmsTemplateCode},function(data) {
    		 if(data=="1")
             {
             $.toast("发送成功!");
             }
            else{
             $.toast("服务器异常，请重新获取验证码！");
        }

  }, "text");
});
  /*商户积分消减提交给客户处理逻辑*/
     $("#btntocustomer").click(function () {
         if (!shopminscorevalidateInput()) return;
           $(this).attr("disabled", "disabled").val("正在处理...");
           var datacountid=$("#countid").val();
           var datausertel = $("#usertel").val();
           var dataminmoney=$("#minmoney").val();
           var dataminreason=$("#minreason").val();

$.post("seller/Validatetocustomerminscore.htm",{countid:datacountid,usertel:datausertel,minmoney:dataminmoney,minreason:dataminreason},function(data) {
             $("#btntocustomer").removeAttr("disabled").val("提交客户审核");
             if(data!=-1){
	             if(data=="1")
	             {
	                $.toast("正在跳转，请稍侯!");
	                setTimeout(function(){window.location.href ="seller/shopminscore2customer.htm";},1000);
	             }
	             else{
	                 $.toast("服务器异常，请重新提交以上信息！");
	            }
             }
             else{
            	 $.toast("没有找到此客户的信息，请与客户确认！");
             }
  }, "text");
});
     /*商户积分消减提交给物业审核处理逻辑*/
     $("#btntoproperty").click(function () {
         if (!shopminscorevalidateInput()) return;
           $(this).attr("disabled", "disabled").val("正在处理...");
           var datacountid=$("#countid").val();
           var datausertel = $("#usertel").val();
           var dataminmoney=$("#minmoney").val();
           var dataminreason=$("#minreason").val();

		$.post("seller/Validatetopropertyminscore.htm",{countid:datacountid,usertel:datausertel,minmoney:dataminmoney,minreason:dataminreason},function(data) {
	             $("#btntoproperty").removeAttr("disabled").val("提交物业审核");
	             if(data!=-1){
		             if(data=="1")
		             {
		            	 $.toast("提交成功!");
			             setTimeout(function(){window.location.href ="seller/shopcenter.htm";},1000);
			         }
		             else if(data=="-2"){
			        	 $.toast("客户的积分不足，无法完成消减提交！");
			         }
		             else{
		            	 $.toast("服务器异常，请重新提交以上信息！");
		             }
				 }
		        else{
		       	 $.toast("没有找到此客户的信息，请与客户确认！");
		        }
		  }, "text");
});
     /*客户削减积分处理逻辑*/
     $("#minsore2customer").click(function () {
         if (!minscore2comstomervalidateInput()) return;
           $(this).attr("disabled", "disabled").val("正在处理...");
           var datausertel = $("#usertel").val();
           var dataminmoney=$("#minmoney").val();
           var datacode=$("#telcode").val();

		$.post("seller/Validate2customerminscore.htm",{usertel:datausertel,minmoney:dataminmoney,code:datacode},function(data) {
		         $("#minsore2customer").removeAttr("disabled").val("提交");
		         if(data=="0")
		         {
		        	 $.toast("验证码输入错误，请重新输入!");
		         }else if(data=="1")
		         {
		        	 $.toast("消减积分成功!");
		             setTimeout(function(){window.location.href ="seller/shopcenter.htm";},1000);
		         }else if(data=="-1"){
		        	 $.toast("客户的积分不足，无法完成消减！");
		        	 setTimeout(function(){window.location.href ="seller/shopminscore.htm";},1000);
		         }
		         else{
		        	 $.toast("服务器异常，请重新提交以上信息！");
		             }
		  }, "text");
});

     /*查询用户积分处理逻辑*/
     $("#querycustomerscore").click(function () {
         if (!queryuserscorevalidateInput()) return;
           $(this).attr("disabled", "disabled").val("正在查询...");
           var datacustomername=$("#customername").val();
           var datacustomeruserid = $("#countid").val();
           var datausertel=$("#customertel").val();
           var datadate1=$("#date1").val();
           var datadate2=$("#date2").val();

$.post("seller/ajax4querycustomerscore.htm",{customername:datacustomername,countid:datacustomeruserid,usertel:datausertel,date1:datadate1,date2:datadate2},function(data) {
             $("#querycustomerscore").removeAttr("disabled").val("查询");
            if(data=="1")
             {
                $.toast("正在跳转，请稍侯!");
                setTimeout(function(){window.location.href ="seller/scorelist.htm?customername="+datacustomername+"&countid="+datacustomeruserid+"&usertel="+datausertel+"&date1="+datadate1+"&date2="+datadate2;},1000);
             }else if(data=="-2"){
                 $.toast("没有找到此客户积分的信息！");
             }else if(data=="-1"){
                 $.toast("没有找到此客户的信息，请与客户确认！");
             }
             else{
                 $.toast("服务器异常，请重新提交以上信息！");
            }

	}, "text");
});
     /*增加积分处理逻辑*/
     $("#btnaddscore").click(function () {
         if (!adduserscorevalidateInput()) return;
           $(this).attr("disabled", "disabled").val("正在处理...");
           var datacountid=$("#countid").val();
           var datausertel = $("#usertel").val();
           var datamoney = $("#money").val();

$.post("seller/ajax4addscore.htm",{countid:datacountid,usertel:datausertel,money:datamoney},function(data) {
             $("#btnaddscore").removeAttr("disabled").val("提交");
             if(data!=-1){
	             if(data=="1")
	             {
	                $.toast("操作成功!");
	                setTimeout(function(){window.location.href ="seller/scorelist.htm";},1000);
	             }else if(data=="-2"){
	                 $.toast("操作失败，请重新提交！");
	             }
	             else{
	                 $.toast("服务器异常，请重新提交以上信息！");
	            }
             }
             else{
            	 $.toast("没有找到此客户的信息，请与客户确认！");
             }
  }, "text");
});
     /*修改商户信息处理逻辑*/
     $("#btnchangeshopinfo").click(function () {
         if (!changeshopinfovalidateInput()) return;
           $(this).attr("disabled", "disabled").val("正在处理...");
           var dataaddress=$("#address").val();
           var dataphone = $("#phone").val();
           var datacontacts=$("#contacts").val();
           var datacontacttel=$("#contacttel").val();
           var databz=$("#bz").val();
           var datacode=$("#yzcode").val();

$.post("seller/Validatechangeshopinfo.htm",{address:dataaddress,phone:dataphone,contacts:datacontacts,contacttel:datacontactstel,bz:databz,code:datacode},function(data) {
             $("#btnchangeshopinfo").removeAttr("disabled").val("提交");
             if(data=="0")
             {
             $.toast("验证码输入错误，请重新输入!");
             $("#yzcode").val("");
             $("#imgcode").attr("src", "safecode?" + Math.random());
             }else if(data=="1")
             {
            $.toast("修改商户信息成功!");
             setTimeout(function(){window.location.href ="seller/shopcenter.htm";},1000);
            }
            else{
             $.toast("服务器异常，请重新提交以上信息！");
        }
  }, "text");
});
/*用户中心*/
 /*当加载补全基础信息页面时，判断用户是否补全过了*/
   var isinituserinfo=function(){
	  
 		var dataopenid = GetQueryString("openid"); 
 		 //alert(dataopenid);
			 $.post("user/checkuseropenid.htm",{openid:dataopenid},function(data) {
	             if(data=="1")
	             {
		            $.toast("你已补全基础信息!正在跳转到用户中心!");
		             setTimeout(function(){window.location.href ="user/index.htm";},1000);
		            }
			 	}, "text");
			
    }

     /*初始化用户中心主页*/
     var inituserindexinfo=function (){
    	 var datauseropenid = getcookie("wxopenid"); 
 				$(".page-group").css({display:"block"});
		    			 $.post("user/inituserindexinfo.htm",{useropenid:datauseropenid},function(data){
		    				$("#userid").html(data.idusers);
		    			 	$("#totalscore").html(data.totalscore);
		    			 },"json")
    		
     }
     /*初始化用户修改信息*/
     var inituserinfo=function (){
    	 var datauseropenid = getcookie("wxopenid"); 
 				
		    			 $.post("user/inituserinfo.htm",{useropenid:datauseropenid},function(data){
		    				 	$("#user_name").val(data[0].name);
		    				 	$("#usertelno").val(data[0].phone);
		    				 	$("#useroilno").val(data[0].useroilid);
		    				 	if(data[0].isdistrict=="0"){
		    				 		$("#isdistrict").prop("checked",false);
		    				 		$("#isdistrict").val(0);
		    						$("#li4recommentel").attr("style","display:none;");
		    						$("#li4address").attr("style","display:block;");
		    						$("#address").val(data[0].address);	
		    						var addressarr=data[0].address.split(" ");		    						
		    						$("#address").cityPicker("setValue",addressarr);
		    				 	}
		    				 	else if(data[0].isdistrict=="1"){
		    				 		$("#isdistrict").prop("checked",true);
		    				 		$("#isdistrict").val(1);
		    						$("#li4address").attr("style","display:none;");
		    						$("#li4recommentel").attr("style","display:block;");
		    				 		$("#recommentel").val(data[0].recommentel);
		    				 	}
		    			 },"json")
    		
     }
     /*修改用户基础信息处理逻辑*/
     $("#btnchangeuserinfo").click(function () {
         if (!changeuserinfovalidateInput()) return;
           $(this).attr("disabled", "disabled").val("正在处理...");
           var datausername=$("#user_name").val();
           var dataphone = $("#usertelno").val();
           var datauseroilno=$("#useroilno").val();
           var dataaddress=$("#address").val();
           var dataisdistrict=$("#isdistrict").val();
           var datarecommentel=$("#recommentel").val();
           var datacode=$("#telcode").val();
           var dataopenid=getcookie("wxopenid");
           

$.post("user/Validatechangeuserinfo.htm",{username:datausername,phone:dataphone,useroilno:datauseroilno,address:dataaddress,isdistrict:dataisdistrict,recommentel:datarecommentel,code:datacode,openid:dataopenid},function(data) {
             $("#btnchangeuserinfo").removeAttr("disabled").val("提交");
             if(data=="0")
             {
             $.toast("验证码输入错误，请重新输入!");
             $("#telcode").val("");
             }else if(data=="1")
             {
            $.toast("操作成功!正在为你跳转到用户中心..");
             setTimeout(function(){window.location.href ="user/index.htm";},1000);
            }
            else{
             $.toast("服务器异常，请重新提交以上信息！");
        }
  }, "text");
});
     /*初始化用户消减积分列表*/
   var inituserminscorelist=function (){
    	 var datauseropenid = getcookie("wxopenid"); 

 			 $.post("user/inituserminscorelist.htm",{useropenid:datauseropenid},function(data){
    				 if($.isEmptyObject(data)){
	                	 $.toast("没有找到积分消减记录！");
	                     setTimeout(function(){window.location.href ="user/index.htm";},1000);
	                 }
	                else{
	                	$("#scoremlist").children("li").remove();
	                	for(var i=0;i<data.length;i++){
	                		$("#scoremlist").append("<li class=\"item-content\"><div class=\"item-media\"><img src=\"common/images/sg.png\" style=\"width: 4rem;\"></div><div class=\"item-inner\"><div class=\"item-title-row\"><div class=\"item-title\">商家名称："+data[i].name+"</div></div><div class=\"item-subtitle\">消减金额 "+data[i].money+"元 消减积分 "+data[i].score+"分</div><div class=\"item-text\">消减日期："+data[i].date+"</div></div></li>");
	                	}
	                }
    			 },"json");}
   /*初始化用户兑换积分列表*/
   var initexchangescorelist=function (){
    	 var datauseropenid = getcookie("wxopenid");
    			 $.post("user/initexchangescorelist.htm",{useropenid:datauseropenid},function(data){
    				 if($.isEmptyObject(data)){
	                	 $.toast("没有找到积分兑换记录！");
	                     setTimeout(function(){window.location.href ="user/index.htm";},1000);
	                 }
	                else{
	                	$("#exchangescorelist").children("li").remove();
	                	for(var i=0;i<data.length;i++){
	                		$("#exchangescorelist").append("<li class=\"item-content\"><div class=\"item-media\"><img src=\"common/images/"+data[i].logo+"\" style='width: 4rem;'></div><div class=\"item-inner\"><div class=\"item-title-row\"><div class=\"item-title\">兑换项："+data[i].name+"</div></div><div class=\"item-subtitle\">积分："+data[i].score+"分 </div><div class=\"item-text\">兑换日期："+data[i].date+"</div></div></li>");
	                	}
	                }
    			 },"json");
      	
    		}
     
     /*发送手机验证码业务逻辑*/
     $("#addusercode").click(function () {

    	 var datausertel = $("#usertelno").val();
    	 if (datausertel == "") {
             $("#usertelno").focus();
             $.toast("手机号不能为空!");
         }
    	 else{
    	 var datasmsTemplateCode="SMS_11360183";
    	 var validCode=true;
    	 var time=60;
			var code=$(this);
			if (validCode) {
				validCode=false;
				code.attr("class","button disabled");
			var t=setInterval(function  () {
				time--;
				code.val(time+"秒后重新获取");
				if (time==0) {
					clearInterval(t);
				code.val("重新获取");

					validCode=true;
					code.attr("class","button  button-fill active");
				}
			},1000);

			}
    	 $.post("user/sendinitusersms.htm",{telno:datausertel,smstemplatecode:datasmsTemplateCode},function(data) {
    		 if(data=="1")
             {
             $.toast("发送成功!");
             }
            else{
             $.toast("服务器异常，请重新获取验证码！");
        }

  }, "text");
    	 }
});
     /*补全用户基础信息处理逻辑*/
     $("#btnadduserinfo").click(function () {
         if (!adduserinfovalidateInput()) return;
           $(this).attr("disabled", "disabled").val("正在处理...");
           var datausername=$("#user_name").val();
           var dataphone = $("#usertelno").val();
           var datauseroilno=$("#useroilno").val();
           var dataaddress=$("#address").val();
           var dataisdistrict=$("#isdistrict").val();
           var datarecommentel=$("#recommentel").val();
           var datacode=$("#telcode").val();
           var dataopenid ="";
           //alert(dataopenid);
           var args = new Object();
           args = GetUrlParms();
           if(args["openid"]!=undefined||args["openid"]!="")
			{
        	   dataopenid = args["openid"] ;
			}
           else{
        	   dataopenid=getcookie("wxopenid");
           }

$.post("user/Validateadduserinfo.htm",{username:datausername,phone:dataphone,useroilno:datauseroilno,address:dataaddress,isdistrict:dataisdistrict,recommentel:datarecommentel,code:datacode,openid:dataopenid},function(data) {
             $("#btnadduserinfo").removeAttr("disabled").val("提交");
             if(data=="0")
             {
             $.toast("验证码输入错误，请重新输入!");
             $("#telcode").val("");
             }else if(data=="1")
             {
            $.toast("操作成功!正在为你跳转到用户中心..");
             setTimeout(function(){window.location.href ="user/index.htm";},1000);
            }
            else{
             $.toast("服务器异常，请重新提交以上信息！");
        }
  }, "text");
});
     /*用户物业报修申请处理逻辑*/
     $("#btnuserapplicationwyfix").click(function () {
         if (!wyfixuserapplicationvalidateInput()) return;
           $(this).attr("disabled", "disabled").val("正在处理...");
           var datafixname=$("#fixname").val();
           var datafixaddress = $("#fixaddress").val();
           var datafixtime=$("#fixtime").val();
           var dataproblemcontents=$("#problemcontents").val();
           var datacontact=$("#contact").val();
           var datacontacttel=$("#contacttel").val();
           var dataopenid = getcookie("wxopenid");

$.post("user/Validateuserapplicationwyfix.htm",{fixname:datafixname,fixaddress:datafixaddress,fixtime:datafixtime,problemcontents:dataproblemcontents,contact:datacontact,contacttel:datacontacttel,openid:dataopenid},function(data) {
             $("#btnuserapplicationwyfix").removeAttr("disabled").val("提交");
             if(data=="1")
             {
            $.toast("操作成功!正在为你跳转到用户中心..");
             setTimeout(function(){window.location.href ="user/index.htm";},1000);
            }
            else{
             $.toast("服务器异常，请重新提交以上信息！");
            }
  }, "text");
});
     /*查询用户积分处理逻辑*/
     $("#queryscore").click(function () {
         if (!userqueryscorevalidateInput()) return;
           $(this).attr("disabled", "disabled").val("正在查询...");
           var datashopname=$("#shopname").val();
           var datauseropenid = getcookie("wxopenid"); 
           var datadate1=$("#date1").val();
           var datadate2=$("#date2").val();

$.post("user/ajax4queryscore.htm",{shopname:datashopname,useropenid:datauseropenid,date1:datadate1,date2:datadate2},function(data) {
             $("#queryscore").removeAttr("disabled").val("查询");
             if(data=="1")
             {
                $.toast("正在跳转，请稍侯!");
                setTimeout(function(){window.location.href ="user/userscorelist.htm?shopname="+datashopname+"&date1="+datadate1+"&date2="+datadate2;},1000);
             }else if(data=="-2"){
                 $.toast("没有查询到您需要的积分信息！");
             }
             else{
                 $.toast("服务器异常，请重新提交以上信息！");
            }

	}, "text");
});
     /*初始化用户积分列表*/
    var initusersorelistinfo= function (){
     	 var shopname="";
     	 var date1="";
     	 var date2="";
     	 
       	 var datauseropenid = getcookie("wxopenid"); 
		$(".page-group").css({display:"block"});
        	   $.post("user/inituserindexinfo.htm",{useropenid:datauseropenid},function(data){
   			 	$("#totalscore").html(data.totalscore);
   			 },"json");
     			var args = new Object();
     			 args = GetUrlParms();
     			 if(args["shopname"]!=undefined||args["shopname"]!="")
     				{
     				shopname = args["shopname"] ;
     				}
     			 if(args["date1"]!=undefined||args["date1"]!="")
     				{
     				 	date1 = args["date1"] ;
     				}
     			 if(args["date2"]!=undefined||args["date2"]!="")
     				{
     				 	date2 = args["date2"] ;
     				}

     			if(shopname!= null||date1!= null||date2!=null){
     				$.post("user/ajaxscorelist.htm",{"shopname":shopname,"date1":date1,"date2":date2,useropenid:datauseropenid},function(data){
     	                if($.isEmptyObject(data)){
     	                	 $.toast("没有查询到您需要的积分信息！");
     	                     setTimeout(function(){window.location.href ="user/index.htm";},1000);
     	                 }
     	                else{
     	                	var scoreOut;
     	                	$("#scorelist").children("li").remove();
     	                	for(var i=0;i<data.length;i++){
     	                		$("#scorelist").append("<li class=\"item-content\"><div class=\"item-media\"><img src=\"common/images/sg.png\" style='width: 4rem;'></div><div class=\"item-inner\"><div class=\"item-title-row\"><div class=\"item-title\">商家名称："+data[i].shopname+"</div></div><div class=\"item-subtitle\">消费金额 "+data[i].money+"元 积分 "+data[i].score+"分</div><div class=\"item-text\">积分日期："+data[i].dt+"<br><div class=\"star\"></div><span style=\"float:right;\">立即评价:</span></div></div></li>");
     	                	}
     	                	$('.star').raty({
		     			        number: 5, size: 'small', path: 'common/lib/zepto.raty/images', score: 0, space: false, click: function (score) {
		     			            scoreOut = score;
		     			           // console.log(scoreOut)
		     			        }
		     			    });
     	                	} },"json");
     				}
     				else{
     				$.post("user/ajaxscorelist.htm",{"useropenid":datauseropenid},function(data){
     	                if($.isEmptyObject(data)){
     	                	 $.toast("没有找到积分记录！");
     	                     setTimeout(function(){window.location.href ="user/index.htm";},1000);
     	                 }
     	                else{
     	                	var scoreOut;
     	                	$("#scorelist").children("li").remove();
     	                	for(var i=0;i<data.length;i++){
     	                		$("#scorelist").append("<li class=\"item-content\"><div class=\"item-media\"><img src=\"common/images/sg.png\" style='width: 4rem;'></div><div class=\"item-inner\"><div class=\"item-title-row\"><div class=\"item-title\">商家名称："+data[i].shopname+"</div></div><div class=\"item-subtitle\">消费金额 "+data[i].money+"元 积分 "+data[i].score+"分</div><div class=\"item-text\">积分日期："+data[i].dt+"<br><div class=\"star\"></div><span style=\"float:right;\">立即评价:</span></div></div></li>");
     	                	}
     	                	$('.star').raty({
		     			        number: 5, size: 'small', path: 'common/lib/zepto.raty/images', score: 0, space: false, click: function (score) {
		     			            scoreOut = score;
		     			            //console.log(scoreOut)
		     			        }
		     			    });
     	                } },"json");

     		}
     }
    function equaltoday(date){
    	var now = new Date();
    	  var year = now.getFullYear();
          var month = now.getMonth() + 1;
          var day = now.getDate();
          var todaydate=year+"年"+month+"月"+day+"日";
          var fomatdate=date.split(' ')[0];
          if (fomatdate===todaydate){
        	  return true;
          }
          else{
        	  return false;
          }
    }
    /*初始化用户商家列表*/
    var initusersellerlistinfo= function (){
     	 var datauseropenid = getcookie("wxopenid"); 
  		  $(".page-group").css({display:"block"});
   
     				$.post("user/ajaxsellerlist.htm",{useropenid:datauseropenid},function(data){
     	                if($.isEmptyObject(data)){
     	                	 $.toast("没有找到到您需要的商户信息！");
     	                     setTimeout(function(){window.location.href ="https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx1447cb4b5d5a3196&redirect_uri=http://shequ.cbelite.cn/wuye/user/index.htm&response_type=code&scope=snsapi_base&state=s&connect_redirect=1#wechat_redirect";},1000);
     	                 }
     	                else{
     	                	var scoreOut;
     	                	$("#sellerlist").children("li").remove();
     	                	for(var i=0;i<data.length;i++){
     	                		$("#sellerlist").append("<li class=\"item-content\"><div class=\"item-media\"><img src=\"common/images/sg.png\" style='width: 4rem;'></div><div class=\"item-inner\"><div class=\"item-title-row\"><div class=\"item-title\">商家名称："+data[i].name+"</div></div><div class=\"item-subtitle\">电话："+data[i].phone+"</div><div class=\"item-text\">地址："+data[i].address+"<br><!--<div class=\"star\"></div><span style=\"float:right;\">立即评价:</span>--></div></div></li>");
     	                	}
     	                	$('.star').raty({
		     			        number: 5, size: 'small', path: 'common/lib/zepto.raty/images', score:0, space: false, click: function (score) {
		     			            scoreOut = score;
		     			           // console.log(scoreOut)
		     			        }
		     			    });
     	                	} },"json");
     				}
    
     		
     
    /*初始化物业通知列表*/
    var initwynotice=function (){
     	 var datauseropenid = getcookie("wxopenid"); 

     			 $.post("user/initwynoticelist.htm",{useropenid:datauseropenid},function(data){
     				 if($.isEmptyObject(data)){
 	                	 $.toast("没有通知记录！");
 	                     setTimeout(function(){window.location.href ="user/index.htm";},1000);
 	                 }
 	                else{
 	                	$("#wynoticelist").children("li").remove();
 	                	for(var i=0;i<data.length;i++){
 	                		//if(equaltoday(data[i].dt)){
 	                			$("#wynoticelist").append("<li><a href=\"user/detailnotice.htm?noteid="+data[i].idnote+"\" class=\"external item-link item-content\"><div class=\"item-media\"><img src=\"common/images/notice.png\" style=\"width: 2rem;\"></div><div class=\"item-inner\"><div class=\"item-title-row\"><div class=\"item-title\">通知："+data[i].title+"</div></div> <div class=\"item-subtitle\">"+data[i].content+"<br>(点击可查看详情)</div> <div class=\"item-text\">日期："+data[i].dt+"</div></div></a></li>");
 	                		//}
 	                		//else{
 	                			//$("#wynoticelist").append("<li><a href=\"user/detailnotice.htm?noteid="+data[i].idnote+"\" class=\"external item-link item-content\"><div class=\"item-media\"><img src=\"common/images/news1.png\" style=\"width: 2rem;\"></div><div class=\"item-inner\"><div class=\"item-title-row\"><div class=\"item-title\">通知："+data[i].title+"</div></div> <div class=\"item-subtitle\">"+data[i].content+"<br>(点击可查看详情)</div> <div class=\"item-text\">日期："+data[i].dt+"</div></div></a></li>");
 	                		//}
 	                	}
 	                }
     			 },"json");

      }

    /*初始化通知详情信息*/
    var initdetailwynotice= function (){
    	var dataidnote = "";
 		var args = new Object();
		 args = GetUrlParms();
		  if(args["noteid"]!=undefined&&args["noteid"]!=""){
			  dataidnote = args["noteid"] ;
			  $.post("user/ajaxdetailnotice.htm",{"idnote":dataidnote},function(data){
  				$("#notetitle").html(data[0].title);
  			 	$("#dt").html(data[0].dt);
  			 	$("#readnum").html(data[0].viewnum);
  			 	$("#content").html(data[0].content);
  			 },"json");
  		}
    }
    $("#dialog").click(function () {
    	var userid=$("#userid").html();
        qrcode.makeCode(userid);
        $(".layer").css({display:"block"});
    });
 $("#closedialog").click(function () {
   $(".layer").css({display:"none"});
    });

 $("#scancode").click(function () {
	 wx.scanQRCode({
		    needResult: 1,
		    scanType: ["qrCode"],
		    success: function (res) {
		    var result = res.resultStr;
		    $("#countid").val(result);
		    }
		});
	    });
