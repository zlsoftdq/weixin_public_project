    // 对浏览器的UserAgent进行正则匹配，不含有微信独有标识的则为其他浏览器
    var useragent = navigator.userAgent;
    if (useragent.match(/MicroMessenger/i) != 'MicroMessenger') {
        // 这里警告框会阻塞当前页面继续加载
    	window.location.href ="https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx1447cb4b5d5a3196&redirect_uri=http://shequ.cbelite.cn/wuye/user/adduser.htm&response_type=code&scope=snsapi_base&state=s";
    }