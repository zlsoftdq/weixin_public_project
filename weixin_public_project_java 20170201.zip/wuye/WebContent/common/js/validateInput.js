 function comparedate(a, b) {
    var arr = a.split("-");
    var starttime = new Date(arr[0], arr[1], arr[2]);
    var starttimes = starttime.getTime();

    var arrs = b.split("-");
    var lasttime = new Date(arrs[0], arrs[1], arrs[2]);
    var lasttimes = lasttime.getTime();

    if (starttimes >= lasttimes) {

    	$.toast("起始日期不能大于终止日期，请重新选择!");
        return true;
    }
    else
        return false;

}  
/*商户中心验证*/
 function loginvalidateInput() {
     var isOk = true;
     var isPwd = /^[0-9a-zA-Z]*$/;
     if ($("#username").val() == "") {
         myalert("用户名不能为空!");
         isOk = false;
     }
     else if ($("#password").val() == "") {
         myalert("密码不能为空!");
         isOk = false;
     }
     else if (!isPwd.test($("#password").val())) {
         myalert("密码中含有非法字符!");
         isOk = false;
     }
     return isOk;
}
function shoploginvalidateInput() {
         var isOk = true;
         var isPwd = new RegExp("^[0-9a-zA-Z]*$");   
         if ($("#uname").val() == "") {
             $.toast("用户名不能为空!");
             isOk = false;
         }
         else if ($("#pwd").val() == "") {
             $.toast("密码不能为空!");
             isOk = false;
         }
         else if ($("#yzcode").val() == "") {
             $.toast("验证码不能为空!");
             isOk = false;
         }
         else  if (!(isPwd.test($("#uname").val()))){
             $.toast("用户名中含有非法字符!");
             isOk = false;
         }
         else if (!isPwd.test($("#pwd").val())) {
             $.toast("密码中含有非法字符!");
             isOk = false;
         }
  
         return isOk;
}
function minscore2comstomervalidateInput() {
    var isOk = true;
    if ($("#usertel").val() == "") {
        $.toast("客户手机号获取失败!");
        isOk = false;
    }else if ($("#minmoney").val() == "") {
        $.toast("消减金额获取失败!");
        isOk = false;
    }else  if ($("#telcode").val() == "") {
        $.toast("手机验证码不能为空!");
        isOk = false;
    }
    return isOk;
}
  function changeshoppwdvalidateInput() {
         var isOk = true;
         var isPwd = new RegExp("^[0-9a-zA-Z]*$");
         if ($("#oldpwd").val() == "") {
             $.toast("原密码不能为空!");
             isOk = false;
         }
         else if ($("#newpwd").val() == "") {
             $.toast("新密码不能为空!");
             isOk = false;
         }
         else if ($("#confirmnewpwd").val() == "") {
             $.toast("确认新密码不能为空!");
             isOk = false;
         }
         else if ($("#yzcode").val() == "") {
             $.toast("验证码不能为空!");
             isOk = false;
         }
         else if (!isPwd.test($("#oldpwd").val())) {
             $.toast("原密码中含有非法字符!");
             isOk = false;
         }
         else if (!isPwd.test($("#newpwd").val())) {
             $.toast("新密码中含有非法字符!");
             isOk = false;
         }
         else if (!isPwd.test($("#confirmnewpwd").val())) {
             $.toast("确认密码中含有非法字符!");
             isOk = false;
         }
         else if ($("#newpwd").val() != $("#confirmnewpwd").val()) {
             $.toast("新密码与确认新密码不一致，请重新输入！");
             isOk = false;
         }
         return isOk;
}
  function adduserscorevalidateInput() {
      var isOk = true;
      var isNum = new RegExp("^[0-9]*$");
      var isTel= new RegExp("^[1][3,5,7,8][0-9]{9}$");
      var isMoney=new RegExp("^-?\d+\.?\d{0,2}$");
      if (Number(Boolean($("#countid").val()))+Number(Boolean($("#usertel").val()))<1){
          $.toast("计分ID和手机号必须填写其中一项!");
          isOk = false;
      }
      else if ($("#money").val() == "") {
          $.toast("消费金额不能为空!");
          isOk = false;
      }
      else if($("#countid").val() != "") {
       if (!isNum.test($("#countid").val())) {
          $.toast("客户计分id只能输入数字!");
          isOk = false;
      }
      }
      else if($("#usertel").val() != "") {
       if (!isTel.test($('#usertel').val())) {
          $.toast("请输入正确的手机号!");
          isOk = false;
      }
      }
      return isOk;
}
  function queryuserscorevalidateInput() {
      var isOk = true;
      var isNum = new RegExp("^[0-9]*$");
      var isTel= new RegExp("^[1][3,5,7,8][0-9]{9}$");
      if (Number(Boolean($("#customername").val()))+Number(Boolean($("#customeruserid").val()))+Number(Boolean($("#customertel").val()))<1){
          $.toast("客户姓名，计分ID和手机号必须填写其中一项!");
          isOk = false;
      }
      else if ($("#date1").val() == "") {
          $.toast("请选择查询的起始日期!");
          isOk = false;
      }
      else if ($("#date2").val() == "") {
         $.toast("请选择查询的终止日期!");
          isOk = false;
      }
      else if(comparedate($("#date1").val(),$("#date2").val())){
    	  isOk = false;
      }
      else if($("#customeruserid").val() != "") {
        if (!isNum.test($("#customeruserid").val())) {
          $.toast("客户计分id只能输入数字!");
          isOk = false;
      }
      }
      else if($("#customertel").val() != "") {
       if (!isTel.test($('#customertel').val())) {
          $.toast("请输入正确的手机号!");
          isOk = false;
      }
      }
     return isOk;
}
  function shopminscorevalidateInput() {
      var isOk = true;
      var isNum = new RegExp("^[0-9]*$");
      var isTel= new RegExp("^[1][3,5,7,8][0-9]{9}$");
      var isMoney=new RegExp("^-?\d+\.?\d{0,2}$");
      if (Number(Boolean($("#countid").val()))+Number(Boolean($("#usertel").val()))<1 ){
          $.toast("计分ID和手机号必须填写其中一项!");
          isOk = false;
      }
      else if ($("#minmoney").val() == "") {
          $.toast("消减金额不能为空!");
          isOk = false;
      }
      else if ($("#minreason").val() == "") {
          $.toast("消减理由不能为空!");
          isOk = false;
      }
      else if($("#countid").val() != "") {
       if (!isNum.test($("#countid").val())) {
          $.toast("客户计分id只能输入数字!");
          isOk = false;
      }
      }
      else if($("#usertel").val() != "") {
       if (!isTel.test($('#usertel').val())) {
          $.toast("请输入正确的手机号!");
          isOk = false;
      }
      }
      return isOk;
}
  function changeshopinfovalidateInput() {
      var isOk = true;
      var isTel= new RegExp("^[1][3,5,7,8][0-9]{9}$");
      if ($("#address").val() == "") {
          $.toast("地址不能为空!");
          isOk = false;
      }
      else if ($("#phone").val() == "") {
          $.toast("客服电话不能为空!");
          isOk = false;
      }
      else if ($("#contacts").val() == "") {
          $.toast("联系人不能为空!");
          isOk = false;
      }
      else if ($("#contacttel").val() == "") {
          $.toast("联系电话不能为空!");
          isOk = false;
      }
      else if ($("#yzcode").val() == "") {
          $.toast("验证码不能为空!");
          isOk = false;
      }
      else if (!isTel.test($('#contacttel').val())) {
          $.toast("请输入正确的手机号!");
          isOk = false;
      }
      
      return isOk;
}
  /*用户中心验证*/ 
  function adduserinfovalidateInput() {
      var isOk = true;
      var isTel= new RegExp("^[1][3,5,7,8][0-9]{9}$");
      if ($("#user_name").val() == "") {
          $.toast("姓名不能为空!");
          isOk = false;
      }
      else if ($("#usertelno").val() == "") {
          $.toast("手机号码不能为空!");
          isOk = false;
      }
      else if ($("#telcode").val() == "") {
          $.toast("验证码不能为空!");
          isOk = false;
      }
      else if (!isTel.test($('#usertelno').val())) {
          $.toast("请输入正确的手机号!");
          isOk = false;
      }
      if($("#isdistrict").prop("checked")){
  		$("#isdistrict").val(1);
  		if ($("#recommentel").val() == "") {
            $.toast("请输入推荐人手机号!");
            isOk = false;
        }
  		else if (!isTel.test($('#recommentel').val())) {
            $.toast("请输入正确的手机号!");
            isOk = false;
        }
  	}
  	else{
  		$("#isdistrict").val(0);  		
  		if ($("#address").val() == "") {
            $.toast("请选择您的住宅地址!");
            isOk = false;
        }
  		else{
  			var dataaddress=$("#address").val();
  			var arr=dataaddress.split(" ");
  			if(arr[2].indexOf("单元")==-1){
  				$.toast("您选择住宅地址的格式不正确!");
  	            isOk = false;
  			}
  		}    
  	}
      return isOk;
}
  function changeuserinfovalidateInput() {
      var isOk = true;
      var isTel= new RegExp("^[1][3,5,7,8][0-9]{9}$");
      if ($("#user_name").val() == "") {
          $.toast("姓名不能为空!");
          isOk = false;
      }
      else if ($("#usertelno").val() == "") {
          $.toast("手机号码不能为空!");
          isOk = false;
      }
      else if ($("#telcode").val() == "") {
          $.toast("验证码不能为空!");
          isOk = false;
      }
      else if (!isTel.test($('#usertelno').val())) {
          $.toast("请输入正确的手机号!");
          isOk = false;
      }
      if($("#isdistrict").prop("checked")){
  		$("#isdistrict").val(1);
  		if ($("#recommentel").val() == "") {
            $.toast("请输入推荐人手机号!");
            isOk = false;
        }
  		else if (!isTel.test($('#recommentel').val())) {
            $.toast("请输入正确的手机号!");
            isOk = false;
        }
  	}
  	else{
  		$("#isdistrict").val(0);  		
  		if ($("#address").val() == "") {
            $.toast("请选择您的住宅地址!");
            isOk = false;
        }
  		else{
  			var dataaddress=$("#address").val();
  			var arr=dataaddress.split(" ");
  			if(arr[2].indexOf("单元")==-1){
  				$.toast("您选择住宅地址的格式不正确!");
  	            isOk = false;
  			}
  		}    
  	}
      return isOk;
}
  function wyfixuserapplicationvalidateInput() {
      var isOk = true;
      var isTel= new RegExp("^[1][3,5,7,8][0-9]{9}$");
      if ($("#fixname").val() == "") {
          $.toast("报修项目不能为空!");
          isOk = false;
      }
      else if ($("#fixaddress").val() == "") {
          $.toast("请选择维修地点!");
          isOk = false;
      }
      else if ($("#fixtime").val() == "") {
          $.toast("请选择预约时间!");
          isOk = false;
      }
      else if ($("#problemcontents").val() == "") {
          $.toast("问题描述不能为空!");
          isOk = false;
      }
      else if ($("#contact").val() == "") {
          $.toast("联系人不能为空!");
          isOk = false;
      }
      else if ($("#contacttel").val() == "") {
          $.toast("联系电话不能为空!");
          isOk = false;
      }
      else if (!isTel.test($('#contacttel').val())) {
          $.toast("请输入正确的手机号!");
          isOk = false;
      }      
      return isOk;
}
  function userqueryscorevalidateInput() {
      var isOk = true;
      if ($("#shopname").val() == ""){
          $.toast("商家名称不能为空!");
          isOk = false;
      }
      else if ($("#date1").val() == "") {
          $.toast("请选择查询的起始日期!");
          isOk = false;
      }
      else if ($("#date2").val() == "") {
          $.toast("请选择查询的终止日期!");
          isOk = false;
      }
      else if(comparedate($("#date1").val(),$("#date2").val())){
    	  isOk = false;
      }
     return isOk;
}